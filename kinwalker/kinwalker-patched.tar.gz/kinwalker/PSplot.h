/*
  Last changed Time-stamp: <2006-02-10 15:37:56 xtof>
  $Id: PSplot.h,v 1.1.1.1 2006/02/15 10:15:54 xtof Exp $
*/
#ifndef _PSPLOT_H_
#define _PSPLOT_H_

void
PSColorPlot(std::string sequence, std::string outPath, double max_ratio);

#endif

/* End of file */
