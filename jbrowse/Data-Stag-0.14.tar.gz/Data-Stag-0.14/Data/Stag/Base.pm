package Data::Stag::Base;
use base qw(Data::Stag::BaseHandler);

use vars qw($VERSION);
$VERSION="0.14";

# DEPRECATED MODULE - synonym for BaseHandler

1;
