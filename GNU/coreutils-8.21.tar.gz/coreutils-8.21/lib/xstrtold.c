#define LONG 1
#include "xstrtod.c"
