`summary.cca` <-
function(object, ...){
    s<-object
    class(s)<-"summary.cca"
    s
}

