Usage:

It needs to call RNAsubopt(from Vienna Package) and predator.

Command line: RNAScore file1 file2

file1��A file of RNA in fasta format,e.g.��RNA.txt��. If there is more than one sequence, only the first one will be processed. The RNA sequence should not be longer than 4095, since the RNAsubopt software will only process the first 4095 nucleotides if the input RNA is too long.
file2��A file of protein in fasta format,e.g ��protein.txt��. Each run can handle multiple sequences.

