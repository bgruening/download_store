#' The checkmate package
#'
#' @section Additional information:
#'
#' \describe{
#'   \item{Homepage:}{\url{https://github.com/mllg/checkmate}}
#' }
#'
#' @docType package
#' @name checkmate
NULL
