#ifndef CHECKMATE_HELPER_H_
#define CHECKMATE_HELPER_H_

#include <R.h>
#include <Rinternals.h>

Rboolean isStrictlyNumeric(SEXP);

#endif
