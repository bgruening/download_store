#ifndef CHECKMATE_QTEST_H_
#define CHECKMATE_QTEST_H_

#include <R.h>
#include <Rinternals.h>

SEXP c_qtest(SEXP, SEXP, SEXP);

#endif
