library(testthat)
test_check("BatchJobs")
