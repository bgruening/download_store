.graphviz_build_version <- list(version = numeric_version("2.28.0"),
                                bundled = TRUE)
