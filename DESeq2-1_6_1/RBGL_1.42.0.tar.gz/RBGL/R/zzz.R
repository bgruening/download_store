.onLoad <- function(libname, pkgname) require("methods")

