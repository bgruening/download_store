#ifndef _@PKG@_RCPP_HELLO_WORLD_H
#define _@PKG@_RCPP_HELLO_WORLD_H

#include <RcppArmadillo.h>

RcppExport SEXP rcpparma_hello_world() ;

#endif
