### =========================================================================
### The is.unsorted() generic
### -------------------------------------------------------------------------

setGeneric("is.unsorted",
           function(x, na.rm = FALSE, strictly = FALSE)
           standardGeneric("is.unsorted"),
           signature = "x")
