### R code from vignette source 'RcppArmadillo-unitTests.Rnw'

###################################################
### code chunk number 1: RcppArmadillo-unitTests.Rnw:13-16
###################################################
if( file.exists( "unitTests-results/RcppArmadillo-unitTests.txt" ) ){
	writeLines( readLines( "unitTests-results/RcppArmadillo-unitTests.txt" ) )
}


