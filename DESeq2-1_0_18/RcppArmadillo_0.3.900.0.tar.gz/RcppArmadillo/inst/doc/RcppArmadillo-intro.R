### R code from vignette source 'RcppArmadillo-intro.Rnw'

###################################################
### code chunk number 1: RcppArmadillo-intro.Rnw:44-46
###################################################
prettyVersion <- packageDescription("RcppArmadillo")$Version
prettyDate <- format(Sys.Date(), "%B %e, %Y")


