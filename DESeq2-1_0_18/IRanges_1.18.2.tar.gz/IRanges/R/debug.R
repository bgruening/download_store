###

debug_AEbufs <- function()
    invisible(.Call2("debug_AEbufs", PACKAGE="IRanges"))

debug_Ocopy_byteblocks <- function()
    invisible(.Call2("debug_Ocopy_byteblocks", PACKAGE="IRanges"))

debug_IRanges_class <- function()
    invisible(.Call2("debug_IRanges_class", PACKAGE="IRanges"))

debug_Grouping_class <- function()
    invisible(.Call2("debug_Grouping_class", PACKAGE="IRanges"))

debug_SharedVector_class <- function()
    invisible(.Call2("debug_SharedVector_class", PACKAGE="IRanges"))

debug_SharedRaw_class <- function()
    invisible(.Call2("debug_SharedRaw_class", PACKAGE="IRanges"))

debug_SharedInteger_class <- function()
    invisible(.Call2("debug_SharedInteger_class", PACKAGE="IRanges"))

debug_SharedDouble_class <- function()
    invisible(.Call2("debug_SharedDouble_class", PACKAGE="IRanges"))

debug_XVector_class <- function()
    invisible(.Call2("debug_XVector_class", PACKAGE="IRanges"))

debug_inter_range_methods <- function()
    invisible(.Call2("debug_inter_range_methods", PACKAGE="IRanges"))

