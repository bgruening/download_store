### R code from vignette source 'Bioconductor.Rnw'

###################################################
### code chunk number 1: Bioconductor.Rnw:91-92
###################################################
sessionInfo()


