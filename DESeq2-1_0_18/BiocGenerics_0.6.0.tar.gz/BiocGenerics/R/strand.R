### =========================================================================
### The strand() and `strand<-`() generics
### -------------------------------------------------------------------------

setGeneric("strand", function(x, ...) standardGeneric("strand"))

setGeneric("strand<-", function(x, ..., value) standardGeneric("strand<-"))

