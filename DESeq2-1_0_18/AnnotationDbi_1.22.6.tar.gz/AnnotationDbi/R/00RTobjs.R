### Environment for storing run-time objects
RTobjs <- new.env(hash=TRUE, parent=emptyenv())

