#ifndef UTIL_H
#define UTIL_H

namespace bode {

int splits(char *str,char **dest,int max);
void trimTrailing(char *str);

}

#endif
