require("Rsamtools") || stop("unable to load Rsamtools package")
Rsamtools:::.test()
