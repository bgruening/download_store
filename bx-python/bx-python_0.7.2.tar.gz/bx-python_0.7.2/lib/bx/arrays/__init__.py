"""
Classes for working with arrays of data.
"""
