"""
Data structures and tools for working with Position Weight Matrices (PWMs).

TODO: Some of the packages in this directory are actually command line
programs that provide no library functions and should be moved to the
scripts directory.
"""