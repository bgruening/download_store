/*
 * BlockClust.cpp
 *
 *  Created on: Nov 9, 2012
 *      Author: videmp
 */

#include "BlockClust.h"
#include <iostream>
using namespace std;

BlockClust::BlockClust(){
}

BlockClust::~BlockClust(){
}

int main (int argc, char **argv){
    int modeFlag = 0;
	string trainFile, testFile, validationFile, configFile, outDir, rejectBED, acceptBED;
    char *mode = NULL;
    char *gspanFormat;
    unsigned short radius = 0;
    unsigned short nrOfBins = 0;
    unsigned short bitSize = 0;
    int index;
    int c;
    float bestROC = 0;

    opterr = 0;

    while ((c = getopt (argc, argv, "c:n:o:a:b:m:R:V:T:t:r:f:")) != -1)
        switch (c){
        case 'm':
        	mode = optarg;
        	modeFlag = 1;
        	if(strcmp(mode, "TRAIN") != 0 && strcmp(mode, "TEST") != 0){
        		cerr << "option 'm' should be either 'TRAIN' or 'TEST' " << endl;
        		exit(0);
        	}
            break;
        case 'f':
        	gspanFormat = optarg;
        	if(strcmp(gspanFormat, "SIMPLE") != 0 && strcmp(gspanFormat, "PARALLEL") != 0
        	&& strcmp(gspanFormat, "SUB") != 0 && strcmp(gspanFormat, "PARTSUB") != 0
        	&& strcmp(gspanFormat, "SPECIAL") != 0 && strcmp(gspanFormat, "SEQUENCE") != 0){
        		cerr << "option 'f' should be SEQUENCE|SIMPLE|PARALLEL|SUB|PARTSUB|SPECIAL" << endl;
        		exit(0);
        	}
            break;
        case 'a':
        	acceptBED = optarg;
            break;
        case 'r':
        	rejectBED = optarg;
            break;
        case 'o':
        	outDir = optarg;
            break;
        case 'b':
        	sscanf(optarg, "%hu", &bitSize);
            break;
        case 'n':
        	sscanf(optarg, "%hu", &nrOfBins);
            break;
        case 'R':
        	sscanf(optarg, "%hu", &radius);
            break;
        case 'T':
        	trainFile = optarg;
            break;
        case 't':
        	testFile = optarg;
            break;
        case 'V':
        	validationFile = optarg;
            break;
        case 'c':
            configFile = optarg;
            break;
        case '?':
            if (optopt == 'c')
                fprintf (stderr, "Option -%c requires an argument.\n", optopt);
            else if (isprint (optopt))
                fprintf (stderr, "Unknown option `-%c'.\n", optopt);
            else
                fprintf (stderr,
                         "Unknown option character `\\x%x'.\n",
                         optopt);
            return 1;
		default:
            break;
	}
    for (index = optind; index < argc; index++)
        printf ("Non-option argument %s\n", argv[index]);


    if(!modeFlag){
    	fprintf (stderr, "option '-m' is mandatory\n");
		return 1;
    }

    /******************************************************/
    /********************* TEST MODE **********************/
    /******************************************************/
    if(strcmp(mode, "TEST") == 0){
		cout << "============== TESTING MODE ==============" << endl;

	    if(testFile.empty() || configFile.empty() || acceptBED.empty() || rejectBED.empty() || outDir.empty()){
	    	fprintf (stderr, "options '-t', '-c', '-a', '-r' and '-o' are mandatory in testing mode\n");
	    	return 1;
	    }

	    printf ("Blockbuster output	: %s\nConfiguration		: %s\nAccept annotations	: %s\nReject annotations	: %s\nOutput directory	: %s\n\n",
	    		testFile.c_str(), configFile.c_str(), acceptBED.c_str(), rejectBED.c_str(), outDir.c_str());
	    system (("mkdir "+outDir).c_str());

	    unsigned short nrOfBins = 0, radius = 0;
        char blockGroupFeatures[20] = "";
        char blockFeatures[50]= "";
        char blockEdgeFeatures[50]= "";
		string LINE;
		ifstream BB;
		BB.open(configFile.c_str());
		if(!BB.is_open()){
		    cerr << "Error opening file '" << configFile << "'!!!" << endl;
		    exit(1);
		}
		while(!BB.eof()){
			getline(BB, LINE);
			sscanf(LINE.c_str(), "Discretization_level: %hu", &nrOfBins);
			sscanf(LINE.c_str(), "Radius: %hu", &radius);
			sscanf(LINE.c_str(), "Feature_combination: %s %s %s", blockGroupFeatures, blockFeatures, blockEdgeFeatures);
		}
		BB.close();
		if (strcmp(blockGroupFeatures, "") == 0 || strcmp(blockFeatures, "") == 0 || strcmp(blockEdgeFeatures, "") == 0 || nrOfBins == 0 || radius == 0){
			cerr << "Please check the configuration file!\n";
			exit(0);
		}

        int count = 0;
        for (int i = 0; i < 50; i++){
        	 if (blockEdgeFeatures[i] == ',')
        		 count++;
    		 if(blockFeatures[i] == ',')
    			 count++;
        }
        unsigned short sequenceDegree = count + 2;
        unsigned short distance = 2*radius+1;
	    BlockGroupAnnotator ba;
	    string annotatedBBOFile = ba.annotateBlockGroups(acceptBED, rejectBED, testFile, outDir);
        FeatureComputer fc;
        fc.init(annotatedBBOFile,configFile,outDir,nrOfBins);
        GspanCreator gc;
        stringstream s;
        s << blockGroupFeatures << " " << blockFeatures << " " << blockEdgeFeatures;
        string configuration = s.str();
        if(strcmp(gspanFormat, "SIMPLE") == 0)
        	gc.createGspanGraphFormat(configuration, outDir + "/discretized.feat", outDir);
        else if(strcmp(gspanFormat, "SUB") == 0)
        	gc.createGspanSubGraphFormat(configuration, outDir + "/discretized.feat", outDir);
        else if(strcmp(gspanFormat, "PARALLEL") == 0)
        	gc.createParallelSubGraphFormat(configuration, outDir + "/discretized.feat", outDir);
        else if(strcmp(gspanFormat, "PARTSUB") == 0)
        	gc.createPartialSubGraphFormat(configuration, outDir + "/discretized.feat", outDir);
        else if(strcmp(gspanFormat, "SPECIAL") == 0)
        	gc.createGspanSpecialGraphFormat(configuration, outDir + "/discretized.feat", outDir);
        else
        	gc.createGspanFile(configuration, outDir + "/discretized.feat", outDir);

		s.str("");
		s << outDir << "/roc_measures_n_" << nrOfBins << "_r_" << radius << ".out";
        ofstream ROC;
		ROC.open(s.str().c_str());
		if(!ROC.is_open()){
		    cerr << "Error opening file '" << s.str() << "'!!!" << endl;
		    exit(1);
		}
		s.str("");
		if(strcmp(gspanFormat, "SEQUENCE") == 0){
//			radius = sequenceDegree;
			distance = 2*radius+1;
			cout << "Radius: " << radius << "\n" << "Distance: " << distance << "\n" << "Bit size: "<< bitSize << endl;
			s << "EDeN -i "<< outDir <<"/discretized.gspan -f SEQUENCE -M "<<sequenceDegree<< " -b "<< bitSize << " -a MATRIX -r "<<radius<<" -d "<< distance << " -g DIRECTED -y "<<outDir;
		}
		else{
			distance = 2*radius+1;
			cout << "Radius: " << radius << "\n" << "Distance: " << distance << "\n" << "Bit size: "<< bitSize << endl;
			s << "EDeN -i "<< outDir <<"/discretized.gspan -a MATRIX -r "<<radius<<" -d "<<distance << " -b "<< bitSize << " -g DIRECTED -y "<<outDir;
		}
		system(s.str().c_str()); //EDeN command
		s.str("");
		s << outDir<< "/matrix";
    	BlockClust bc;
		bc.roc(s.str().c_str(), fc.getBlockGroupClassMap(), ROC, configuration);
		ROC.close();
    }

    /******************************************************/
    /********************* TRAIN MODE *********************/
    /******************************************************/
    if(strcmp(mode, "TRAIN") == 0){
		cout << "============== TRAINING MODE ==============" << endl;

	    if(trainFile.empty() || validationFile.empty() || acceptBED.empty() || rejectBED.empty() || outDir.empty() || !nrOfBins || !radius ){
	    	fprintf (stderr, "options '-T', '-V', '-a', '-r', '-n', '-R' and '-o' are mandatory in training mode\n");
	    	return 1;
	    }
	    printf ("Blockbuster output	: %s\nAnnotations BED		: %s\n\nReject annotations	: %s\nNr. of bins		: %hu\nRadius			: %hu\nOutput directory	: %s\n\n",
	    	    trainFile.c_str(), acceptBED.c_str(), rejectBED.c_str(), nrOfBins, radius, outDir.c_str());
	    system (("mkdir "+outDir).c_str());

		FeatureComputer v_fc, t_fc;
	    string bgf[v_fc.bg_featFunctionMap.size()];// = new string[v_fc.bg_featFunctionMap.size()];
	    string bf[v_fc.b_featFunctionMap.size()];// = new string[v_fc.b_featFunctionMap.size()];
	    string bef[v_fc.be_featFunctionMap.size()];// = new string[v_fc.be_featFunctionMap.size()];
	    unsigned short i = 0;

		stringstream s;
		v_fc.init(validationFile, outDir, nrOfBins);
		s << outDir << "/bin_boundaries." << nrOfBins;
		t_fc.init(trainFile, s.str().c_str(), outDir, nrOfBins);
		exit(0); // to exit after creating bin boundaries file
		s.str("");

	    for(FeatureComputer::blockGroupFunctionMap::iterator it = v_fc.bg_featFunctionMap.begin(); it != v_fc.bg_featFunctionMap.end(); ++it){
			bgf[i] = it->first;
			i++;
	    }
	    i = 0;
	    for(FeatureComputer::blockFunctionMap::iterator it = v_fc.b_featFunctionMap.begin(); it != v_fc.b_featFunctionMap.end(); ++it){
	    	bf[i] = it->first;
	    	i++;
	    }
	    i = 0;
	    for(FeatureComputer::blockEdgeFunctionMap::iterator it = v_fc.be_featFunctionMap.begin(); it != v_fc.be_featFunctionMap.end(); ++it){
	    	bef[i] = it->first;
	    	i++;
	    }


	    BlockClust bc;

    	vector<string> bgfCombinations;
    	int n = sizeof( bgf ) / sizeof( bgf[0] );
    	for (int r=1; r<=n; r++)
    	  bc.combinations(n, r, bgf, bgfCombinations);

    	vector<string> bfCombinations;
    	n = sizeof( bf ) / sizeof( bf[0] );
    	for (int r=1; r<=n; r++)
    	  bc.combinations(n, r, bf, bfCombinations);

    	vector<string> befCombinations;
    	n = sizeof( bef ) / sizeof( bef[0] );
    	for (int r=1; r<=n; r++)
    		bc.combinations(n, r, bef, befCombinations);

    	vector<string> wholeCombinations;
    	for(unsigned int i=0; i<bgfCombinations.size(); i++){
    		if (std::string::npos == bgfCombinations[i].find("SPE")
    				|| std::string::npos == bgfCombinations[i].find("RLE")
    				|| std::string::npos == bgfCombinations[i].find("GMDX"))
    			continue;
    		for(unsigned int j=0; j<bfCombinations.size(); j++){
        		if (std::string::npos == bfCombinations[j].find("BRLE")
        				|| std::string::npos == bfCombinations[j].find("BMNX"))
					continue;
    			for(unsigned int k=0; k<befCombinations.size(); k++){
    	    		if (std::string::npos == befCombinations[k].find("BC")
    	    				|| std::string::npos == befCombinations[k].find("MDXD")
    	    				|| std::string::npos == befCombinations[k].find("MNXD"))
						continue;
    				string str = "";

    				str.append(bgfCombinations[i]).append(" ").append(bfCombinations[j]).append(" ").append(befCombinations[k]);
    				wholeCombinations.push_back(str);
//    				cout << str << endl;
    			}
    		}
    	}
    	bgfCombinations.clear();
    	bfCombinations.clear();
    	befCombinations.clear();

		s << outDir << "/roc_measures.out";
		ofstream ROC;
		ROC.open(s.str().c_str());
		if(!ROC.is_open()){
		    cerr << "Error opening file '" << s.str() << "'!!!" << endl;
		    exit(1);
		}
		s.str("");

		GspanCreator gc;
		for (unsigned int comb = 0; comb < wholeCombinations.size(); comb++){
			string featCombination = wholeCombinations[comb];

			cout << featCombination << endl;	
			size_t f = featCombination.find(" ");
			while(f != string::npos){
				featCombination.replace(f, string(" ").length(), "_");
				f = featCombination.find(" ",f+1);
			}
			s << outDir << "/" << featCombination;
			system (("mkdir " + s.str()).c_str());
			string featOutDir = s.str();
			s.str("");

			s << wholeCombinations[comb]; //configuration
			cout << s.str() << "\n" << featOutDir << endl;

			string configuration = s.str();

			cout << "Creating gspan file..." <<endl;
			if(strcmp(gspanFormat, "SIMPLE") == 0)
	        	gc.createGspanGraphFormat(configuration, outDir + "/discretized.feat", featOutDir);
	        else if(strcmp(gspanFormat, "SUB") == 0)
	        	gc.createGspanSubGraphFormat(configuration, outDir + "/discretized.feat", featOutDir);
	        else if(strcmp(gspanFormat, "PARALLEL") == 0)
	        	gc.createParallelSubGraphFormat(configuration, outDir + "/discretized.feat", featOutDir);
	        else if(strcmp(gspanFormat, "PARTSUB") == 0)
	        	gc.createPartialSubGraphFormat(configuration, outDir + "/discretized.feat", featOutDir);
	        else
	        	gc.createGspanFile(configuration, outDir + "/discretized.feat", featOutDir);
			cout << "Done" <<endl;
			s.str("");
		    unsigned short distance = 2*radius+1;
			unsigned short sequenceDegree = gc.getSequenceDegree();
			// ********** Changed radius to sequence degree *********** //
			if(strcmp(gspanFormat, "SEQUENCE") == 0){
				radius = sequenceDegree;
				distance = 2*radius+1;
				s << "EDeN -i "<< outDir << "/" << featCombination <<"/discretized.gspan -f SEQUENCE -M "<<sequenceDegree<<" -b "<< bitSize << " -a MATRIX -r "<<radius<<" -d "<< distance << " -g DIRECTED -y "<<outDir<< "/" << featCombination;
			}
			else{
				s << "EDeN -i "<<outDir << "/" << featCombination<<"/discretized.gspan -a MATRIX -r "<<radius<<" -d "<<distance << " -b "<< bitSize << " -g DIRECTED -y "<<outDir<< "/" << featCombination;
			}
			system(s.str().c_str()); //EDeN call
			s.str("");
			s << outDir<< "/" << featCombination<<"/matrix";
			stringstream config;
			config << "n_" << nrOfBins << "_r_" << radius << "_" << featCombination;
			float avgROC = bc.roc(s.str().c_str(), t_fc.getBlockGroupClassMap(), ROC, config.str());
			config.str("");
			s.str("");
			if(bestROC < avgROC){
				bestROC = avgROC;
			}
			else{
				s << "rm -r " << outDir<< "/" << featCombination;
				system(s.str().c_str());
			}
			s.str("");
		}
		ROC.close();
    }
    return 0;
}

/////////////////////////////////////////////

void BlockClust::combinations(int n, int r, string s[], vector<string> &f){
   vector<bool> v(n);
   fill(v.begin() + r, v.end(), true);
   do{
       stringstream ss;
       for (int i = 0; i < n; ++i){
           if (!v[i])
        	   ss << "," << s[i];
       }
       f.push_back(ss.str().erase(0,1));
   } while (next_permutation(v.begin(), v.end()));
   v.clear();
}

/////////////////////////////////////////////

float BlockClust::roc(const char* similarityMatrix, map<int, string> blockGroupClassMap, ofstream &ROC, string config){
	ifstream SIM;
	SIM.open (similarityMatrix);
	if(!SIM.is_open()){
	    cerr << "Error opening file '" << similarityMatrix << "'!!!" << endl;
	    exit(1);
	}
	int count=1;
	float rocs[blockGroupClassMap.size()];
	unsigned int knownBGCount = 0;
	map <string, vector<float> > annoationRocs;
	string LINE;
	ofstream TEMP;
	while(!SIM.eof()){
		getline(SIM, LINE);
		if(LINE == "")
			continue;
		vector<string> fields = split(" ", LINE);
		string rowClass = blockGroupClassMap.find(count)->second;
		stringstream scount;
		scount << ":" << count;
		size_t f = rowClass.find(scount.str());
		while(f != string::npos){
			rowClass.replace(f, rowClass.length(), "");
			f = rowClass.find(scount.str());
		}
	    map<float, map<int, string> > similaritiesMap;
		for(unsigned int i=0; i<fields.size(); i++){
			similaritiesMap[atof(fields[i].c_str())][i] = blockGroupClassMap.find(i+1)->second;
		}
		scount.str("");
		map<float, map<int, string> >::iterator it1;
		map<int, string>::iterator it2;
		string similarities = "";
		for(it1 = similaritiesMap.begin(); it1 != similaritiesMap.end(); ++it1){
			int cnt = 1;
			stringstream sim;
			sim << it1->first;
			for(it2 = it1->second.begin(); it2 != it1->second.end(); ++it2){
				string fieldClass = it2->second;
				size_t f = fieldClass.find(":");
				while(f != string::npos){
					fieldClass.replace(f, fieldClass.length(), "");
					f = fieldClass.find(":");
				}
				if(fieldClass == rowClass){
					similarities.append("1").append(" ").append(sim.str()).append("\n");
				}
				else{
					similarities.append("0").append(" ").append(sim.str()).append("\n");
				}
			}
		    cnt++;
			sim.clear();
		}
		stringstream temp;
		temp << similarityMatrix <<"."<< count << ".rocin";
		TEMP.open(temp.str().c_str());
		if(!TEMP.is_open()){
		    cerr << "Error opening file '" << temp.str().c_str() << "'!!!" << endl;
		    exit(1);
		}
		TEMP << similarities;
		TEMP.close();
		stringstream cmd;
		cmd << "perf -ROC < " << temp.str().c_str();
	    FILE* pipe = popen(cmd.str().c_str(), "r");
	    if (!pipe) fprintf (stderr, "ERROR");
	    char buffer[128];
	    std::string result = "";
	    while(!feof(pipe)){
	    	if(fgets(buffer, 128, pipe) != NULL)
	    		result += buffer;
	    }
	    pclose(pipe);
	    cmd.str("");
	    cmd << "rm " << temp.str().c_str();
	    system(cmd.str().c_str());
	    cmd.str("");
	    temp.str("");
	    float roc;
	    sscanf(result.c_str(), "ROC\t%f\n", &roc);
//	    if(rowClass != "unknown"){
	    	rocs[knownBGCount] = roc;
	    	knownBGCount++;
//	    }
	    annoationRocs[rowClass].push_back(roc);
		count++;
	}
	SIM.close();

	float sum = 0;
	map<string, vector<float> >::iterator it;
	for(it = annoationRocs.begin(); it != annoationRocs.end(); ++it){
		string annotation = it->first;
		for (unsigned int i=0; i<it->second.size(); i++){
			sum += it->second[i];
		}
		float annotationAvgROC = sum/it->second.size();
		ROC << annotationAvgROC << "\t" << it->second.size() << "\t" << annotation << "\t" << config << endl;
		cout << annotationAvgROC << "\t" << it->second.size() << "\t" << annotation << "\t" << config << endl;
		sum=0;
	}
	sum=0;

	for(unsigned int i=0; i<knownBGCount; i++){
		sum += rocs[i];
	}

	cout << "Sum: " << sum << "\tNr: " << knownBGCount << endl;

	float avgROC = sum/knownBGCount;

	ROC << avgROC << "\t" << knownBGCount << "\tAverage\t" << config << endl;
	cout << avgROC << "\t" << knownBGCount << "\tAverage\t" << config << endl;
	annoationRocs.clear();
	return avgROC;
}

/////////////////////////////////////////////

vector<string> BlockClust::split(const string& delim, const string& str){
	std::size_t start_pos = 0;
	std::size_t match_pos;
	std::size_t substr_length;
	vector<string> result;
	while((match_pos = str.find(delim, start_pos)) != string::npos){
		substr_length = match_pos - start_pos;
		if (substr_length > 0){
			result.push_back(str.substr(start_pos, substr_length));
		}
		start_pos = match_pos + delim.length();
	}
	substr_length = str.length() - start_pos;
	if (substr_length > 0){
		result.push_back(str.substr(start_pos, substr_length));
	}
	return result;
}


string BlockClust::generateRandomColor(){
	int ints[2] = {0};
	srand( (unsigned)time(NULL) );
	for (int i=0; i < 3 ; i++)
			ints[i] = ( rand() % 256 );
	stringstream color;
	color <<hex << ints[0] << hex << ints[1] << hex << ints[2];
	return color.str();
}

