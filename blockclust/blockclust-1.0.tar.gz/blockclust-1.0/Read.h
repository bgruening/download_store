/*
 * Read.h
 *
 *  Created on: Nov 9, 2012
 *      Author: videmp
 */

#ifndef TAG_H_
#define TAG_H_
#include <string>
using namespace std;

class Read{
	public:
		Read();
		Read(string rdId, unsigned long rdStart, unsigned long rdEnd, double rdExpression);
		virtual ~Read();
		string getId();
		unsigned long getStart();
		unsigned long getEnd();
		unsigned short getLength();
		double getExpression();
		double getArea();
	private:
		string readId;
		unsigned long readStart;
		unsigned long readEnd;
		double readExpression;
};

#endif /* TAG_H_ */
