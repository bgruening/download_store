/*
 * Read.cpp
 *
 *  Created on: Nov 9, 2012
 *      Author: videmp
 */

#include "Read.h"

Read::Read(){
	readId  = "";
	readStart = 0;
	readEnd = 0;
	readExpression = 0;
}

Read::Read(string rdId, unsigned long rdStart, unsigned long rdEnd, double rdExpression){
	readId = rdId;
	readStart = rdStart;
	readEnd = rdEnd;
	readExpression = rdExpression;

}

Read::~Read(){
	// TODO Auto-generated destructor stub
}

string Read::getId(){ return readId; }
unsigned long Read::getStart(){ return readStart; }
unsigned long Read::getEnd(){ return readEnd; }
unsigned short Read::getLength(){ return readEnd - readStart +1; }
double Read::getExpression(){ return readExpression; }
double Read::getArea(){ return getLength()*getExpression(); }

