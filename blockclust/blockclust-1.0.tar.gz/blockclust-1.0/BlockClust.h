/*
 * BlockClust.h
 *
 *  Created on: Nov 9, 2012
 *      Author: videmp
 */

#ifndef BLOCKCLUST_H_
#define BLOCKCLUST_H_
#include <string>
#include <sstream>
#include "algorithm"
#include <iostream>
#include <time.h>
#include "BlockGroup.h"
#include "FeatureComputer.h"
#include "GspanCreator.h"
#include "BlockGroupAnnotator.h"
using namespace std;

//typedef double (BlockGroup::*blockGroupFeat)();
//typedef double (Block::*blockFeat)();
//typedef double (BlockEdge::*blockEdgeFeat)();
//typedef std::map<std::string, blockGroupFeat> blockGroupFeat_map;
//typedef std::map<std::string, blockFeat> blockFeat_map;
//typedef std::map<std::string, blockEdgeFeat> blockEdgeFeat_map;


class BlockClust{
public:
	BlockClust();
	virtual ~BlockClust();
	void combinations(int n, int r, string s[], vector<string> &f);
	float roc(const char* similarityMatrix, map <int, string> blockGroupClassMap, ofstream &ROC, string config);
	vector<string> split(const string& delim, const string& str);
	string generateRandomColor();
//	map<string, blockGroupFeat> getBG_featFunctionMap();
//	map<string, blockFeat> getB_featFunctionMap();
//	map<string, blockEdgeFeat> getBE_featFunctionMap();

private:
//	map<string, blockGroupFeat> bg_featFunctionMap;
//	map<string, blockFeat> b_featFunctionMap;
//	map<string, blockEdgeFeat> be_featFunctionMap;

};

#endif /* BLOCKCLUST_H_ */
