#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Long;
use Cwd 'abs_path';
use Pod::Usage;
use FindBin '$Bin';
use List::Util qw(sum);

=head1 NAME

BlockClustPipeLine.pl

=head1 SYNOPSIS

perl BlockClustPipeLine.pl -m [test/train] -a [annotations BED file] -c [configuration string] -T [test file] -od [output directory] 

=head1 OPTIONS

		-help		brief help message
		-man		full documentation
		-m			mode of run
		-a			file of annotations
		-c			configuration file
		-t			train input file
		-V			validation input file
		-T			test input file
		-o			output directory
                        
=head1 DESCRIPTION
         
=cut

my ($help, $man, $mode, $accept_annotations_bed, $reject_annotations_bed, $model_accept_annotations_bed, $model_reject_annotations_bed, $train_file, $test_file, $validation_file, $config_file, $predict, $nr_of_bins, $radius, $gspan_format, $output_dir, $nr_nearest_neightbors, $model_dir, $cmsearch_out, $clusters_bed, $bam, $tags_bed, $sim_tab, $rfam_map_file);

$nr_of_bins = 3;
$radius = 1;
$gspan_format = "SEQUENCE";

my $options = GetOptions ("help"        => \$help,
                         "man"          => \$man,
                         "m=s"			=> \$mode,
                         "a=s"      	=> \$accept_annotations_bed,
                         "r=s"      	=> \$reject_annotations_bed,
			 			 "T=s"			=> \$train_file,
			 			 "t=s"        	=> \$test_file,
			 			 "V=s"			=> \$validation_file,
                         "c=s"			=> \$config_file,
                         "n=i"			=> \$nr_of_bins,
                         "x=i"			=> \$nr_nearest_neightbors,
                         "Rd=i"			=> \$radius,
                         "p"			=> \$predict,
                         "f=s"			=> \$gspan_format,
                         "o=s"			=> \$output_dir,
                         "md=s"			=> \$model_dir,
                         "ma=s"      	=> \$model_accept_annotations_bed,
                         "mr=s"      	=> \$model_reject_annotations_bed,
                         "cm=s"			=> \$cmsearch_out,
                         "cbed=s"		=> \$clusters_bed,
                         "bam=s"        => \$bam,
                         "tbed=s"       => \$tags_bed,
                         "tab=s"        => \$sim_tab,
                         "rfam=s"       => \$rfam_map_file
			);

pod2usage(-exitstatus => 0, -verbose => 2) if $man;

trim(\$test_file) if($test_file); trim(\$train_file) if($train_file); trim(\$validation_file) if($validation_file); 
trim(\$accept_annotations_bed) if($accept_annotations_bed); trim(\$reject_annotations_bed) if($reject_annotations_bed);
trim(\$config_file) if($config_file); trim(\$output_dir) if($output_dir); 

if(!$mode){
	print STDERR "option '-m' is mandatory\n";
	exit 1;
}

if($mode ne "TRAIN" && $mode ne "TEST" && $mode ne "POST" && $mode ne "PRE"){
	print STDERR "From script Option -m can be one of the 'TRAIN', 'TEST', 'PRE' and 'POST' \n";
	exit 1;
}

if($mode eq "TEST" || $mode eq "POST" ){
    $output_dir = abs_path($output_dir);
    if($predict){
	    $model_dir = abs_path($model_dir);
    }

    if(!$output_dir || $output_dir eq ""){
	    $output_dir = `echo -n blockclust_\$(date +%d%m%Y_%H%M%S)`;
    }

    if($output_dir eq $Bin || $output_dir =~ m/^-/) {
	    print STDERR "Please choose a different output directory\n";
	    exit 1;
    }
}


if($mode eq "TEST"){
	if(!$test_file || !$config_file || !$accept_annotations_bed || !$reject_annotations_bed ||
		$test_file eq "" || $config_file eq "" || $accept_annotations_bed eq "" || $reject_annotations_bed eq ""){
	   	print STDERR "Options '-t', '-a', '-r' and '-c' are mandatory in test mode\n";
	   	exit 1;
	}

	if($predict && !$model_dir){
		print STDERR "Please provide model directory '-md' along with option '-p'\n";
		exit 1;
	}
	if($predict && $model_dir eq $Bin) {
		print STDERR "Please choose a different model directory\n";
		exit 1;
	}
######### BlockClust call ############
	system("$Bin/BlockClust -m TEST -a $accept_annotations_bed -r $reject_annotations_bed -c $config_file -o $output_dir -t $test_file -f $gspan_format");  
	if ($? >> 8 != 0) {
    	print STDERR "============= BlockClust run terminated =============\n\n";
    	exit 1;
	}
	
	open ANNOT, "$output_dir/blockgroup_annotations.txt" or die $!;	
	my $count = 1;
	my %bgo = ();
	while(<ANNOT>){
		chomp($_);
		my @f = split('\t', $_);
		$bgo{$count} = "$f[1]:$f[0]";
		$count++;
	}
	close ANNOT;

	$count = 1;
	open MTX, "$output_dir/discretized.gspan.mtx" or die $!;
	open TAB, ">$output_dir/discretized.gspan.tab" or die $!;
	while(<MTX>){
		chomp($_);
		my @f = split('\s+', $_);
		for(my $j=0;$j<=$#f;$j++){
			print TAB $count,":",$bgo{$count},"\t",$j+1,":",$bgo{$j+1},"\t",$f[$j],"\n";
		}
		$count++;
	}
	close MTX;
	close TAB;

	if($predict){
		print "Performing classification\n";
		my $sequence_degree=`grep Feature_combination: $config_file| awk -F ' ' '{print \$3","\$4}' | grep -o ','|wc -l`;
		$sequence_degree++;

		my $radius=`grep -P 'Radius: [0-9]*' $config_file`;
		chomp($radius);
		$radius =~ s/Radius: //;
		my $distnce = 2*$radius+1; 
		
		
#		system("$Bin/BlockClust -m TEST -a $model_accept_annotations_bed -r $model_reject_annotations_bed -c $config_file -o $model_dir -t $model_dir/model.bbo -f $gspan_format");
		my $train_size = `wc -l < $model_dir/blockgroup_annotations.txt`;
		chomp($train_size);
			
		print "train size: ",$train_size,"\n";

		my $test_size = `wc -l < $output_dir/blockgroup_annotations.txt`;
		chomp($test_size);
		
		$train_size--;

		system "cat $model_dir/discretized.gspan $output_dir/discretized.gspan > $output_dir/input.gspan";
		system "cat $model_dir/blockgroup_annotations.txt $output_dir/blockgroup_annotations.txt > $output_dir/input.blockgroup_annotations.txt";
		system "awk '{if(\$2==\"miRNA\") print \"1\"; if(\$2==\"tRNA\") print \"2\";if(\$2==\"snoRNA\") print \"3\"; if(\$2==\"snoRNA_CD-box\") print \"3\";if(\$2==\"snoRNA_HACA-box\") print \"4\";if(\$2==\"snoRNA_scaRNA\") print \"5\";if(\$2==\"snRNA\") print \"6\";if(\$2==\"rRNA\") print \"7\";if(\$2==\"Y_RNA\") print \"8\";if(\$2==\"unknown\") print \"9\";}' $output_dir/input.blockgroup_annotations.txt > $output_dir/input.target";

		system "awk 'BEGIN {c=-1;} {c+=1;print c}' $model_dir/blockgroup_annotations.txt > $output_dir/train.ids";
		system "v=$train_size;awk -v c=\$v '{c+=1;print c}' $output_dir/blockgroup_annotations.txt > $output_dir/test.ids";

		# EDeN nearest neighbors
		system "EDeN -g DIRECTED -t $output_dir/input.target -A $output_dir/test.ids -B $output_dir/train.ids -a NEAREST_NEIGHBOR -i $output_dir/input.gspan -f SEQUENCE -r $radius -d $distnce -M $sequence_degree -x $nr_nearest_neightbors";
		
		$train_size++;
		system ("head -$train_size $output_dir/input.target > $output_dir/train.target");
		system ("tail -$test_size $output_dir/input.target > $output_dir/test.target");

		system "mkdir $output_dir/miRNA" if(!-d "$output_dir/miRNA");
		system "mkdir $output_dir/tRNA" if(!-d "$output_dir/tRNA");
		system "mkdir $output_dir/CD-box" if(!-d "$output_dir/CD-box");
		system "mkdir $output_dir/HACA-box" if(!-d "$output_dir/HACA-box");
		system "mkdir $output_dir/rRNA" if(!-d "$output_dir/rRNA");
				
		print "NEAREST NEIGHBOR PREDICTION:\n";

		system "sed 's/2/-1/; s/3/-1/; s/4/-1/; s/5/-1/; s/6/-1/; s/7/-1/; s/8/-1/; s/9/-1/;' $output_dir/test.target > $output_dir/miRNA/miRNA.test.target";
		system "sed 's/2/-1/; s/3/-1/; s/4/-1/; s/5/-1/; s/6/-1/; s/7/-1/; s/8/-1/; s/9/-1/;' $output_dir/train.target > $output_dir/miRNA/miRNA.train.target";
		system "awk '{ if(\$2!=1) \$2=-1;if(\$3!=1) \$3=-1; if(\$4!=1) \$4=-1;  print \$0}' $output_dir/input.gspan.knn_target_value | awk '{print (\$2+\$3+\$4)/3}' > $output_dir/miRNA/miRNA.nn.temp";
		system "paste $output_dir/miRNA/miRNA.test.target $output_dir/miRNA/miRNA.nn.temp > $output_dir/miRNA/miRNA.nn.perf.in";
		print "miRNA:\n";
		system "perf -PRF -SEN -PPV -NPV -ROC -SPC -ACC -PRE -REC -t 0.5 < $output_dir/miRNA/miRNA.nn.perf.in | tee $output_dir/miRNA.nn.out";

		system "sed 's/1/-1/; s/3/-1/; s/4/-1/; s/5/-1/; s/6/-1/; s/7/-1/; s/8/-1/; s/9/-1/; s/2/1/;' $output_dir/test.target > $output_dir/tRNA/tRNA.test.target";
		system "sed 's/1/-1/; s/3/-1/; s/4/-1/; s/5/-1/; s/6/-1/; s/7/-1/; s/8/-1/; s/9/-1/; s/2/1/;' $output_dir/train.target > $output_dir/tRNA/tRNA.train.target";
		system "awk '{ if(\$2!=2) \$2=-1;if(\$3!=2) \$3=-1; if(\$4!=2) \$4=-1; if(\$2==2) \$2=1;if(\$3==2) \$3=1; if(\$4==2) \$4=1; print \$0}' $output_dir/input.gspan.knn_target_value | awk '{print (\$2+\$3+\$4)/3}' > $output_dir/tRNA/tRNA.nn.temp";
		system "paste $output_dir/tRNA/tRNA.test.target $output_dir/tRNA/tRNA.nn.temp > $output_dir/tRNA/tRNA.nn.perf.in";
		print "tRNA:\n";
		system "perf -PRF -SEN -PPV -NPV -ROC -SPC -ACC -PRE -REC -t 0.5 < $output_dir/tRNA/tRNA.nn.perf.in | tee $output_dir/tRNA.nn.out";

		system "sed 's/1/-1/; s/2/-1/; s/4/-1/; s/5/-1/; s/6/-1/; s/7/-1/; s/8/-1/; s/9/-1/; s/3/1/;' $output_dir/test.target > $output_dir/CD-box/CD-box.test.target";
		system "sed 's/1/-1/; s/2/-1/; s/4/-1/; s/5/-1/; s/6/-1/; s/7/-1/; s/8/-1/; s/9/-1/; s/3/1/;' $output_dir/train.target > $output_dir/CD-box/CD-box.train.target";
		system "awk '{ if(\$2!=3) \$2=-1;if(\$3!=3) \$3=-1; if(\$4!=3) \$4=-1; if(\$2==3) \$2=1;if(\$3==3) \$3=1; if(\$4==3) \$4=1; print \$0}' $output_dir/input.gspan.knn_target_value | awk '{print (\$2+\$3+\$4)/3}' > $output_dir/CD-box/CD-box.nn.temp";
		system "paste $output_dir/CD-box/CD-box.test.target $output_dir/CD-box/CD-box.nn.temp > $output_dir/CD-box/CD-box.nn.perf.in";
		print "CD-box:\n";
		system "perf -PRF -SEN -PPV -NPV -ROC -SPC -ACC -PRE -REC -t 0.5 < $output_dir/CD-box/CD-box.nn.perf.in | tee $output_dir/CD-box.nn.out";

		system "sed 's/1/-1/; s/2/-1/; s/3/-1/; s/5/-1/; s/6/-1/; s/7/-1/; s/8/-1/; s/9/-1/; s/4/1/;' $output_dir/test.target > $output_dir/HACA-box/HACA-box.test.target";
		system "sed 's/1/-1/; s/2/-1/; s/3/-1/; s/5/-1/; s/6/-1/; s/7/-1/; s/8/-1/; s/9/-1/; s/4/1/;' $output_dir/train.target > $output_dir/HACA-box/HACA-box.train.target";
		system "awk '{ if(\$2!=4) \$2=-1;if(\$3!=4) \$3=-1; if(\$4!=4) \$4=-1; if(\$2==4) \$2=1;if(\$3==4) \$3=1; if(\$4==4) \$4=1; print \$0}' $output_dir/input.gspan.knn_target_value | awk '{print (\$2+\$3+\$4)/3}' > $output_dir/HACA-box/HACA-box.nn.temp";
		system "paste $output_dir/HACA-box/HACA-box.test.target $output_dir/HACA-box/HACA-box.nn.temp > $output_dir/HACA-box/HACA-box.nn.perf.in";
		print "HACA-box:\n";
		system "perf -PRF -SEN -PPV -NPV -ROC -SPC -ACC -PRE -REC -t 0.5 < $output_dir/HACA-box/HACA-box.nn.perf.in | tee $output_dir/CD-box.nn.out";		
				
		system "sed 's/1/-1/; s/2/-1/; s/3/-1/; s/4/-1/; s/5/-1/; s/6/-1/; s/8/-1/; s/9/-1/; s/7/1/;' $output_dir/test.target > $output_dir/rRNA/rRNA.test.target";
		system "sed 's/1/-1/; s/2/-1/; s/3/-1/; s/4/-1/; s/5/-1/; s/6/-1/; s/8/-1/; s/9/-1/; s/7/1/;' $output_dir/train.target > $output_dir/rRNA/rRNA.train.target";
		system "awk '{ if(\$2!=7) \$2=-1;if(\$3!=7) \$3=-1; if(\$4!=7) \$4=-1; if(\$2==7) \$2=1;if(\$3==7) \$3=1; if(\$4==7) \$4=1; print \$0}' $output_dir/input.gspan.knn_target_value | awk '{print (\$2+\$3+\$4)/3}' > $output_dir/rRNA/rRNA.nn.temp";
		system "paste $output_dir/rRNA/rRNA.test.target $output_dir/rRNA/rRNA.nn.temp > $output_dir/rRNA/rRNA.nn.perf.in";
		print "rRNA:\n";
		system "perf -PRF -SEN -PPV -NPV -ROC -SPC -ACC -PRE -REC -t 0.5 < $output_dir/rRNA/rRNA.nn.perf.in | tee $output_dir/rRNA.nn.out";

		print "\n=======================================================\n\n";

		print "CLASSIFICATION:\n";
				
		system "cp $output_dir/discretized.gspan $output_dir/miRNA/discretized.gspan";
		system "EDeN -g DIRECTED -i $model_dir/discretized.gspan -f SEQUENCE -M 3 -r 3 -d 7 -a TRAIN -m $model_dir/miRNA.model -t $output_dir/miRNA/miRNA.train.target";
		system "EDeN -g DIRECTED -i $output_dir/miRNA/discretized.gspan -f SEQUENCE -M 3 -r 3 -d 7 -a TEST -m $model_dir/miRNA.model";
		system "paste $output_dir/miRNA/miRNA.test.target $output_dir/miRNA/discretized.gspan.prediction | awk '{print \$1\"\t\"\$3}' > $output_dir/miRNA/miRNA.pred.perf.in";
		
		system "cp $output_dir/discretized.gspan $output_dir/tRNA/discretized.gspan";
		system "EDeN -g DIRECTED -i $model_dir/discretized.gspan -f SEQUENCE -M 3 -r 3 -d 7 -a TRAIN -m $model_dir/tRNA.model -t $output_dir/tRNA/tRNA.train.target";
		system "EDeN -g DIRECTED -i $output_dir/tRNA/discretized.gspan -f SEQUENCE -M 3 -r 3 -d 7 -a TEST -m $model_dir/tRNA.model";
		system "paste $output_dir/tRNA/tRNA.test.target $output_dir/tRNA/discretized.gspan.prediction | awk '{print \$1\"\t\"\$3}' > $output_dir/tRNA/tRNA.pred.perf.in";
		
		system "cp $output_dir/discretized.gspan $output_dir/CD-box/discretized.gspan";
		system "EDeN -g DIRECTED -i $model_dir/discretized.gspan -f SEQUENCE -M 3 -r 3 -d 7 -a TRAIN -m $model_dir/CD-box.model -t $output_dir/CD-box/CD-box.train.target";
		system "EDeN -g DIRECTED -i $output_dir/CD-box/discretized.gspan -f SEQUENCE -M 3 -r 3 -d 7 -a TEST -m $model_dir/CD-box.model";
		system "paste $output_dir/CD-box/CD-box.test.target $output_dir/CD-box/discretized.gspan.prediction | awk '{print \$1\"\t\"\$3}' > $output_dir/CD-box/CD-box.pred.perf.in";

		system "cp $output_dir/discretized.gspan $output_dir/HACA-box/discretized.gspan";
		system "EDeN -g DIRECTED -i $model_dir/discretized.gspan -f SEQUENCE -M 3 -r 3 -d 7 -a TRAIN -m $model_dir/HACA-box.model -t $output_dir/HACA-box/HACA-box.train.target";
		system "EDeN -g DIRECTED -i $output_dir/HACA-box/discretized.gspan -f SEQUENCE -M 3 -r 3 -d 7 -a TEST -m $model_dir/HACA-box.model";
		system "paste $output_dir/HACA-box/HACA-box.test.target $output_dir/HACA-box/discretized.gspan.prediction | awk '{print \$1\"\t\"\$3}' > $output_dir/HACA-box/HACA-box.pred.perf.in";

		system "cp $output_dir/discretized.gspan $output_dir/rRNA/discretized.gspan";
		system "EDeN -g DIRECTED -i $model_dir/discretized.gspan -f SEQUENCE -M 3 -r 3 -d 7 -a TRAIN -m $model_dir/rRNA.model -t $output_dir/rRNA/rRNA.train.target";
		system "EDeN -g DIRECTED -i $output_dir/rRNA/discretized.gspan -f SEQUENCE -M 3 -r 3 -d 7 -a TEST -m $model_dir/rRNA.model";
		system "paste $output_dir/rRNA/rRNA.test.target $output_dir/rRNA/discretized.gspan.prediction | awk '{print \$1\"\t\"\$3}' > $output_dir/rRNA/rRNA.pred.perf.in";		

		print "miRNA:\n";
		system "perf -PRF -SEN -PPV -NPV -ROC -SPC -ACC -PRE -REC -t 0.5 < $output_dir/miRNA/miRNA.pred.perf.in | tee $output_dir/miRNA.pred.out";
		print "tRNA:\n";
		system "perf -PRF -SEN -PPV -NPV -ROC -SPC -ACC -PRE -REC -t 0.5 < $output_dir/tRNA/tRNA.pred.perf.in | tee $output_dir/tRNA.pred.out";
		print "CD-box:\n";
		system "perf -PRF -SEN -PPV -NPV -ROC -SPC -ACC -PRE -REC -t 0.5 < $output_dir/CD-box/CD-box.pred.perf.in | tee $output_dir/CD-box.pred.out";
		print "HACA-box:\n";
		system "perf -PRF -SEN -PPV -NPV -ROC -SPC -ACC -PRE -REC -t 0.5 < $output_dir/HACA-box/HACA-box.pred.perf.in | tee $output_dir/HACA-box.pred.out";
		print "rRNA:\n";
		system "perf -PRF -SEN -PPV -NPV -ROC -SPC -ACC -PRE -REC -t 0.5 < $output_dir/rRNA/rRNA.pred.perf.in | tee $output_dir/rRNA.pred.out";
	}

	else{
		print "=========================================================\n";
		print "Performing clustering. Use option -p for classification\n";
		print "$output_dir/blockgroup_annotations.txt";
		open ANNOT, "$output_dir/blockgroup_annotations.txt" or die $!;
		open COL, ">$output_dir/blockgroup_colors.txt" or die $!;
		my %blockgroup_colors_hash;
		my %colors_list;
		while(<ANNOT>){
			my ($id, $annotation) = split('\t', $_);
			if(exists $blockgroup_colors_hash{$annotation}){
				print COL "$id\trange\t$blockgroup_colors_hash{$annotation}\t$annotation";
			}
			else{
				my $red = rand(255);
				my $green = rand(255);
				my $blue = rand(255);
				L: my $hexcolor=sprintf("#%2.2X%2.2X%2.2X",$red,$green,$blue);
				if(exists $colors_list{$hexcolor}){
					goto L;
				}
				else {
					$blockgroup_colors_hash{$annotation} = $hexcolor;
					$colors_list{$hexcolor}++;
				}		
			}
		}
		close COL;
		close ANNOT;
		
		open ANNOT, "$output_dir/blockgroup_annotations.txt" or die $!;
		my %annotations_hash = ();
		my $count = 1;
		while(<ANNOT>){
			my ($id, $annotation) = split('\t', $_);
			$annotations_hash{$count} = $id;
			$count++; 
		}
		close ANNOT;
		
		open MTX, "$output_dir/discretized.gspan.mtx" or die $!;
		open OMTX, ">$output_dir/hclust_tree.mtx" or die $!;
		$count = 1;
		while(<MTX>){
			my $line = $_;
			chomp($line);
			my $new_line = $annotations_hash{$count}." ";
			$new_line .= $line;
			print OMTX $new_line,"\n";
			$count++;
		}
		close MTX;
		close OMTX;
		
		system "Rscript $Bin/plotClusters.R clust $output_dir/hclust_tree.mtx $output_dir/blockgroup_annotations.txt $output_dir/hclust_tree.pdf";

		## MCL clustering
		system "mcl $output_dir/discretized.gspan.tab --abc -pi 20 -I 20 -o $output_dir/mcl.out 2> $output_dir/mcl.log";

		my $test_file_name = `filename=\$(basename $test_file);filename="\${filename%.*}";echo -n \$filename`;
		
		extractMCLClusters();
	}
	print "============= DONE ============\n\n";
	
}

if($mode eq "TRAIN"){
	if(!$train_file ||!$validation_file || !$accept_annotations_bed || !$reject_annotations_bed || !$output_dir){
        print STDERR "options '-T', '-V', '-a', '-R' and '-o' are mandatory in testing mode\n";
        exit 0;
	}
	system "$Bin/BlockClust -m TRAIN -T $train_file -V $validation_file -a $accept_annotations_bed -r $reject_annotations_bed -n $nr_of_bins -R $radius -o $output_dir";
}

if($mode eq "PRE"){
    if(!$bam || !$tags_bed ){
        print STDERR "options '-bam', '-tbed' are mandatory in pre-processing mode\n";
        exit 0;
    }
    open SAM, "samtools view $bam |" || die "cannot open $bam: $!\n";
    my %tags = ();
    while(<SAM>){
        next if($_ =~ m/^@|\tchrM\t/);
        chomp;
        my @f = split('\t',$_);
        next if ($_ =~ /^[@]/ || $f[2] eq "*");
        my $id = $f[0];
        my $flag = $f[1];
        my $chrom = $f[2];
        my $start = $f[3]; $start--;
        my $cigar = $f[5];
        my $seqence = $f[9];
        my $end = $start;
        my $strand; 
        if($flag == 0){
            $strand = "+";
        }
        elsif($flag == 16){
            $strand = "-";
            $seqence = reverseComplement($seqence);
        }
        else{
            print STDERR "Warning: flag '$flag' found!\n";
            next;
        }

        $cigar =~ s/(\d+)[MD]/$end+=$1/eg;
        my $pos = "$chrom\t$start\t$end\t$strand";

        $tags{$seqence}{"seq"}++;
        $tags{$seqence}{"read_id"}{$id}++;
        $tags{$seqence}{"pos"}{$pos}++;
    }
    close SAM;

    my $tag_id = 1;
    open OUT, ">$tags_bed" or die $!;
    foreach my $seq(keys %tags){
        my $nr_of_mappings = $tags{$seq};
        my $nr_of_loci = keys %{$tags{$seq}{"pos"}};
        my $read_count = keys %{$tags{$seq}{"read_id"}};
        my $normalized_count = sprintf("%.6f", $read_count/$nr_of_loci);
        foreach my $pos(keys %{$tags{$seq}{"pos"}}){
            my ($chrom,$start,$end,$strand) = split('\t', $pos);
            print OUT "$chrom\t",$start,"\t",$end,"\ttag_$tag_id|$read_count|$nr_of_loci\t",$normalized_count,"\t$strand\n";
            $tag_id++;
        }
    }
    close OUT;
}

if($mode eq "POST"){
	if(!$cmsearch_out || !$clusters_bed || !$output_dir){
        print STDERR "options '-cm', '-o' are mandatory in post-processing mode\n";
        exit 0;
	}

	my %clusterSizeHash = ();
	my %clusterEntriesHash = ();
	open BED, $clusters_bed or die $!;
	while(<BED>){
		my @f = split('\t', $_);
		my @cf = split(':', $f[3]);
		$clusterSizeHash{$cf[3]}++;
		push(@{$clusterEntriesHash{$cf[3]}}, $cf[0].":".$cf[1].":".$cf[2]);
	}
	close BED;

	my %rfamHash = ();
	open RFAM, $rfam_map_file or die $!;
	while(<RFAM>){
		my @f = split('\t', $_);
		$rfamHash{$f[0]} = $f[1];
	}
	close RFAM;
	
	my %cmsHash = ();
	my %uniqFoundHash = ();
	## process cmsearch output
	open CMS, $cmsearch_out or die $!;
	while(<CMS>){
		chomp($_);
		my @fields = split('\s+', $_);
		next if($fields[15] > 0.01);
		my @disc_fields = split(':', $fields[18]);
		my $cluster_id = $disc_fields[3];
		next if(exists $uniqFoundHash{$cluster_id}{$fields[0]});
		$cmsHash{$cluster_id}{$rfamHash{$fields[3]}}++;
		$uniqFoundHash{$cluster_id}{$fields[0]}++;
	}
	close CMS;
	
	my %clusterAnalysisHash = ();
	my $sum = 0;
	foreach my $cluster (sort keys %clusterSizeHash){
		my $cluster_size = $clusterSizeHash{$cluster};
		my $known_instances = 0;
		foreach my $rfam_class (keys %{$cmsHash{$cluster}}){
			#my $class_fraction = $cmsHash{$cluster}{$rfam_class}/$cluster_size;
			#$class_fraction = int($class_fraction + 0.5);
			#print $cluster,"\t",$rfam_class,"\t",$cmsHash{$cluster}{$rfam_class},"\n";
			$clusterAnalysisHash{$cluster}{$rfam_class} += $cmsHash{$cluster}{$rfam_class};
		}
		$known_instances = keys %{$uniqFoundHash{$cluster}};
		my $unknown_instances = $cluster_size - $known_instances;
		$clusterAnalysisHash{$cluster}{'unknown'} = $unknown_instances;
		#print $cluster,"\t",$known_instances+$unknown_instances,"\t",$known_instances,"\n";
	}
	open OUT, ">$output_dir/cluster_distribution.txt" or die $!;
	print OUT "Clusters\tRNA_type\n";
	foreach my $cluster (sort keys %clusterAnalysisHash){
		foreach my $class (keys %{$clusterAnalysisHash{$cluster}}){
		    next if($clusterAnalysisHash{$cluster}{$class} <= 0);
            for(my  $i=0; $i<$clusterAnalysisHash{$cluster}{$class}; $i++){
    			print OUT $cluster,"\t",$class,"\n"; #,"\t",$clusterAnalysisHash{$cluster}{$class},
            }
		}
	}
	close OUT;
	
	system "Rscript $Bin/plotClusters.R hist $output_dir/cluster_distribution.txt $output_dir/cluster_distribution.pdf";

	## select cluster representatives
	open TAB, $sim_tab or die $!;
	my %similaritiesHash = ();
	while(<TAB>){
	    chomp($_);
	    my ($bg1, $bg2, $sim) = split('\t', $_);
	    $similaritiesHash{"$bg1\t$bg2"} = $sim;
	}
	close TAB;
	my @cluster_candidates = ();
	foreach my $cluster (keys %clusterEntriesHash){
	    my @entries = @{$clusterEntriesHash{$cluster}};
	    my $candidate = "";
	    my $candidate_sim = 0;
	    foreach my $i (@entries){
	        my $sum = 0;
	        foreach my $j (@entries){
	            $sum += $similaritiesHash{"$i\t$j"};
	        }
	        if($sum > $candidate_sim){
	            $candidate = $i;
	            $candidate_sim = $sum;
	        }
	    }
	    push(@cluster_candidates, $candidate);
	}

    open OUTTAB, ">$output_dir/cluster_candidate_sim.tab" or die $!;
    open OUTMTX, ">$output_dir/cluster_candidate_sim.mtx" or die $!;
    open BGA, ">$output_dir/candidate_bg_annotations.txt" or die $!;
    foreach my $i (@cluster_candidates){
        my $sum = 0;
        my ($id1, $class1, $bg1) = split(':', $i);
        print BGA $bg1,"\t",$class1,"\n";
        print OUTMTX $bg1;
        foreach my $j (@cluster_candidates){
            print OUTTAB $i,"\t",$j,"\t",$similaritiesHash{"$i\t$j"},"\n";
            print OUTMTX " ",$similaritiesHash{"$i\t$j"};
        }
        print OUTMTX "\n";
    }
    close OUTTAB;
    close OUTMTX;
    close BGA;
    
    system "Rscript $Bin/plotClusters.R clust $output_dir/cluster_candidate_sim.mtx $output_dir/candidate_bg_annotations.txt $output_dir/hclust_tree_clusters.pdf";
    
    system "mcl $output_dir/cluster_candidate_sim.tab --abc -pi 20 -I 20 -o $output_dir/mcl_cand.out 2> $output_dir/mcl_cand.log";
}


sub extractMCLClusters {
	my $test_file_name = `filename=\$(basename $test_file);filename="\${filename%.*}";echo -n \$filename`;
	
	my %clusters = ();
	open IN, "$output_dir/mcl.out" or die $!;
	my $cluster_count = 1;
	while(<IN>){
		chomp($_);
		my @fs = split('\t', $_);
		next if(scalar @fs < 3);
		foreach my $f (@fs){
			$clusters{$f} = $cluster_count;
		}
		$cluster_count++;
	}
	close IN;
	
	#>cluster_1	chr22	39709814	39709914	-	236.17	68	3	13077:snoRNA_CD-box:snoU83B	snoRNA_CD-box	0.90099:0.978495
	#chr22	39709891	39709913	tag_1965152|1	1.000000	-	1
	
	my %bgHash = ();
	my %bedHash = ();
	my $cluster_nr  = "";
	my $bg_count = 0;
	open BBO, "$output_dir/$test_file_name.annotated.bbo" or die $!;
	while(<BBO>){
		chomp($_);
		my @f = split('\t', $_);
		if($_ =~ m/^>/){
			$cluster_nr = $_;
			my @bgf = split('\t', $_);
			my $bg_id = $bgf[0];
			my $bg_class = $bgf[9];
			$bg_count++;
			$bg_id =~ s/^>//;
			$bg_id =~ s/cluster_/blockgroup_/;
			if(exists $clusters{"$bg_count:$bg_class:$bg_id"}){
				$cluster_nr = $clusters{"$bg_count:$bg_class:$bg_id"};
				push(@{$bgHash{$cluster_nr}}, $_);
				my $bed_entry = $f[1]."\t".$f[2]."\t".$f[3]."\t$bg_count:$bg_class:$bg_id:cluster_$cluster_nr:"."\t".$f[5]."\t".$f[4];
			 	push(@{$bedHash{$cluster_nr}}, $bed_entry);
			}
			else{
				$cluster_nr = "";
			}
		}
		else{
			if($cluster_nr ne ""){
				push(@{$bgHash{$cluster_nr}}, $_);
			}
		}
	}
	close BBO;
	
	mkdir "$output_dir/mcl_clusters" if(! -d "$output_dir/mcl_clusters");
	open ALLOUTBED, ">$output_dir/mcl_clusters/all_clusters.bed" or die $!; 
	foreach my $cluster (sort keys %bgHash){
		open OUTBBO, ">$output_dir/mcl_clusters/cluster_$cluster.bbo" or die $!;
		foreach my $line(@{$bgHash{$cluster}}){
			print OUTBBO $line,"\n";
		}
		close OUTBBO;
		open OUTBED, ">$output_dir/mcl_clusters/cluster_$cluster.bed" or die $!;
		foreach my $line(@{$bedHash{$cluster}}){
			print OUTBED $line,"\n";
			print ALLOUTBED $line, "\n";
		}
		close OUTBED;
	}
	close ALLOUTBED;
	return;
}



sub reverseComplement{
    my ($seq) = @_;
    my $revcomp = reverse($seq);    
    $revcomp =~ tr/ACGTUacgtu/TGCAAtgcaa/;    
    return $revcomp;
}


sub trim{
	$_ = shift;
	$$_ =~ s/^\s+|\s+$//g;
	return $_;
}
