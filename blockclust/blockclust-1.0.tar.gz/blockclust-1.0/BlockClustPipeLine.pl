#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Long;
use Cwd 'abs_path';
use Pod::Usage;
use FindBin '$Bin';
use List::Util qw(sum);

=head1 NAME

BlockClustPipeLine.pl

=head1 SYNOPSIS

perl BlockClustPipeLine.pl -m [test/train] -a [annotations BED file] -c [configuration string] -T [test file] -od [output directory] 

=head1 OPTIONS

        -help       brief help message
        -man        full documentation
        -m          mode of run
        -a          file of annotations
        -c          configuration file
        -T          train input file
        -V          validation input file
        -t          test input file
        -od         output directory

=head1 DESCRIPTION
         
=cut

my ($help, $man, $mode, $accept_annotations_bed, $reject_annotations_bed, $model_accept_annotations_bed, $model_reject_annotations_bed, $train_file, $test_file, $validation_file, $config_file, $predict, $nr_of_bins, $radius, $gspan_format, $output_dir, $nr_nearest_neightbors, $model_dir, $cmsearch_out, $clusters_bed, $bam, $tags_bed, $sim_tab, $prediction_mode, $train_and_test, $bit_size);

$nr_of_bins = 3;
$radius = 5;
$gspan_format = "SEQUENCE";
$nr_nearest_neightbors = 3;
$bit_size = 15;

my $options = GetOptions ("help"    => \$help,
                        "man"       => \$man,
                        "m=s"       => \$mode,
                        "a=s"       => \$accept_annotations_bed,
                        "r=s"       => \$reject_annotations_bed,
                        "T=s"       => \$train_file,
                        "t=s"       => \$test_file,
                        "V=s"       => \$validation_file,
                        "c=s"       => \$config_file,
                        "n=i"       => \$nr_of_bins,
                        "x=i"       => \$nr_nearest_neightbors,
                        "Rd=i"      => \$radius,
                        "p"         => \$predict,
                        "pm=s"      => \$prediction_mode,
                        "f=s"       => \$gspan_format,
                        "o=s"       => \$output_dir,
                        "md=s"      => \$model_dir,
                        "ma=s"      => \$model_accept_annotations_bed,
                        "mr=s"      => \$model_reject_annotations_bed,
                        "cm=s"      => \$cmsearch_out,
                        "cbed=s"    => \$clusters_bed,
                        "bam=s"     => \$bam,
                        "tbed=s"    => \$tags_bed,
                        "tab=s"     => \$sim_tab,
                        "tt"		=> \$train_and_test,
                        "b=i"		=> \$bit_size
                        );

pod2usage(-exitstatus => 0, -verbose => 2) if $man;

trim(\$test_file) if($test_file); trim(\$train_file) if($train_file); trim(\$validation_file) if($validation_file); 
trim(\$accept_annotations_bed) if($accept_annotations_bed); trim(\$reject_annotations_bed) if($reject_annotations_bed);
trim(\$config_file) if($config_file); trim(\$output_dir) if($output_dir); 

if(!$mode){
    print STDERR "option '-m' is mandatory\n";
    exit 1;
}

if($mode eq "TEST" || $mode eq "POST" ){
    $output_dir = abs_path($output_dir);
    if($predict){
        $model_dir = abs_path($model_dir);
    }

    if(!$output_dir || $output_dir eq ""){
        $output_dir = `echo -n blockclust_\$(date +%d%m%Y_%H%M%S)`;
    }

    if($output_dir eq $Bin || $output_dir =~ m/^-/) {
        print STDERR "Please choose a different output directory\n";
        exit 1;
    }
}

if($mode eq "TRAIN"){
    if(!$train_file ||!$validation_file || !$accept_annotations_bed || !$reject_annotations_bed || !$output_dir){
        print STDERR "options '-T', '-V', '-a', '-R' and '-o' are mandatory in testing mode\n";
        exit 0;
    }
    system "$Bin/BlockClust -m TRAIN -T $train_file -V $validation_file -a $accept_annotations_bed -r $reject_annotations_bed -n $nr_of_bins -R $radius -o $output_dir -b $bit_size";
}

elsif($mode eq "PRE"){
    if(!$bam || !$tags_bed ){
        print STDERR "options '-bam', '-tbed' are mandatory in pre-processing mode\n";
        exit 0;
    }
    open SAM, "samtools view $bam |" || open SAM, "samtools view -S $bam |" || die "cannot open $bam: $!\n";
    my %tags = ();
    while(<SAM>){
        next if($_ =~ m/^@|\tchrM\t/);
        chomp;
        my @f = split('\t',$_);
        next if ($_ =~ /^[@]/ || $f[2] eq "*");
        my $id = $f[0];
        my $flag = $f[1];
        my $chrom = $f[2];
        my $start = $f[3]; $start--;
        my $cigar = $f[5];
        my $seqence = $f[9];
        my $end = $start;
        my $strand; 
        if($flag == 0){
            $strand = "+";
        }
        elsif($flag == 16){
            $strand = "-";
            $seqence = reverseComplement($seqence);
        }
        else{
            print STDERR "Warning: flag '$flag' found!\n";
            next;
        }

        $cigar =~ s/(\d+)[MD]/$end+=$1/eg;
        my $pos = "$chrom\t$start\t$end\t$strand";

        $tags{$seqence}{"seq"}++;
        $tags{$seqence}{"read_id"}{$id}++;
        $tags{$seqence}{"pos"}{$pos}++;
    }
    close SAM;

    my $tag_id = 1;
    open OUT, ">$tags_bed" or die $!;
    foreach my $seq(keys %tags){
        my $nr_of_mappings = $tags{$seq};
        my $nr_of_loci = keys %{$tags{$seq}{"pos"}};
        my $read_count = keys %{$tags{$seq}{"read_id"}};
        my $normalized_count = sprintf("%.6f", $read_count/$nr_of_loci);
        foreach my $pos(keys %{$tags{$seq}{"pos"}}){
            my ($chrom,$start,$end,$strand) = split('\t', $pos);
            print OUT "$chrom\t",$start,"\t",$end,"\ttag_$tag_id|$read_count|$nr_of_loci\t",$normalized_count,"\t$strand\n";
            $tag_id++;
        }
    }
    close OUT;
}

elsif($mode eq "TEST"){
    if(!$test_file || !$config_file || !$accept_annotations_bed || !$reject_annotations_bed ||
        $test_file eq "" || $config_file eq "" || $accept_annotations_bed eq "" || $reject_annotations_bed eq ""){
        print STDERR "Options '-t', '-a', '-r' and '-c' are mandatory in test mode\n";
        exit 1;
    }

    if($predict && !$model_dir){
        print STDERR "Please provide model directory '-md' along with option '-p'\n";
        exit 1;
    }
    if($predict && $model_dir eq $Bin) {
        print STDERR "Please choose a different model directory\n";
        exit 1;
    }
######### BlockClust call ############
    system("$Bin/BlockClust -m TEST -a $accept_annotations_bed -r $reject_annotations_bed -c $config_file -o $output_dir -t $test_file -f $gspan_format -b $bit_size");
    if ($? >> 8 != 0) {
        print STDERR "============= BlockClust run terminated =============\n\n";
        exit 1;
    }
	system "cp $config_file $output_dir/";
    open ANNOT, "$output_dir/blockgroup_annotations.txt" or die $!;
    my $count = 1;
    my %bgo = ();
    while(<ANNOT>){
        chomp($_);
        my @f = split('\t', $_);
        $bgo{$count} = "$f[1]:$f[0]";
        $count++;
    }
    close ANNOT;

#   print "Plotting features...\n";
#   system "perl $Bin/plotFeatures.pl -a $output_dir/blockgroup_annotations.txt -f $output_dir/non_discretized.feat -od $output_dir -c $config_file";

    $count = 1;
    open MTX, "$output_dir/matrix" or die $!;
    open TAB, ">$output_dir/discretized.gspan.tab" or die $!;
    while(<MTX>){
        chomp($_);
        my @f = split('\s+', $_);
        for(my $j=0;$j<=$#f;$j++){
            print TAB $count,":",$bgo{$count},"\t",$j+1,":",$bgo{$j+1},"\t",$f[$j],"\n";
        }
        $count++;
    }
    close MTX;
    close TAB;


    print "=========================================================\n";

    open ANNOT, "$output_dir/blockgroup_annotations.txt" or die $!;
    my %annotations_hash = ();
    $count = 1;
    while(<ANNOT>){
        my ($id, $annotation) = split('\t', $_);
        $annotations_hash{$count} = $id;
        $count++; 
    }
    close ANNOT;

    open MTX, "$output_dir/matrix" or die $!;
    open OMTX, ">$output_dir/hclust_input.mtx" or die $!;
    $count = 1;
    while(<MTX>){
        my $line = $_;
        chomp($line);
        my $new_line = $annotations_hash{$count}." ";
        $new_line .= $line;
        print OMTX $new_line,"\n";
        $count++;
    }
    close MTX;
    close OMTX;

    system "Rscript $Bin/plotClusters.R clust $output_dir/hclust_input.mtx $output_dir/blockgroup_annotations.txt $output_dir/hclust_tree.pdf";

    ## MCL clustering
    system "mcl $output_dir/discretized.gspan.tab --abc -pi 20 -I 20 -o $output_dir/mcl.out 2> $output_dir/mcl.log";
    extractMCLClusters();
#    system "perl $Bin/calculatePrecisionPerClass.pl -f $output_dir/mcl.out -t 0.5 -dir $output_dir/mcl_clusters > $output_dir/cluster_precisions.out";

    if($predict){
        print "Performing classification\n";
        my ($sequence_degree, $radius, $distance) = extractEDeNParameters();

        if($prediction_mode eq "nearest_neighbour"){
            # EDeN nearest neighbors
            my ($class_target_hash_ref, $train_class_target_hash_ref) = writeTrainTestTargets();
            my %class_target_hash = %{$class_target_hash_ref};
            my %train_class_target_hash = %{$train_class_target_hash_ref};
			
            system "EDeN -g DIRECTED -b $bit_size -t $output_dir/input.target -A $output_dir/test.ids -B $output_dir/train.ids -a NEAREST_NEIGHBOR -i $output_dir/input.gspan -f SEQUENCE -r $radius -d $distance -M $sequence_degree -x $nr_nearest_neightbors -y $output_dir >> $output_dir/EDeN.log";

            my %target_class_hash = reverse %class_target_hash;
            my %nnPredictionHash = ();
            open KNN, "$output_dir/knn_target_value" or die $!;
            my $c=1;
            while(<KNN>){
                chomp($_);
                my %tgt_hash = ();
                my @f = split('\s+', $_);
                shift(@f);
                foreach my $tgt(@f){
                    $tgt_hash{$tgt}++;
                }
                foreach my $tgt (keys %tgt_hash){
                    #print $tgt_hash{$tgt}/($#f+1),"\n";
                    if(($tgt_hash{$tgt}/($#f+1)) > 0.5){
                        $nnPredictionHash{$c} = $target_class_hash{$tgt};
                    }
                }
                $nnPredictionHash{$c} = "unknown" if(! exists $nnPredictionHash{$c});
                $c++;
            }
            close KNN;
            writePredictions("$output_dir/nearest_neighbour_predictions.txt", %nnPredictionHash);
            
            print "NEAREST NEIGHBOR PREDICTION:\n";
            foreach my $class(sort keys %train_class_target_hash){
                computeNNPerformance($class, $train_class_target_hash{$class});
            }
        print "\n=======================================================\n\n";
        }
        elsif($prediction_mode eq "model_based"){
            ## Create models for each family
            my %tempPredictionsHash = ();
            system "mkdir $output_dir/models" if(! -d "$output_dir/models");
            
            my ($class_target_hash_ref, $train_class_target_hash_ref) = writeTrainTestTargets();
            my %class_target_hash = %{$class_target_hash_ref};
            my %train_class_target_hash = %{$train_class_target_hash_ref};
            foreach my $class(sort keys %train_class_target_hash){
            	if($train_and_test){
                	makeModelAndTest($class, $train_class_target_hash{$class});
            	}
            	else{
#                	if($class =~ m/miRNA|tRNA|CD-box/){
                		modelBasedTest($class, $train_class_target_hash{$class});
#                	}
            	}
                collectPredictions($class, \%tempPredictionsHash);
            }

            my %modelPredictionsHash = ();
            foreach my $bg (sort {$a<=>$b} keys %tempPredictionsHash){
                my $pred_string = "";
                foreach (@{$tempPredictionsHash{$bg}}){
                    $pred_string .= ";".$_;
                }
                $pred_string =~ s/^;+|;+$|\s//g;
                $pred_string = "unknown" if($pred_string eq "");
                $modelPredictionsHash{$bg} = $pred_string;
            }
            writePredictions("$output_dir/model_based_predictions.txt", %modelPredictionsHash);

            print "MODEL BASED PREDICTION:\n";
            foreach my $class(sort keys %train_class_target_hash){
                computePredictionPerformance($class);
            }
        }
    }

    print "============= DONE ============\n\n";
}

elsif($mode eq "POST"){
    if(!$cmsearch_out || !$clusters_bed || !$output_dir){
        print STDERR "options '-cm', '-o' are mandatory in post-processing mode\n";
        exit 0;
    }

    my %clusterSizeHash = ();
    my %clusterEntriesHash = ();
    open BED, $clusters_bed or die $!;
    while(<BED>){
    my @f = split('\t', $_);
    my @cf = split(':', $f[3]);
    $clusterSizeHash{$cf[3]}++;
    push(@{$clusterEntriesHash{$cf[3]}}, $cf[0].":".$cf[1].":".$cf[2]);
    }
    close BED;

    my %rfamHash = ();
    open RFAM, "$Bin/rfam_map.txt" or die $!;
    while(<RFAM>){
        chomp($_);
        my @f = split('\t', $_);
        $rfamHash{$f[0]} = $f[1];
    }
    close RFAM;

    my %cmsHash = ();
    my %uniqFoundHash = ();
    ## process cmsearch output
    open CMS, $cmsearch_out or die $!;
    while(<CMS>){
        chomp($_);
        my @fields = split('\s+', $_);
        next if($fields[15] > 0.000001);
        my @disc_fields = split(':', $fields[17]);
        my $cluster_id = $disc_fields[3];
        next if(exists $uniqFoundHash{$cluster_id}{$fields[0]});
        $cmsHash{$cluster_id}{$rfamHash{$fields[3]}}++;
        $uniqFoundHash{$cluster_id}{$fields[0]}++;
    }
    close CMS;

    my %clusterAnalysisHash = ();
    my $sum = 0;
    foreach my $cluster (sort keys %clusterSizeHash){
        my $cluster_size = $clusterSizeHash{$cluster};
        my $known_instances = 0;
        foreach my $rfam_class (keys %{$cmsHash{$cluster}}){
            $clusterAnalysisHash{$cluster}{$rfam_class} += $cmsHash{$cluster}{$rfam_class};
        }
        $known_instances = keys %{$uniqFoundHash{$cluster}};
        my $unknown_instances = $cluster_size - $known_instances;
        $clusterAnalysisHash{$cluster}{'unknown'} = $unknown_instances;
    }
    open OUT, ">$output_dir/cluster_distribution.txt" or die $!;
    print OUT "Clusters\tRNA_type\n";
    foreach my $cluster (sort keys %clusterAnalysisHash){
        foreach my $class (keys %{$clusterAnalysisHash{$cluster}}){
            next if($clusterAnalysisHash{$cluster}{$class} <= 0);
            for(my  $i=0; $i<$clusterAnalysisHash{$cluster}{$class}; $i++){
                print OUT $cluster,"\t",$class,"\n"; #,"\t",$clusterAnalysisHash{$cluster}{$class},
            }
        }
    }
    close OUT;
    system "Rscript $Bin/plotClusters.R hist $output_dir/cluster_distribution.txt $output_dir/cluster_distribution.pdf";

    ## select cluster representatives
    open TAB, $sim_tab or die $!;
    my %similaritiesHash = ();
    while(<TAB>){
        chomp($_);
        my ($bg1, $bg2, $sim) = split('\t', $_);
        $similaritiesHash{"$bg1\t$bg2"} = $sim;
    }
    close TAB;
    my @cluster_candidates = ();
    foreach my $cluster (keys %clusterEntriesHash){
        my @entries = @{$clusterEntriesHash{$cluster}};
        my $candidate = "";
        my $candidate_sim = 0;
        foreach my $i (@entries){
            my $sum = 0;
            foreach my $j (@entries){
                $sum += $similaritiesHash{"$i\t$j"};
            }
            if($sum > $candidate_sim){
                $candidate = $i;
                $candidate_sim = $sum;
            }
        }
        push(@cluster_candidates, $candidate);
    }

    open OUTTAB, ">$output_dir/cluster_candidate_sim.tab" or die $!;
    open OUTMTX, ">$output_dir/cluster_candidate_sim.mtx" or die $!;
    open BGA, ">$output_dir/candidate_bg_annotations.txt" or die $!;
    foreach my $i (@cluster_candidates){
        my $sum = 0;
        my ($id1, $class1, $bg1) = split(':', $i);
        print BGA $bg1,"\t",$class1,"\n";
        print OUTMTX $bg1;
        foreach my $j (@cluster_candidates){
            print OUTTAB $i,"\t",$j,"\t",$similaritiesHash{"$i\t$j"},"\n";
            print OUTMTX " ",$similaritiesHash{"$i\t$j"};
        }
        print OUTMTX "\n";
    }
    close OUTTAB;
    close OUTMTX;
    close BGA;
    
    system "Rscript $Bin/plotClusters.R clust $output_dir/cluster_candidate_sim.mtx $output_dir/candidate_bg_annotations.txt $output_dir/hclust_tree_clusters.pdf";
    
    system "mcl $output_dir/cluster_candidate_sim.tab --abc -pi 20 -I 20  -o $output_dir/mcl_cand.out 2> $output_dir/mcl_cand.log";
}

else{
    print STDERR "From script Option -m can be one of the 'TRAIN', 'TEST', 'PRE' and 'POST' \n";
    exit 1;
}

sub reverseComplement{
    my ($seq) = @_;
    my $revcomp = reverse($seq);
    $revcomp =~ tr/ACGTUacgtu/TGCAAtgcaa/;
    return $revcomp;
}


sub trim{
    $_ = shift;
    $$_ =~ s/^\s+|\s+$//g;
    return $_;
}

sub extractEDeNParameters{
    my $sequence_degree=`grep Feature_combination: $config_file| awk -F ' ' '{print \$3","\$4}' | grep -o ','|wc -l`;
    chomp($sequence_degree);
    $sequence_degree++;
    my $radius=`grep -P 'Radius: [0-9]*' $config_file`;
    chomp($radius);
    $radius =~ s/Radius: //;
    my $distnce = 2*$radius+1;
    return($sequence_degree, $radius, $distnce);
}

sub makeModelAndTest{
    my $class = $_[0];
    my $class_target = $_[1];

    my ($sequence_degree, $radius, $distance) = extractEDeNParameters();
    writeClassTargets($class, $class_target, "train");
    writeClassTargets($class, $class_target, "test");
    system "EDeN -g DIRECTED  -b $bit_size -i $model_dir/discretized.gspan -f SEQUENCE -M $sequence_degree -r $radius -d $distance -a TRAIN -m $output_dir/models/$class.model -t $output_dir/$class/$class.train.target >> $output_dir/EDeN.log";
    system "cp $output_dir/discretized.gspan $output_dir/$class/discretized.gspan";
    system "EDeN -g DIRECTED  -b $bit_size -i $output_dir/$class/discretized.gspan -f SEQUENCE -M $sequence_degree -r $radius -d $distance -a TEST -m $output_dir/models/$class.model -y $output_dir/$class >> $output_dir/EDeN.log";
    
    system "cp $model_dir/discretized.gspan $output_dir/models/";
    system "cp $model_dir/blockgroup_annotations.txt $output_dir/models/";
}

sub modelBasedTest{
    my $class = $_[0];
    my $class_target = $_[1];

    my ($sequence_degree, $radius, $distance) = extractEDeNParameters();
    writeClassTargets($class, $class_target, "train");
    writeClassTargets($class, $class_target, "test");
    system "cp $output_dir/discretized.gspan $output_dir/$class/discretized.gspan";
    system "EDeN -g DIRECTED  -b $bit_size -i $output_dir/$class/discretized.gspan -f SEQUENCE -M $sequence_degree -r $radius -d $distance -a TEST -m $model_dir/$class.model -y $output_dir/$class >> $output_dir/EDeN.log";
}

sub computePredictionPerformance{
    my $class = $_[0];
    system "paste $output_dir/$class/$class.test.target $output_dir/$class/prediction | awk '{print \$1\"\t\"\$3}' > $output_dir/$class/$class.pred.perf.in";

    print "$class:\n";
    system "perf -PRF -SEN -PPV -NPV -ROC -SPC -ACC -PRE -REC -t 0.5 < $output_dir/$class/$class.pred.perf.in | tee $output_dir/$class.pred.out";
}


sub computeNNPerformance{
    my $class = $_[0];
    my $class_target = $_[1];

    system "mkdir $output_dir/$class" if(!-d "$output_dir/$class");
    writeClassTargets($class, $class_target, "test");

    system "awk '{ if(\$2!=$class_target) \$2=-1;if(\$3!=$class_target) \$3=-1; if(\$4!=$class_target) \$4=-1; if(\$2==$class_target) \$2=1;if(\$3==$class_target) \$3=1; if(\$4==$class_target) \$4=1; print \$0}' $output_dir/knn_target_value | awk '{print (\$2+\$3+\$4)/3}' > $output_dir/$class/$class.nn.temp";
    system "paste $output_dir/$class/$class.test.target $output_dir/$class/$class.nn.temp > $output_dir/$class/$class.nn.perf.in";
    print "$class:\n";
    system "perf -PRF -SEN -PPV -NPV -ROC -SPC -ACC -PRE -REC -t 0.5 < $output_dir/$class/$class.nn.perf.in | tee $output_dir/$class.nn.out";
}

sub writeClassTargets{
    my $class = $_[0];
    my $class_target = $_[1];
    my $t = $_[2];
    system "mkdir $output_dir/$class" if(!-d "$output_dir/$class");
    open IN, "$output_dir/$t.target" or die $!;
    open OUT, ">$output_dir/$class/$class.$t.target" or die $!;
    while(<IN>){
        chomp($_);
        if($_ eq $class_target){
            print OUT "1\n";
        }
        else{
            print OUT "-1\n";
        }
    }
    close IN;
    close OUT;
}

sub collectPredictions{
    my $class = $_[0];
    my $predictionsHashRef = $_[1];
    my $c = 0;
    open IN, "$output_dir/$class/prediction" or die $!;
    while(<IN>){
        chomp($_);
        $c++;
        my ($trgt, $val) = split('\s', $_);
        my $prediction = "";
        if($trgt eq "1"){
            $prediction = "predicted_$class";
        }
        push (@{$predictionsHashRef->{$c}}, $prediction);
    }
    close IN;
}

sub writePredictions{
    my $file = shift;
    my %predictionsHash = @_;
    my $test_file_name = `filename=\$(basename $test_file);filename="\${filename%.*}";echo -n \$filename`;
    open BBO, "$output_dir/$test_file_name.annotated.bbo" or die $!;
    open PRED, ">$file" or die $!;
    my $c = 0;
    while(<BBO>){
        next if($_ !~ m/^>/);
        chomp($_);
        $c++;
        my @f = split('\t', $_);
        my $prediction = $predictionsHash{$c};
        print PRED "$f[1]\t$f[2]\t$f[3]\t$prediction\t$f[5]\t$f[4]\n";
    }
    close BBO;
    close PRED;
}

sub extractMCLClusters {
    my $test_file_name = `filename=\$(basename $test_file);filename="\${filename%.*}";echo -n \$filename`;

    my %clusters = ();
    open IN, "$output_dir/mcl.out" or die $!;
    my $cluster_count = 1;
    while(<IN>){
        chomp($_);
        my @fs = split('\t', $_);
        next if(scalar @fs < 3);
        foreach my $f (@fs){
            $clusters{$f} = $cluster_count;
        }
        $cluster_count++;
    }
    close IN;

    my %bgHash = ();
    my %bedHash = ();
    my $cluster_nr  = "";
    my $bg_count = 0;
    open BBO, "$output_dir/$test_file_name.annotated.bbo" or die $!;
    while(<BBO>){
        chomp($_);
        my @f = split('\t', $_);
        if($_ =~ m/^>/){
            $cluster_nr = $_;
            my @bgf = split('\t', $_);
            my $bg_id = $bgf[0];
            my $bg_class = $bgf[9];
            $bg_count++;
            $bg_id =~ s/^>//;
            $bg_id =~ s/cluster_/blockgroup_/;
            if(exists $clusters{"$bg_count:$bg_class:$bg_id"}){
                $cluster_nr = $clusters{"$bg_count:$bg_class:$bg_id"};
                push(@{$bgHash{$cluster_nr}}, $_);
                my $bed_entry = $f[1]."\t".$f[2]."\t".$f[3]."\t$bg_count:$bg_class:$bg_id:cluster_$cluster_nr:"."\t".$f[5]."\t".$f[4];
                push(@{$bedHash{$cluster_nr}}, $bed_entry);
            }
            else{
                $cluster_nr = "";
            }
        }
        else{
            if($cluster_nr ne ""){
                push(@{$bgHash{$cluster_nr}}, $_);
            }
        }
    }
    close BBO;

    mkdir "$output_dir/mcl_clusters" if(! -d "$output_dir/mcl_clusters");
    open ALLOUTBED, ">$output_dir/mcl_clusters/all_clusters.bed" or die $!; 
    foreach my $cluster (sort keys %bgHash){
        open OUTBBO, ">$output_dir/mcl_clusters/cluster_$cluster.bbo" or die $!;
        foreach my $line(@{$bgHash{$cluster}}){
            print OUTBBO $line,"\n";
        }
        close OUTBBO;
        open OUTBED, ">$output_dir/mcl_clusters/cluster_$cluster.bed" or die $!;
        foreach my $line(@{$bedHash{$cluster}}){
            print OUTBED $line,"\n";
            print ALLOUTBED $line, "\n";
        }
        close OUTBED;
    }
    close ALLOUTBED;
    return;
}


sub writeTrainTestTargets{
	system "cat $model_dir/discretized.gspan $output_dir/discretized.gspan > $output_dir/input.gspan";
	system "cat $model_dir/blockgroup_annotations.txt $output_dir/blockgroup_annotations.txt > $output_dir/input.blockgroup_annotations.txt";

	my $train_size = `wc -l < $model_dir/blockgroup_annotations.txt`;
	chomp($train_size);
	my $test_size = `wc -l < $output_dir/blockgroup_annotations.txt`;
	chomp($test_size);

	my %class_target_hash = ();
	open BGA, "$output_dir/input.blockgroup_annotations.txt" or die $!;
	open TGT, ">$output_dir/input.target" or die $!;
	open TRTGT, ">$output_dir/train.target" or die $!;
	open TRIDS, ">$output_dir/train.ids" or die $!;
	open TETGT, ">$output_dir/test.target" or die $!;
	open TEIDS, ">$output_dir/test.ids" or die $!;
	my $tgt_id_count = 1;
	my $c = 1;
	my %train_class_target_hash = ();
	while(<BGA>){
		chomp($_);
		my ($bg_id, $class) = split('\t', $_);
		if(! exists $class_target_hash{$class}){    
			$class_target_hash{$class} = $tgt_id_count;
			$tgt_id_count++;
		}
		print TGT $class_target_hash{$class},"\n";
		if($c <= $train_size){
			print TRTGT $class_target_hash{$class},"\n";
			$train_class_target_hash{$class} = $class_target_hash{$class};
			print TRIDS $c-1,"\n";
		}
		else{
			print TETGT $class_target_hash{$class},"\n";
			print TEIDS $c-1,"\n";
		}
		$c++;
	}
	close BGA;
	close TGT;
	close TRTGT;
	close TRIDS;
	close TETGT;
	close TEIDS;
	return(\%class_target_hash, \%train_class_target_hash);
}
