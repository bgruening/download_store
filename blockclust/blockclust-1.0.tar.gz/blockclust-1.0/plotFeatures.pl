#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Long;
use Cwd 'abs_path';
use Pod::Usage;

=head1 NAME

plotFeatures.pl

=head1 SYNOPSIS

perl plotFeatures.pl -a [annotations file]

=head1 OPTIONS

	-help	brief help message
	-man	full documentation
	-a	annotations file
	-f	features file
	-out	output BED 
			
=head1 DESCRIPTION
	 
=cut

my ($help, $man, $annot, $feat, $dfeat, $outdir, $config);

my $options = GetOptions ("help"	=> \$help,
                          "man"  	=> \$man,
                          "a=s"		=> \$annot,
                          "f=s"		=> \$feat,
                          "df=s"		=> \$dfeat,
 			  			  "od=s"	=> \$outdir,
			  			  "c=s"	=> \$config
                         );
pod2usage(-exitstatus => 1, -verbose => 1) if ($help|| !$annot|| !$feat || !$outdir);
pod2usage(-exitstatus => 0, -verbose => 2) if $man;

open BB, $config or die $!;
my %discr = ();

my $curr_feat = "";
while(<BB>){
	chomp($_);
	next if($_ =~ m/Discretization_level|Radius|Feature_combination|Bin_boundaries/);
	if($_ =~ m/^>/){
		$curr_feat = $';
	}
	else{
		if($_ !~ m/inf/){
			my @f = split('\t', $_);
			$discr{$curr_feat}{$f[1]}++;
			$discr{$curr_feat}{$f[2]}++;
		}
	}
}
close BB;


my %true_label_hash = ();
my $label_counter= 0;
open ANNOT, $annot or die $!;
my %bgo = ();
while(<ANNOT>){
	chomp($_);
	$_=~ s/snoRNA_//;
	my @f = split('\t', $_);
	$bgo{$f[0]} = $f[1];
	if(exists $true_label_hash{$f[1]}){
		next;
	}
	else{
		$label_counter++;
		$true_label_hash{$f[1]}= $label_counter;
	}
}
close ANNOT;

open IN, $feat or die $!;
my $header = <IN>;
chomp($header);
my @hf = split("\t",$header);
my %features_hash = ();
my %total_hash = ();
 
while(<IN>){
	chomp($_);
	my @f = split('\t', $_);
	next if($bgo{$f[0]}=~ m/unknown/);
	for (my $i=1; $i<=$#f;$i++){
		if($f[$i] =~ m/,/){
			my @ff = split(',', $f[$i]);
			for (my $ii=1; $ii<=$#ff;$ii++){
				push(@{$features_hash{$hf[$i]}{$bgo{$f[0]}}}, $ff[$ii]);
			}
		}
		else{
			push(@{$features_hash{$hf[$i]}{$bgo{$f[0]}}}, $f[$i]);
		}
	}
}
close IN;

open(RCMD, "| R --vanilla --slave");
print RCMD "remove_outliers <- function(x, na.rm = TRUE, ...) {\n
  qnt <- quantile(x, probs=c(.1, .9), na.rm = na.rm, ...)\n
  H <- 1.5 * IQR(x, na.rm = na.rm)\n
  y <- x\n
  y[x < (qnt[1] - H)] <- NA\n
  y[x > (qnt[2] + H)] <- NA\n
  y\n
}\n";
print RCMD "pdf(\"$outdir/feature_plots.pdf\", width = 12, height=12)\n";
print RCMD "par(mfrow=c(2,2))\n";


foreach my $feat (sort keys %features_hash){
#	print "=====",$feat,"======\n";
#	open TRUE, ">$outdir/true_$feat.out" or die $!;
#	open PRED, ">$outdir/pred_$feat.out" or die $!;
	my $values_list = "";
	my $names_list = "";
	foreach my $class (sort keys $features_hash{$feat}){
		my @feat_values = @{$features_hash{$feat}{$class}};
		my $values = "c(";
		foreach my $value (@feat_values){
			$values .= $value.",";
#			my @bounds = keys %{$discr{$feat}};
#			if($#bounds == 1){
#				if(-9**9**9 < $value && $value < $bounds[0]){
#					print PRED "1\n";
#					print TRUE $true_label_hash{$class},"\n";
#				}
#				elsif($bounds[$#bounds] < $value && $value < 9**9**9){
#					print PRED "3\n";
#					print TRUE $true_label_hash{$class},"\n";
#				}
#				else{
#					print PRED "2\n";
#					print TRUE $true_label_hash{$class},"\n";
#				}
#			}
#			else{
#				my $c = 0;
#				if(-9**9**9 < $value && $value <= $bounds[0]){
#					$c++;
#					print PRED $c,"\t$value\n";
#					print TRUE $true_label_hash{$class},"\n";
#				}
#				for(my $bi=1; $bi<$#bounds; $bi++){
#					next if($#bounds <= $bi );
#					if($bounds[$bi-1] < $value && $value <= $bounds[$bi]){
#						$c++;					
#						print PRED $c,"\t$value\n";
#						print TRUE $true_label_hash{$class},"\n";
#					}
#				}
#				if($value > $bounds[$#bounds] && $value < 9**9**9){
#					$c++;
#					print PRED $c,"\t$value\n";
#					print TRUE $true_label_hash{$class},"\n";
#				}
#			}
		}
		$values =~ s/,$/\)/;
		$values_list .= "remove_outliers($values),";
 		$names_list .= "\"$class\"". ",";
	}
	$values_list =~ s/,$//;
	$names_list =~ s/,$//;
	
	print RCMD "boxplot($values_list, names = c($names_list), main=\"$feat\", cex.axis=0.8, cex.main=1.5, col=rainbow(7,alpha = 0.3))\n";
#	print RCMD "legend(0,0,c($names_list),horiz=TRUE, col=rainbow(7,alpha = 0.3), )\n";

	foreach my $bound (keys %{$discr{$feat}}){
		print RCMD "abline(h = $bound, col = \"red\")\n";
	}

	print RCMD "grid()\n";
#	print "\n";
#	close TRUE;
#	close PRED;

	
#	foreach my $class (sort keys $features_hash{$feat}){
#		system "sed 's/$true_label_hash{$class}/0/' $outdir/true_$feat.out | sed 's/[1-9]/2/'| sed 's/0/1/' > $outdir/$feat\_$class.true.out";
#		print "$class: ";
#		system "ari.m $outdir/pred_$feat.out $outdir/$feat\_$class.true.out";
#	}
}
print RCMD "dev.off()";
close(RCMD);
