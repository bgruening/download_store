#!/usr/bin/perl
use strict;
use warnings;
use List::Util qw(sum max);
use Getopt::Long;
use Pod::Usage;
use Cwd 'abs_path';

## cd /scratch/bi02/videmp/BlockClust/mcl_optization/26-08-13/validation
## for i in {1..10};do echo "***"$i"***"; perl ~/bin/calculatePrecisionPerClass.pl -dir $i -t 0.75;done;
## for i in *known.out.26-08-13;do echo $i;~/install/mcl-12-135/bin/mcl $i/discretized.gspan.tab --abc -pi 15 -I 15 -o $i/mcl.out &> mcl.log; perl ../../src/scripts/calculatePrecisionPerClass.pl -f $i/mcl.out -t 0.5;done

my ($help, $man, $in_file, $threshold);
$threshold = 0.5;
my $options = GetOptions (
				"help"	=> \$help,
				"man"	=> \$man,
				"f=s"	=> \$in_file,
				"t=s"	=> \$threshold
			);

pod2usage(-exitstatus => 0, -verbose => 1) if $help;
pod2usage(-exitstatus => 0, -verbose => 2) if $man;



my %finalHash = ();
my $highest_avg_precision = 0;
my %avg_precision_map = ();
$in_file = abs_path($in_file);


my %clusterPrecisionHash = ();

open IN, $in_file or die $!;
my %precisionMap = ();
my $discarded_clusters = 0;
my $discarded_instances = 0;
my $total_instances = 0;
my $cluster_count = 0;
while(<IN>){
	chomp($_);
	my %classMap = ();
	$cluster_count++;
	my (@fields) = split('\t',$_);
	foreach my $field (@fields){
		$field =~ m/(.+):(.+):(.+)/;
		$classMap{$2}++;
	}
	$total_instances += sum(values %classMap);

	if(sum(values %classMap) < 3){
		$discarded_clusters++;
		$discarded_instances += sum(values %classMap);
		next;
	}
	my $majority_class;
	my $TP = 0;
	print  $cluster_count;
	foreach my $class (keys %classMap){
		if($classMap{$class} > $TP){
			$TP = $classMap{$class};
			$majority_class = $class;
		}
		if($majority_class ne $class && $class eq "unknown"){
			$TP += $classMap{$class};
		}
		print "\t",$class,"\t",$classMap{$class};
	}
	print "\n";

	my @class_counts = sort{$b<=>$a} values %classMap;
	my $precision = $TP/sum(values %classMap);
	push(@{$precisionMap{$majority_class}},$precision);
	
	$clusterPrecisionHash{$cluster_count}{sum(values %classMap)} = $precision;
}
close IN;


my @cluster_precisions = ();
my @cluster_sizes = ();
my $sum_precision = 0;

foreach my $cluster (keys %clusterPrecisionHash){
	foreach my $size (keys %{$clusterPrecisionHash{$cluster}}){
		my $cluster_precision = $clusterPrecisionHash{$cluster}{$size};
		print $size,"\t",$cluster_precision,"\n";
		$sum_precision += $cluster_precision;
		push(@cluster_precisions, $cluster_precision);
		push(@cluster_sizes, $size);
	}
}

my $no_of_clusters = keys %clusterPrecisionHash;

## No of clusters
#print $no_of_clusters,"\t"; 

## Median of cluster size
#print median(@cluster_sizes),"\t";

## Average
#print $sum_precision/$no_of_clusters,"\n";

## Median
#print median(@cluster_precisions),"\n";


sub median
{
    my @vals = sort {$a <=> $b} @_;
    my $len = @vals;
    if($len%2) #odd?
    {
        return $vals[int($len/2)];
    }
    else #even
    {
        return ($vals[int($len/2)-1] + $vals[int($len/2)])/2;
    }
}


my  $sum = 0; my $count = 0;
my $ignore_file = 0;


if(scalar keys %precisionMap < 1 || $discarded_instances > 0.2*$total_instances){
	$ignore_file = 1;
	print scalar keys %precisionMap,"\n";
	print $total_instances,"\t",$discarded_instances,"\n";
}
if($ignore_file == 0){
	foreach my $class (sort keys %precisionMap){
		my @class_precisions = @{$precisionMap{$class}};
		my $avg_class_precision = sum(@class_precisions)/($#class_precisions+1);
		if($class =~ m/miRNA|tRNA/ && $avg_class_precision < $threshold){
			$ignore_file = 1;
			next;
		}
		if($ignore_file == 0){
			foreach my $class_precision (@class_precisions){
				$sum += $class_precision;
				$count++;
			}				
		}
	}
	
	if($ignore_file == 0){		
		my $avg_precision = $sum/$count;
		if($avg_precision > $highest_avg_precision) {
			$highest_avg_precision = $avg_precision;
			$finalHash{'Avg precision'} =  $highest_avg_precision;
			$finalHash{'discarded_clusters'} = $discarded_clusters;
			$finalHash{'discarded_instances'} = $discarded_instances;
			$finalHash{'file'} = $in_file;
			$finalHash{'classMap'} = \%precisionMap;	
		}
		$avg_precision_map{$in_file} = $avg_precision;
	}
}

foreach my $key (sort keys %finalHash){
	if($key eq 'classMap'){
		my %precisionMap = %{$finalHash{$key}};
		foreach my $class (sort keys %precisionMap){
			my @class_precisions = @{$precisionMap{$class}};
			my $avg_class_precision = sum(@class_precisions)/($#class_precisions+1);
			print $class,"\t", $#class_precisions+1,"\t", $avg_class_precision,"\n";
		}
	}
	else{
		print $key, "\t", $finalHash{$key},"\n";			
	}
}
print "\n";


