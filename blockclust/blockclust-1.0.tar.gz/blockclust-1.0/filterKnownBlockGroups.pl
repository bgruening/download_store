#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Long;
use Cwd 'abs_path';
use Pod::Usage;

=head1 NAME

filterKnownBBGroups.pl

=head1 SYNOPSIS

perl filterKnownBBGroups.pl -ncbed [ncRNA BED file] -rbed [reads BED file] -od 

=head1 OPTIONS

        -help       brief help message
        -man        full documentation
        -bbo        Blockbuster output
        -out        output bbo
                        
=head1 DESCRIPTION
         
=cut

my ($help, $man, $blk, $output);

my $options = GetOptions ("help"        => \$help,
                         "man"          => \$man,
                         "bbo=s"     	=> \$blk,
                         "out=s"	=> \$output
                         );

pod2usage(-exitstatus => 1, -verbose => 1) if ($help || !$blk || !$output);
pod2usage(-exitstatus => 0, -verbose => 2) if $man;

#$blk =~ s/\.bbo//;
open BBO, $blk or die $!;
my %blockGroupsHash = ();
my $considerCluster = 0;
my $currentBlockGroup;
while(<BBO>){
        my $line = $_;
        chomp($line);
        if($line =~ m/^>cluster/){
       		$considerCluster = 0;
        }        
		if($line =~ m/^>cluster/ && $line !~ m/unknown/){
       		$currentBlockGroup = $line;
       		$considerCluster = 1;
        }
        else{
        	if($considerCluster == 1){
        		push (@{$blockGroupsHash{$currentBlockGroup}}, $line);
        	}
        }
}
close BBO;

my @dirs = split('/', $blk);
$blk = pop(@dirs);


open ABBO, ">$output" or die $!;
foreach my $blockGroup (sort keys %blockGroupsHash){
	print ABBO $blockGroup,"\n";
	foreach my $tag (@{$blockGroupsHash{$blockGroup}}) {
		print ABBO $tag,"\n";
	}
}
close ABBO;
