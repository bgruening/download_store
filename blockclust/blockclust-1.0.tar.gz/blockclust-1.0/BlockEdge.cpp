/*
 * BlockEdge.cpp
 *
 *  Created on: Nov 9, 2012
 *      Author: videmp
 */

#include "BlockEdge.h"

BlockEdge::BlockEdge(){
}

BlockEdge::BlockEdge(Block lBlock, Block rBlock){
	leftBlock = lBlock;
	rightBlock = rBlock;
}

BlockEdge::~BlockEdge(){
}

Block BlockEdge::getLeftBlock(){ return leftBlock; }
Block BlockEdge::getRightBlock(){ return rightBlock; }

/////////////////////////////////////////

double BlockEdge::blockContiguity(){
	unsigned long leftBlockStart = getLeftBlock().getStart();
	unsigned long rightBlockStart = getRightBlock().getStart();
	unsigned long leftBlockEnd = getLeftBlock().getEnd();
	unsigned long rightBlockEnd = getRightBlock().getEnd();


	double edgeLength = 0;
	long overlapLength = 0;
	double percentageOverlap = 0;

	if(leftBlockStart <= rightBlockStart){
		if(rightBlockStart < leftBlockEnd){
			if(leftBlockEnd < rightBlockEnd){
				edgeLength = rightBlockEnd-leftBlockStart+1;
				overlapLength = leftBlockEnd-rightBlockStart+1;
			}
			else{
				edgeLength = leftBlockEnd -leftBlockStart+1;
				overlapLength = rightBlockEnd-rightBlockStart+1;
			}
		}
		else{
			edgeLength = rightBlockEnd-leftBlockStart+1;
			overlapLength = leftBlockEnd-rightBlockStart+1;
		}
	}
	else{
		if(leftBlockStart < rightBlockEnd){
			if(rightBlockEnd < leftBlockEnd){
				edgeLength = leftBlockEnd-rightBlockStart+1;
				overlapLength = rightBlockEnd-leftBlockStart+1;
			}
			else{
				edgeLength = rightBlockEnd -rightBlockStart+1;
				overlapLength = leftBlockEnd-leftBlockStart+1;
			}
		}
		else{
			edgeLength = leftBlockEnd-rightBlockStart+1;
			overlapLength = rightBlockEnd-leftBlockStart+1;
		}
	}
	percentageOverlap = (overlapLength/edgeLength)*100;
	return percentageOverlap;
}

/////////////////////////////////////////

double BlockEdge::expressionDiff(){
	double leftBlockExpression = getLeftBlock().getExpression();
	double rightBlockExpression = getRightBlock().getExpression();
	double expressionDiff =  leftBlockExpression > rightBlockExpression ? leftBlockExpression - rightBlockExpression : rightBlockExpression - leftBlockExpression;
	return expressionDiff;
}

/////////////////////////////////////////

double BlockEdge::lengthDiff(){
	double leftBlockLength = getLeftBlock().getLength();
	double rightBlockLength = getRightBlock().getLength();
	double lengthDiff =  leftBlockLength > rightBlockLength ? leftBlockLength - rightBlockLength : rightBlockLength - leftBlockLength;
	return lengthDiff;
}

/////////////////////////////////////////

double BlockEdge::areaDiff(){
	double leftBlockArea = getLeftBlock().getArea();
	double rightBlockArea = getRightBlock().getArea();
	double areaDiff =  leftBlockArea > rightBlockArea ? leftBlockArea - rightBlockArea : rightBlockArea - leftBlockArea;
	return areaDiff;
}

/////////////////////////////////////////

double BlockEdge::occupancyDiff(){
	double leftBlockOccupancy = getLeftBlock().blockOccupancy();
	double rightBlockOccupancy = getRightBlock().blockOccupancy();
	double occupancyDiff =  leftBlockOccupancy > rightBlockOccupancy ? leftBlockOccupancy - rightBlockOccupancy : rightBlockOccupancy - leftBlockOccupancy;
	return occupancyDiff;
}

/////////////////////////////////////////

double BlockEdge::medianExpressionDiff(){
	double leftBlockMedianExpression = getLeftBlock().medianReadExpression();
	double rightBlockMedianExpression = getRightBlock().medianReadExpression();
	double medianExpressionDiff =  leftBlockMedianExpression > rightBlockMedianExpression ? leftBlockMedianExpression - rightBlockMedianExpression : rightBlockMedianExpression - leftBlockMedianExpression;
	return medianExpressionDiff;
}

/////////////////////////////////////////

double BlockEdge::meanExpressionDiff(){
	double leftBlockMeanExpression = getLeftBlock().meanReadExpression();
	double rightBlockMeanExpression = getRightBlock().meanReadExpression();
	double meanExpressionDiff =  leftBlockMeanExpression > rightBlockMeanExpression ? leftBlockMeanExpression - rightBlockMeanExpression : rightBlockMeanExpression - leftBlockMeanExpression;
	return meanExpressionDiff;
}
