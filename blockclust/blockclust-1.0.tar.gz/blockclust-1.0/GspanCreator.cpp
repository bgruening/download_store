/*
 * GspanCreator.cpp
 *
 *  Created on: Nov 29, 2012
 *      Author: videmp
 */

#include "GspanCreator.h"

GspanCreator::GspanCreator(){
//	seqenceDegree = 0;
}

GspanCreator::~GspanCreator(){
}

unsigned short GspanCreator::getSequenceDegree(){
	return seqenceDegree;
}

void GspanCreator::createGspanFile(string configuration, string featuresFile, string outputDir){
    char blockGroupFeatures[1000] = "";
    char blockFeatures[1000]= "";
    char blockEdgeFeatures[1000]= "";

    sscanf(configuration.c_str(), "%s %s %s", blockGroupFeatures, blockFeatures, blockEdgeFeatures);
    int count = 0;
    for (int i = 0; i < 1000; i++){
    	 if (blockEdgeFeatures[i] == ',')
    		 count++;
		 if(blockFeatures[i] == ',')
			 count++;
    }
    seqenceDegree = count + 2;
    vector<string> bgf = split(",", blockGroupFeatures);
    vector<string> bf = split(",", blockFeatures);
    vector<string> bef = split(",", blockEdgeFeatures);

    ifstream FF;
    FF.open(featuresFile.c_str());
	if(!FF.is_open()){
	    cerr << "Error opening file '" << featuresFile << "'!!!" << endl;
	    exit(1);
	}
    ofstream OUT;
    OUT.open((outputDir + "/discretized.gspan").c_str());
	if(!OUT.is_open()){
	    cerr << "Error opening file '" << outputDir << "/discretized.gspan'!!!" << endl;
	    exit(1);
	}
	string LINE;
	getline(FF, LINE);

	map <unsigned short, string> featureNamesMap;
	vector<string> featureNames = split("\t", LINE);
	for(unsigned int i=0; i<featureNames.size(); i++){
		featureNamesMap[i] = featureNames[i];
	}

	map<unsigned short, string>::iterator it;
	while(!FF.eof()){
		getline(FF, LINE);
		if(!LINE.empty()){
			map <string, vector<string> > featureValuesMap;
			vector<string> featureValues = split("\t", LINE);
			for(unsigned int i=1; i<featureValues.size(); i++){
				featureValuesMap[featureNamesMap.find(i)->second] = split(",", featureValues[i]);
			}
			for(unsigned int i=0; i<bgf.size(); i++){
				OUT << featureValuesMap.find(bgf[i])->second[0];
				for(unsigned short j=1; j<seqenceDegree; j++){
					OUT << "0";
				}
			}

			OUT << "|";
			size_t numberOfBlocks = featureValuesMap.find(bf[0])->second.size();
			for(unsigned int i=0; i<numberOfBlocks; i++){
				for(unsigned int j=0; j<bf.size(); ++j){
					OUT << featureValuesMap.find(bf[j])->second[i];
				}
				for(unsigned int j=0; j<bef.size(); j++){
					if(i < featureValuesMap.find(bef[j])->second.size()){
						OUT << featureValuesMap.find(bef[j])->second[i];
					}
					else
						OUT << "N";
				}
			}
			OUT << endl;
			featureValuesMap.clear();
		}
	}
	FF.close();
	OUT.close();
	featureNamesMap.clear();
	bgf.clear(); bf.clear(); bef.clear();
    return;
}

/////////////////////////////////////////////

void GspanCreator::createGspanGraphFormat(string configuration, string featuresFile, string outputDir){
    char blockGroupFeatures[100] = "";
    char blockFeatures[100]= "";
    char blockEdgeFeatures[100]= "";

    sscanf(configuration.c_str(), "%s %s %s", blockGroupFeatures, blockFeatures, blockEdgeFeatures);
    vector<string> bgf = split(",", blockGroupFeatures);
    vector<string> bf = split(",", blockFeatures);
    vector<string> bef = split(",", blockEdgeFeatures);
    ifstream FF;
    FF.open(featuresFile.c_str());
	if(!FF.is_open()){
	    cerr << "Error opening file '" << featuresFile << "'!!!" << endl;
	    exit(1);
	}
    ofstream OUT;
    OUT.open((outputDir + "/discretized.gspan").c_str());
	if(!OUT.is_open()){
	    cerr << "Error opening file '" << outputDir << "/discretized.gspan'!!!" << endl;
	    exit(1);
	}

	string LINE;
	getline(FF, LINE);
	map <unsigned short, string> featureNamesMap;
	vector<string> featureNames = split("\t", LINE);
	for(unsigned int i=1; i<featureNames.size(); i++){
		featureNamesMap[i] = featureNames[i];
	}

	while(!FF.eof()){
		getline(FF, LINE);
		if(!LINE.empty()){
			map <string, vector<string> > featureValuesMap;
			vector<string> featureValues = split("\t", LINE);

			for(unsigned int i=0; i<featureValues.size(); i++){
				featureValuesMap[featureNamesMap.find(i)->second] = split(",", featureValues[i]);
			}

			OUT << "t" << " " << featureValues[0] << endl;
			OUT << "v" << " " << featureValues[0];
			for(unsigned int i=0; i<bgf.size(); i++){
//				for(unsigned int j=0; j<split(",", featureValues[i]).size(); j++){
//					cout << featureValuesMap.find(bgf[i])->second[j] << endl;
//				}	
				OUT << " " << featureValuesMap.find(bgf[i])->second[0];
			}
			OUT << endl;
			size_t numberOfBlocks = featureValuesMap.find(bf[0])->second.size();
			for(unsigned int i=0; i<numberOfBlocks; i++){
				OUT << "v" << " " << "b" << i;
				for(unsigned int j=0; j<bf.size(); ++j){
					OUT << " " << featureValuesMap.find(bf[j])->second[i];
				}
				OUT << endl;
			}

			// initial vertex to first block
			OUT << "e" << " " << featureValues[0] << " " << "b0" << " " << "C" << endl;
			size_t numberOfBlockEdges = featureValuesMap.find(bef[0])->second.size();
			// block edges
			for(unsigned int i=0; i<numberOfBlockEdges; i++){
				OUT << "e" << " " << "b" << i << " " << "b" << i+1;
				for(unsigned int j=0; j<bef.size(); ++j){
					OUT << " " << featureValuesMap.find(bef[j])->second[i];
				}
				OUT << endl;
			}
			featureValuesMap.clear();
		}
	}
	FF.close();
	OUT.close();
	featureNamesMap.clear();
	bgf.clear(); bf.clear(); bef.clear();
}

/////////////////////////////////////////////

void GspanCreator::createGspanSubGraphFormat(string configuration, string featuresFile, string outputDir){
    char blockGroupFeatures[100] = "";
    char blockFeatures[100]= "";
    char blockEdgeFeatures[100]= "";

    sscanf(configuration.c_str(), "%s %s %s", blockGroupFeatures, blockFeatures, blockEdgeFeatures);
    vector<string> bgf = split(",", blockGroupFeatures);
    vector<string> bf = split(",", blockFeatures);
    vector<string> bef = split(",", blockEdgeFeatures);

    ifstream FF;
    FF.open(featuresFile.c_str());
	if(!FF.is_open()){
	    cerr << "Error opening file '" << featuresFile << "'!!!" << endl;
	    exit(1);
	}
    ofstream OUT;
    OUT.open((outputDir + "/discretized.gspan").c_str());
	if(!OUT.is_open()){
	    cerr << "Error opening file '" << outputDir << "/discretized.gspan'!!!" << endl;
	    exit(1);
	}

	string LINE;
	getline(FF, LINE);
	map <unsigned short, string> featureNamesMap;
	vector<string> featureNames = split("\t", LINE);
	for(unsigned int i=1; i<featureNames.size(); i++){
		featureNamesMap[i] = featureNames[i];
	}

	while(!FF.eof()){
		getline(FF, LINE);
		if(!LINE.empty()){
			map <string, vector<string> > featureValuesMap;
			vector<string> featureValues = split("\t", LINE);
			for(unsigned int i=0; i<featureValues.size(); i++){
				featureValuesMap[featureNamesMap.find(i)->second] = split(",", featureValues[i]);
			}
			OUT << "t" << " " << featureValues[0] << endl;
			OUT << "v" << " " << featureValues[0] << " " << "G" << endl;
			for(unsigned int i=0; i<bgf.size(); i++){
				OUT << "v" << " " << "g" << i << " " << featureValuesMap.find(bgf[i])->second[0] << endl;
			}
			size_t numberOfBlocks = featureValuesMap.find(bf[0])->second.size();
			for(unsigned int i=0; i<numberOfBlocks; i++){
				OUT << "v" << " " << "b" << i << " " << "B" << endl;
				for(unsigned int j=0; j<bf.size(); ++j){
					OUT << "v" << " " << "b" << i << j << " " << featureValuesMap.find(bf[j])->second[i] << endl;
				}
			}

			size_t numberOfBlockEdges = featureValuesMap.find(bef[0])->second.size();
			for(unsigned int i=0; i<numberOfBlockEdges; i++){
				OUT << "v" << " " << "e" << i << " " << "E" << endl;
				for(unsigned int j=0; j<bef.size(); ++j){
					OUT << "v" << " " << "e" << i << j << " " << featureValuesMap.find(bef[j])->second[i] << endl;
				}
			}
			// initial vertex to first block
			OUT << "e" << " " << featureValues[0] << " " << "g0" << " " << "C" << endl;
			OUT << "e" << " " << featureValues[0] << " " << "b00" << " " << "C" << endl;
			// block group sub-features edges
			for(unsigned int i=1; i<bgf.size(); i++){
				OUT << "e" << " " << "g" << i-1 << " " << "g" << i << " " << "C" << endl;
			}
			// block sub-features edges
			for(unsigned int i=0; i<numberOfBlocks; i++){
				OUT << "e" << " " << "b" << i << " " << "b" << i << "0" << " "  << "C" << endl;
				for(unsigned int j=1; j<bf.size(); ++j){
					OUT << "e" << " " << "b" << i << j-1 << " " << "b" << i << j << " "  << "C" << endl;
				}
			}
			// block edge sub-features edges
			for(unsigned int i=0; i<numberOfBlockEdges; i++){
				OUT << "e" << " " << "e" << i << " " << "e" << i << "0" << " "  << "C" << endl;
				for(unsigned int j=1; j<bf.size(); ++j){
					OUT << "e" << " " << "e" << i << j-1 << " " << "e" << i << j << " " << "C" << endl;
				}
				OUT << "e" << " " << "e" << i << bf.size()-1 << " " << "b" << i+1 << " " << "C" << endl;
			}

			// all edge feature labels
//			size_t numberOfBlockEdges = featureValuesMap.find(bef[0])->second.size();
//			for(unsigned int i=0; i<numberOfBlockEdges; i++){
//				OUT << "e" << " " << "b" << i << " " << "b" << i+1 <<  " ";
//				for(unsigned int j=0; j<bef.size(); ++j){
//					OUT << featureValuesMap.find(bef[j])->second[i] << " ";
//				}
//				OUT << endl;
//			}
			featureValuesMap.clear();
		}
	}
	FF.close();
	OUT.close();
	featureNamesMap.clear();
	bgf.clear(); bf.clear(); bef.clear();
}

/////////////////////////////////////////////

void GspanCreator::createParallelSubGraphFormat(string configuration, string featuresFile, string outputDir){
    char blockGroupFeatures[100] = "";
    char blockFeatures[100]= "";
    char blockEdgeFeatures[100]= "";

    sscanf(configuration.c_str(), "%s %s %s", blockGroupFeatures, blockFeatures, blockEdgeFeatures);
    vector<string> bgf = split(",", blockGroupFeatures);
    vector<string> bf = split(",", blockFeatures);
    vector<string> bef = split(",", blockEdgeFeatures);

    ifstream FF;
    FF.open(featuresFile.c_str());
	if(!FF.is_open()){
	    cerr << "Error opening file '" << featuresFile << "'!!!" << endl;
	    exit(1);
	}
    ofstream OUT;
    OUT.open((outputDir + "/discretized.gspan").c_str());
	if(!OUT.is_open()){
	    cerr << "Error opening file '" << outputDir << "/discretized.gspan'!!!" << endl;
	    exit(1);
	}

	string LINE;
	getline(FF, LINE);
	map <unsigned short, string> featureNamesMap;
	vector<string> featureNames = split("\t", LINE);
	for(unsigned int i=1; i<featureNames.size(); i++){
		featureNamesMap[i] = featureNames[i];
	}

	while(!FF.eof()){
		getline(FF, LINE);
		if(!LINE.empty()){
			map <string, vector<string> > featureValuesMap;
			vector<string> featureValues = split("\t", LINE);
			for(unsigned int i=0; i<featureValues.size(); i++){
				featureValuesMap[featureNamesMap.find(i)->second] = split(",", featureValues[i]);
			}
			OUT << "t" << " " << featureValues[0] << endl;
			OUT << "v" << " " << featureValues[0] << " " << "G" << endl;
			for(unsigned int i=0; i<bgf.size(); i++){
				OUT << "v" << " " << "g" << i << " " << featureValuesMap.find(bgf[i])->second[0] << endl;
			}
			size_t numberOfBlocks = featureValuesMap.find(bf[0])->second.size();
			for(unsigned int i=0; i<numberOfBlocks; i++){
				OUT << "v" << " " << "b" << i << " " << "B" << endl;
				for(unsigned int j=0; j<bf.size(); ++j){
					OUT << "v" << " " << "b" << i << j << " " << featureValuesMap.find(bf[j])->second[i] << endl;
				}
			}

			// initial vertex to first block
			OUT << "e" << " " << featureValues[0] << " " << "g0" << " " << "C" << endl;
			// Parellel edges intial vertex to block nodes
			for(unsigned int i=0; i<numberOfBlocks; i++){
				OUT << "e" << " " << featureValues[0] << " " << "b" << i << " " << "C" << endl;
			}
			// block group sub-features edges
			for(unsigned int i=1; i<bgf.size(); i++){
				OUT << "e" << " " << "g" << i-1 << " " << "g" << i << " " << "C" << endl;
			}
			// all edge feature labels
			size_t numberOfBlockEdges = featureValuesMap.find(bef[0])->second.size();
			for(unsigned int i=0; i<numberOfBlockEdges; i++){
				OUT << "e" << " " << "b" << i << " " << "b" << i+1 <<  " ";
				for(unsigned int j=0; j<bef.size(); ++j){
					OUT << featureValuesMap.find(bef[j])->second[i] << " ";
				}
				OUT << endl;
			}
			featureValuesMap.clear();
		}
	}
	FF.close();
	OUT.close();
	featureNamesMap.clear();
	bgf.clear(); bf.clear(); bef.clear();
}

/////////////////////////////////////////////

void GspanCreator::createPartialSubGraphFormat(string configuration, string featuresFile, string outputDir){
    char blockGroupFeatures[100] = "";
    char blockFeatures[100]= "";
    char blockEdgeFeatures[100]= "";

    sscanf(configuration.c_str(), "%s %s %s", blockGroupFeatures, blockFeatures, blockEdgeFeatures);
    vector<string> bgf = split(",", blockGroupFeatures);
    vector<string> bf = split(",", blockFeatures);
    vector<string> bef = split(",", blockEdgeFeatures);

    ifstream FF;
    FF.open(featuresFile.c_str());
	if(!FF.is_open()){
	    cerr << "Error opening file '" << featuresFile << "'!!!" << endl;
	    exit(1);
	}
    ofstream OUT;
    OUT.open((outputDir + "/discretized.gspan").c_str());
	if(!OUT.is_open()){
	    cerr << "Error opening file '" << outputDir << "/discretized.gspan'!!!" << endl;
	    exit(1);
	}

	string LINE;
	getline(FF, LINE);
	map <unsigned short, string> featureNamesMap;
	vector<string> featureNames = split("\t", LINE);
	for(unsigned int i=1; i<featureNames.size(); i++){
		featureNamesMap[i] = featureNames[i];
	}

	while(!FF.eof()){
		getline(FF, LINE);
		if(!LINE.empty()){
			map <string, vector<string> > featureValuesMap;
			vector<string> featureValues = split("\t", LINE);
			for(unsigned int i=0; i<featureValues.size(); i++){
				featureValuesMap[featureNamesMap.find(i)->second] = split(",", featureValues[i]);
			}
			OUT << "t" << " " << featureValues[0] << endl;
			OUT << "v" << " " << featureValues[0] << " " << "G" << endl;
			for(unsigned int i=0; i<bgf.size(); i++){
				OUT << "v" << " " << "g" << i << " " << featureValuesMap.find(bgf[i])->second[0] << endl;
			}
			size_t numberOfBlocks = featureValuesMap.find(bf[0])->second.size();
			for(unsigned int i=0; i<numberOfBlocks; i++){
				OUT << "v" << " " << "b" << i << " " << "B" << endl;
				for(unsigned int j=0; j<bf.size(); ++j){
					OUT << "v" << " " << "b" << i << j << " " << featureValuesMap.find(bf[j])->second[i] << endl;
				}
			}

			// initial vertex to first block
			OUT << "e" << " " << featureValues[0] << " " << "g0" << " " << "C" << endl;
			OUT << "e" << " " << featureValues[0] << " " << "b00" << " " << "C" << endl;
			// block group sub-features edges
			for(unsigned int i=1; i<bgf.size(); i++){
				OUT << "e" << " " << "g" << i-1 << " " << "g" << i << " " << "C" << endl;
			}
			// block sub-features edges
			for(unsigned int i=0; i<numberOfBlocks; i++){
				OUT << "e" << " " << "b" << i << " " << "b" << i << "0" << " "  << "C" << endl;
				for(unsigned int j=1; j<bf.size(); ++j){
					OUT << "e" << " " << "b" << i << j-1 << " " << "b" << i << j << " "  << "C" << endl;
				}
			}

			// all edge feature labels
			size_t numberOfBlockEdges = featureValuesMap.find(bef[0])->second.size();
			for(unsigned int i=0; i<numberOfBlockEdges; i++){
				OUT << "e" << " " << "b" << i << " " << "b" << i+1 <<  " ";
				for(unsigned int j=0; j<bef.size(); ++j){
					OUT << featureValuesMap.find(bef[j])->second[i] << " ";
				}
				OUT << endl;
			}
			featureValuesMap.clear();
		}
	}
	FF.close();
	OUT.close();
	featureNamesMap.clear();
	bgf.clear(); bf.clear(); bef.clear();
}

/////////////////////////////////////////////

vector<string> GspanCreator::split(const string& delim, const string& str){
    size_t start_pos = 0;
    size_t match_pos;
    size_t substr_length;
    vector<string> result;
    while((match_pos = str.find(delim, start_pos)) != string::npos){
    	substr_length = match_pos - start_pos;
        if (substr_length > 0){
            result.push_back(str.substr(start_pos, substr_length));
        }
        start_pos = match_pos + delim.length();
    }
    substr_length = str.length() - start_pos;
    if (substr_length > 0){
        result.push_back(str.substr(start_pos, substr_length));
    }
    return result;
}



