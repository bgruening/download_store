args <- commandArgs(trailingOnly = TRUE)

if(args[1]=="clust"){
    library(ape)
    #library(RColorBrewer)
    mydata<-read.table(args[2], sep=" ", header=FALSE, row.names=1)
    d <- dist(mydata, method = "euclidean")
    fit <- hclust(d, method="ward")
    p <- as.phylo(fit)
    annot<-read.table(args[3], sep="\t", header=FALSE, row.names=1)
    cols <- c("darkblue","red", "green", "tomato", "grey", "purple", "orange", "yellow", "pink", "cyan")
    #cols <- brewer.pal(n=length(unique(as.numeric(factor(annot$V2)))), 'Dark2') #Accent Dark2 Paired Pastel1 Pastel2 Set1 Set2 Set3
    pdf(args[4], width=10, height=10)
    par(xpd=TRUE)
    plot(p, type="fan", tip.color=cols[as.numeric(factor(annot$V2))], cex=0.5, adj=1, label.offset=0.5, font=2) #no.margin=TRUE,
    tiplabels(pch=19, cex=0.5, col=cols[as.numeric(factor(annot$V2))])#p$tip.label
    legend('topleft', legend=unique(sort(annot$V2)), pt.bg=cols, pt.cex=0.5, pch=21, cex=0.5, bty='o')
    dev.off()
}else if(args[1]=="hist"){
    mydat<-read.table(args[2], sep="\t", header=TRUE)
    library(ggplot2)
    pdf(args[3], width=15, height=10)
    ggplot(mydat, aes(Clusters, fill=RNA_type)) + geom_bar() + theme(axis.text.x = element_text(angle = 90, hjust = 1))
    dev.off()
}else{
    write("Undefined plotting mode!", stderr())
}

