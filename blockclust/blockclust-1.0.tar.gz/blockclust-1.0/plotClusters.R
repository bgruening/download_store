args <- commandArgs(trailingOnly = TRUE)
library('methods')
if(args[1]=="clust"){
    library('ape') #suppressPackageStartupMessages(
    mydata<-read.table(args[2], sep=" ", header=FALSE, row.names=1)
    mydata<-scale(mydata);
    d <- dist(mydata, method = "euclidean")
    fit <- hclust(d, method="average")
    p <- as.phylo(fit)
    write.tree(p, file=args[3])
    annot<-read.table(args[4], sep="\t", header=FALSE, row.names=1)
    rn<-row.names(mydata)
    classes<-unique(annot$V2)
    annot$V2<-as.numeric(annot$V2)
    pdf(args[5], width=12, height=8)
    par(xpd=TRUE)
    library('squash')
    cols <- c("lightskyblue", "red1", "tomato", "gray10", "blue", "cyan", "darkmagenta", "orange", "yellow", "grey", "red4", "pink",  "darkgreen",  "navajowhite2", "palegreen", "darkviolet", "chartreuse", "plum2", "sienna1", "orangered1")
    map <- makecmap(annot$V2, breaks=c(1:length(cols)), colFn = colorRampPalette(cols))
    map$colors<-cols
    annot <- data.frame(V2 = cmap(annot$V2,map))
    n<-length(annot$V2)*0.01
    if(n>1)
        n=0.9
    dendromat(fit, annot, gap = 0.1, cex=1)
    legend('topright', legend = classes, fill = as.character(unique(annot$V2)))
    dev.off()
}else if(args[1]=="hist"){
    mydat<-read.table(args[2], sep="\t", header=TRUE)
    par(xpd=TRUE)
    library('ggplot2') #suppressPackageStartupMessages(
#    pdf(args[3], width=15, height=10)
    cols <- c("lightskyblue", "red1", "tomato", "gray10", "blue", "cyan", "darkmagenta", "orange", "yellow", "grey", "red4", "pink",  "darkgreen",  "navajowhite2", "palegreen", "darkviolet", "chartreuse", "plum2", "sienna1", "orangered1") #, 
    print(length(unique(mydat$RNA_type)))
    p<-qplot(Clusters, data=mydat, geom="bar", fill=factor(RNA_type))+theme(axis.text.x = element_text(angle = 90, hjust = 1))+scale_fill_manual(values=cols)
    ggsave(args[3], p, width=15, height=10) 
#    ggplot(mydat, aes(Clusters, fill=RNA_type)) + geom_bar() + theme(axis.text.x = element_text(angle = 90, hjust = 1))
#    dev.off()
}else{
    write("Undefined plotting mode!", stderr())
}
