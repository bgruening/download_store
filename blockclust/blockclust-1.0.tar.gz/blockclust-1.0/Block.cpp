/*
 * Block.cpp
 *
 *  Created on: Nov 9, 2012
 *      Author: videmp
 */

#include "Block.h"

Block::Block(){
	blockId = 0;
	blockStart = 0;
	blockEnd = 0;
	blockExpression = 0;
}

Block::Block(int blkId, unsigned long blkStart, unsigned long blkEnd, double blkExpression){
	blockId = blkId;
	blockStart = blkStart;
	blockEnd = blkEnd;
	blockExpression = blkExpression;
}

Block::~Block(){
}

unsigned long Block::getStart(){ return blockStart; }
unsigned long Block::getEnd(){ return blockEnd; }
double Block::getLength(){ return blockEnd - blockStart + 1; }
double Block::getExpression(){ return blockExpression; }
double Block::getArea(){ return getLength()*getExpression();}
vector<Read> Block::getReads(){ return reads; }
void Block::setReads(vector<Read> blockReads){ reads = blockReads; }


double Block::blockOccupancy(){
	vector<Read> reads= getReads();
	map<unsigned long, Read> startPosReadMap;
	map<unsigned long, Read> endPosReadMap;

	double highestExpression = 0;
	for (unsigned long i=0; i<reads.size(); ++i){
		if(reads[i].getExpression() > highestExpression)
			highestExpression = reads[i].getExpression();
		if(startPosReadMap.find(reads[i].getStart()) == startPosReadMap.end()){
			startPosReadMap[reads[i].getStart()] = reads[i];
		}
		else{
			if(reads[i].getExpression() > startPosReadMap.find(reads[i].getStart())->second.getExpression()){
				startPosReadMap[reads[i].getStart()] = reads[i];
			}
		}

		if(endPosReadMap.find(reads[i].getEnd()) == endPosReadMap.end()){
			endPosReadMap[reads[i].getEnd()] = reads[i];
		}
		else{
			if(reads[i].getExpression() > endPosReadMap.find(reads[i].getEnd())->second.getExpression()){
				endPosReadMap[reads[i].getEnd()] = reads[i];
			}
		}
	}

	map<unsigned long, Read>::iterator pos;

	double readProfileArea = 0;
	double previousExpresion = 0;
	double previousArea = 0;
	unsigned long previousStart = startPosReadMap.begin()->first;
	for(pos = startPosReadMap.begin(); pos != startPosReadMap.end(); ++pos){
		if(pos->second.getExpression() >= previousExpresion){
			readProfileArea += (pos->first-previousStart)*previousExpresion;
			previousStart = pos->first;
			previousExpresion = pos->second.getExpression();
		}
	}
	unsigned long previousEnd = startPosReadMap.find(previousStart)->second.getEnd();

	readProfileArea += (previousEnd-previousStart)*previousExpresion;

	for(pos = endPosReadMap.begin(); pos != endPosReadMap.end(); ++pos){
		if(previousEnd < pos->first){
			if(pos->second.getExpression() < previousExpresion){
				readProfileArea += (pos->first-previousEnd)*pos->second.getExpression();
				previousEnd = pos->first;
				previousExpresion = pos->second.getExpression();
				previousArea = (pos->first-previousEnd)*pos->second.getExpression();
			}
			if(pos->second.getExpression() == previousExpresion){
				readProfileArea -= previousArea;
				readProfileArea += (pos->first-previousEnd)*pos->second.getExpression();
				previousEnd = pos->first;
				previousExpresion = pos->second.getExpression();
			}
		}
	}
	double blockOccupancy = readProfileArea/(getLength()*highestExpression);

	if(blockOccupancy > 1){
		cerr << "Block ocupancy > 1!!!" << endl;
		exit(1);
	}
	startPosReadMap.clear();
	endPosReadMap.clear();
	return blockOccupancy;
}

////////////////////////////////////////////

double Block::readLengthEntropy(){
	map<double, unsigned int> readLengthMap;
	float numberOfReads=0;
	vector<Read> readsList = getReads();
	vector<Read>::iterator readIterator;
	for ( readIterator = readsList.begin(); readIterator != readsList.end(); ++readIterator ){
		double readLength = readIterator->getLength();
		readLengthMap[readLength]++;
		numberOfReads++;
	}
	double readLengthEntropy = 0;
	for( map<double, unsigned int>::iterator ii=readLengthMap.begin(); ii!=readLengthMap.end(); ++ii){
		unsigned int lengthFrequency = ii->second;
		double lengthProbability = lengthFrequency/numberOfReads;
		readLengthEntropy += lengthProbability*(log2(lengthProbability));
	}
	readLengthEntropy *= -1;
	readLengthMap.clear();
	return readLengthEntropy;
}

////////////////////////////////////////////

double Block::readExpressionEntropy(){
	map<double, unsigned int> readExpressionMap;
	float numberOfReads=0;
	vector<Read> readsList = getReads();
	vector<Read>::iterator readIterator;
	for ( readIterator = readsList.begin(); readIterator != readsList.end(); ++readIterator ){
		double readExpression = readIterator->getExpression();
		double rouded = floor(readExpression * 100 + 0.5) / 100;
		readExpressionMap[rouded]++;
		numberOfReads++;
	}
	double readExpressionEntropy = 0;
	for( map<double, unsigned int>::iterator ii=readExpressionMap.begin(); ii!=readExpressionMap.end(); ++ii){
		unsigned int expressionFrequency = ii->second;
		double expressionProbability = expressionFrequency/numberOfReads;
		readExpressionEntropy += expressionProbability*(log2(expressionProbability));
	}
	readExpressionEntropy *= -1;
	readExpressionMap.clear();
	return readExpressionEntropy;
}

////////////////////////////////////////////

double Block::readAreaEntropy(){
	map<double, unsigned int> readAreaMap;
	float numberOfReads=0;
	vector<Read> readsList = getReads();
	vector<Read>::iterator readIterator;
	for ( readIterator = readsList.begin(); readIterator != readsList.end(); ++readIterator ){
		double readArea = readIterator->getArea();
		double rouded = floor(readArea * 100 + 0.5) / 100;
		readAreaMap[rouded]++;
		numberOfReads++;
	}
	double readAreaEntropy = 0;
	for( map<double, unsigned int>::iterator ii=readAreaMap.begin(); ii!=readAreaMap.end(); ++ii){
		unsigned int areaFrequency = ii->second;
		double areaProbability = areaFrequency/numberOfReads;
		readAreaEntropy += areaProbability*(log2(areaProbability));
	}
	readAreaEntropy *= -1;
	readAreaMap.clear();
	return readAreaEntropy;
}

////////////////////////////////////////////

double Block::medianReadExpression(){
	vector<Read> readsList = getReads();
	vector<Read>::iterator readIterator;
	vector<double> readExpressions;
	for ( readIterator = readsList.begin(); readIterator != readsList.end(); ++readIterator ){
		double readExpression = readIterator->getExpression();
		readExpressions.push_back(readExpression);
	}
	readsList.clear();

	typedef vector<double>::size_type vec_sz;
	vec_sz size = readExpressions.size();
	if (size == 0){
		cerr << "median of an empty vector" << endl;
		exit(0);
	}
	sort(readExpressions.begin(), readExpressions.end());
	vec_sz mid = size/2;
	return size % 2 == 0 ? (readExpressions[mid] + readExpressions[mid-1]) / 2 : readExpressions[mid];
}

////////////////////////////////////////////

double Block::meanReadExpression(){
	vector<Read> readsList = getReads();
	vector<Read>::iterator readIterator;
	vector<double> readExpressions;
	for ( readIterator = readsList.begin(); readIterator != readsList.end(); ++readIterator ){
		double readExpression = readIterator->getExpression();
		readExpressions.push_back(readExpression);
	}
	readsList.clear();
	return accumulate(readExpressions.begin(), readExpressions.end(), 0.0) / readExpressions.size();
}
