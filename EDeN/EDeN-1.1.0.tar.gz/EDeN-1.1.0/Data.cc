#include "Data.h"

Data::Data() :
		mpParameters(0), mDataIsLoaded(false), mTargetIsLoaded(false), mIndexIsLoaded(false) {
}

void Data::Init(Parameters* apParameters) {
	mpParameters = apParameters;
	mKernel.Init(mpParameters);
}

double Data::ComputeKernel(unsigned i, unsigned j) {
	if (i > Size() || j > Size())
		throw range_error("ERROR3.1: Kernel computation for instances out of range. Available range: 0-" + stream_cast<string>(Size()) + " but asked for kernel between instances with index " + stream_cast<string>(i) + " and " + stream_cast<string>(j));
	return mKernel.ComputeKernel(mVectorList[i], mVectorList[j]);
}

void Data::ComputeFeatureCorrelationMatrix() {
	mFeatureCorrelationMatrix.clear();
	igzstream fin;
	fin.open(mpParameters->mInputDataFileName.c_str());
	if (!fin)
		throw range_error("ERROR2.11: Cannot open file: " + mpParameters->mInputDataFileName);

	{
		if (!mpParameters->mMinimalOutput)
			cout << endl << "Processing file:" << mpParameters->mInputDataFileName << " for feature correlation" << endl;
		ProgressBar pb;
		bool valid_input = true;
		while (!fin.eof() && valid_input) {
			GraphClass g;
			SetGraphFromFile(fin, g);
			if (!g.IsEmpty()) {
				if (!mpParameters->mMinimalOutput)
					pb.Count();
				//extract from a graph the feature vector for each vertex (manage directed graph)
				vector<SVector> graph_vertex_vector_list;
				mKernel.GenerateVertexFeatureVector(g, graph_vertex_vector_list);
				unsigned size = mpParameters->mGraphType == "DIRECTED" ? graph_vertex_vector_list.size() / 2 : graph_vertex_vector_list.size();
				for (unsigned vertex_id = 0; vertex_id < size; ++vertex_id) {
					SVector x = graph_vertex_vector_list[vertex_id];
					if (mpParameters->mGraphType == "DIRECTED")
						x += graph_vertex_vector_list[vertex_id + size];
				}

				//impute to each feature the occurrences of the other features associated to the same single vertex
				//for each vertex
				for (unsigned i = 0; i < graph_vertex_vector_list.size(); ++i) {
					SVector& x = graph_vertex_vector_list[i];
					//for each feature
					for (SVector::InnerIterator it(x); it; ++it) {
						unsigned hash_code = it.index();
						if (mFeatureCorrelationMatrix.count(hash_code) == 0)
							mFeatureCorrelationMatrix.insert(make_pair(hash_code, x));
						else
							mFeatureCorrelationMatrix[hash_code] += x;
					}
				}
			} else
				valid_input = false;
		}
	}

	//row normalize correlation matrix
	for (map<unsigned, SVector>::iterator it = mFeatureCorrelationMatrix.begin(); it != mFeatureCorrelationMatrix.end(); ++it) {
		unsigned id = it->first;
		SVector& x = it->second;

		//extract threshold for k largest correlation
		vector<double> corr;
		for (SVector::InnerIterator it(x); it; ++it)
			corr.push_back(-it.value());
		sort(corr.begin(), corr.end());
		double threshold = -corr[mpParameters->mTopologicalRegularizationNumNeighbors];
		//trim vector to the top mpParameters->mTopologicalRegularizationNumNeighbors
		SVector x_new(pow(2, mpParameters->mHashBitSize));
		;
		for (SVector::InnerIterator it(x); it; ++it)
			if (it.value() > threshold)
				x_new.insert(it.index()) = it.value();
		//retain only the top mpParameters->mTopologicalRegularizationNumNeighbors related features by replacing the vector row
		x = x_new;

		//create the normalized Laplacian
		x.coeffRef(id) = 0; //remove counts to self
		x /= -x.norm();
		x.coeffRef(id) = 1; //set counts to self to 1
	}

}

void Data::LoadIndex() {
	if (mpParameters->mRowIndexFileName != "")
		if (mRowIndexList.size() == 0) {
			LoadUnsignedList(mpParameters->mRowIndexFileName, mRowIndexList);
			mIndexIsLoaded = true;
		}
	if (mpParameters->mColIndexFileName != "")
		if (mColIndexList.size() == 0) {
			LoadUnsignedList(mpParameters->mColIndexFileName, mColIndexList);
			mIndexIsLoaded = true;
		}

	if (IsDataLoaded() == false)
		throw range_error("ERROR: Cannot assign indices before reading data file.");

	if (mRowIndexList.size() == 0) {
		if (!mpParameters->mMinimalOutput)
			cout << endl << "No row index list specified. Assuming all " << Size() << " row indices as valid." << endl;
		for (unsigned i = 0; i < Size(); ++i)
			mRowIndexList.push_back(i);
	}
	if (mColIndexList.size() == 0) {
		if (!mpParameters->mMinimalOutput)
			cout << endl << "No col index list specified. Assuming all " << Size() << " col indices as valid." << endl;
		for (unsigned i = 0; i < Size(); ++i)
			mColIndexList.push_back(i);
	}
}

bool Data::IsIndexLoaded() {
	return mIndexIsLoaded;
}

void Data::LoadTarget() {
	if (mpParameters->mTargetFileName != "") {
		mTargetList.clear();
		LoadRealList(mpParameters->mTargetFileName, mTargetList);
		mTargetIsLoaded = true;
	}
}

bool Data::IsTargetLoaded() {
	return mTargetIsLoaded;
}

void Data::LoadRealList(string aFileName, vector<double>& oList) {
	oList.clear();
	if (!mpParameters->mMinimalOutput)
		cout << endl << "Reading file: " << aFileName << " ..";
	ifstream fin;
	fin.open(aFileName.c_str());
	if (!fin)
		throw range_error("ERROR2.235: Cannot open file:" + aFileName);
	while (!fin.eof()) {
		string line;
		getline(fin, line);
		stringstream ss;
		ss << line << endl;
		while (!ss.eof()) {
			double value(0);
			ss >> value;
			if (ss.good()) {
				oList.push_back(value);
			}
		}
	}
	fin.close();
	if (!mpParameters->mMinimalOutput)
		cout << ".. read: " << oList.size() << " values." << endl;
}

void Data::LoadUnsignedList(string aFileName, vector<unsigned>& oList) {
	oList.clear();
	if (!mpParameters->mMinimalOutput)
		cout << endl << "Reading file: " << aFileName << " ..";
	ifstream fin;
	fin.open(aFileName.c_str());
	if (!fin)
		throw range_error("ERROR2.236: Cannot open file:" + aFileName);
	while (!fin.eof()) {
		string line;
		getline(fin, line);
		stringstream ss;
		ss << line << endl;
		while (!ss.eof()) {
			unsigned value(0);
			ss >> value;
			if (ss.good()) {
				oList.push_back(value);
			}
		}
	}
	fin.close();
	if (!mpParameters->mMinimalOutput)
		cout << ".. read: " << oList.size() << " values." << endl;
}

void Data::LoadGspanList(vector<GraphClass>& aGraphList) {
	mVectorList.clear();
	for (unsigned i = 0; i < aGraphList.size(); ++i) {
		SVector x(pow(2, mpParameters->mHashBitSize));
		;
		mKernel.GenerateFeatureVector(aGraphList[i], x);
		mVectorList.push_back(x);
	}
}

void Data::LoadData(istream& fin) {
	ProgressBar pb;
	bool valid_input = true;
	unsigned instance_counter = 0;
	while (!fin.eof() && valid_input) {
		switch (mpParameters->mFileTypeCode) {
		case GRAPH:
#ifdef USEOBABEL
			case MOLECULAR_GRAPH:
#endif
		case SEQUENCE: {
			vector<GraphClass> g_list(BUFFER_SIZE);
			unsigned i = 0;
			while (i < BUFFER_SIZE && !fin.eof() && valid_input) {
				SetGraphFromFile(fin, g_list[i]);
				if (g_list[i].IsEmpty())
					valid_input = false;
				else {
					i++;
					instance_counter++;
				}
			}
			// store vectors calculated from buffer elements
			vector<SVector> v_list(i);
#ifdef USEMULTITHREAD
#pragma omp parallel for schedule(dynamic)
#endif
			for (unsigned j = 0; j < i; j++) {
				SVector x(pow(2, mpParameters->mHashBitSize));
				mKernel.GenerateFeatureVector(g_list[j], x);
				v_list[j] = x;
				pb.Count();
			}
			// append vectors calculated from buffer to master vector
			mVectorList.insert(mVectorList.end(), v_list.begin(), v_list.end());

		}
			break;
		case SPARSE_VECTOR: {
			SVector x(pow(2, mpParameters->mHashBitSize));
			;
			if (mpParameters->mBinaryFormat)
				SetVectorFromSparseVectorBinaryFile(fin, x);
			else
				SetVectorFromSparseVectorAsciiFile(fin, x);
			if (x.size() > 0) {
				mVectorList.push_back(x);
				instance_counter++;
				if (!mpParameters->mMinimalOutput)
					pb.Count();
			}
		}
			break;
		default:
			throw range_error("ERROR2.45: file type not recognized: " + mpParameters->mFileType);
		}
	}

	if (instance_counter > 0)
		mDataIsLoaded = true;
	else
		throw range_error("ERROR: something went wrong: data file was expected but no data is available");
}

void Data::LoadData() {
	mVectorList.clear();
	mKernel.ParametersSetup();
	igzstream fin;
	fin.open(mpParameters->mInputDataFileName.c_str());
	if (!fin)
		throw range_error("ERROR2.11: Cannot open file: " + mpParameters->mInputDataFileName);
	if (!mpParameters->mMinimalOutput)
		cout << "Processing file: " << mpParameters->mInputDataFileName << endl;
	LoadData(fin);

	//additional files to load if required
	if (IsIndexLoaded() == false)
		LoadIndex();

	if (IsTargetLoaded() == false)
		LoadTarget();

	//additional operations to perform on data if required
	if (mpParameters->mTopologicalRegularizationNumNeighbors != 0)
		ComputeFeatureCorrelationMatrix();
}

bool Data::IsDataLoaded() {
	return mDataIsLoaded;
}

void Data::SetGraphFromFile(istream& in, GraphClass& oG) {
	switch (mpParameters->mFileTypeCode) {
	case GRAPH:
		SetGraphFromGraphGspanFile(in, oG);
		break;
#ifdef USEOBABEL
		case MOLECULAR_GRAPH:
		SetGraphFromGraphOpenBabelFile(in, oG, mpParameters->mOpenBabelFormat);
		break;
#endif
	case SEQUENCE: {
		if (mpParameters->mSequenceToken && mpParameters->mSequenceMultiLine)
			SetGraphFromSequenceMultiLineTokenFile(in, oG);
		if (mpParameters->mSequenceToken && !mpParameters->mSequenceMultiLine)
			SetGraphFromSequenceTokenFile(in, oG);
		if (!mpParameters->mSequenceToken && mpParameters->mSequenceMultiLine)
			SetGraphFromSequenceMultiLineFile(in, oG);
		if (!mpParameters->mSequenceToken && !mpParameters->mSequenceMultiLine)
			SetGraphFromSequenceFile(in, oG);
		break;
	}
	default:
		throw range_error("ERROR2.45: file type not recognized: " + mpParameters->mFileType);
	}
	//HACK**************************************************************************************************
	/*static int counter = -1;
	 if (oG.VertexSize() > 0) {
	 counter++;
	 string gid = stream_cast<string>(counter);
	 vector<unsigned> view_point_list;
	 oG.ComputePairwiseDistanceInformation(mpParameters->mRadius + mpParameters->mDistance);
	 oG.SaveAsMatlabFile(gid, view_point_list);
	 }
	 */
	//******************************************************************************************************
}

void Data::SetGraphFromGraphOpenBabelFile(istream& in, GraphClass& oG, string aFormat) {
	static OpenBabelConverter molecule_converter;
	if (in.good() && !in.eof()) {
		//molecule_converter.ConvertOpenBabelFormatToGraph(&in, oG, aFormat); //OLD version
		molecule_converter.ConvertOpenBabelFormatToGraph(mpParameters->mInputDataFileName, oG, aFormat);
	}
}

void Data::SetVectorFromSparseVectorAsciiFile(istream& in, SVector& aX) {
	string line;
	getline(in, line);
	if (line == "")
		return;
	stringstream ss;
	ss << line << endl;
	while (!ss.eof() && ss.good()) {
		string key_value;
		ss >> key_value;
		size_t limit = key_value.find_first_of(":", 0);
		if (limit != string::npos) { //if the delimiter ':' is found then proceed
			string key = key_value.substr(0, limit);
			string value = key_value.substr(limit + 1, key_value.size());
			unsigned key_int = stream_cast<unsigned>(key);
			double val_real = stream_cast<double>(value);
			aX.insert(key_int) = val_real;
		}
	}
}

void Data::SetVectorFromSparseVectorBinaryFile(istream& in, SVector& aX) {
	loadSparseBinary(in, aX);
}

void Data::SetGraphFromSequenceFile(istream& in, GraphClass& oG) {
	vector<vector<unsigned> > vertex_component_list;
	vector<unsigned> vertex_component;
	bool graph_disconnect = true;
	string line;
	getline(in, line);
	if (line == "")
		return;
	unsigned vertex_counter = 0;
	for (unsigned position_counter = 0; position_counter < line.length(); position_counter++) {
		char char_label = line.at(position_counter);
		string label = stream_cast<string>(char_label);
		if (label == "|") {
			graph_disconnect = true;
			vertex_component_list.push_back(vertex_component);
			vertex_component.clear();
		} else {
			vertex_component.push_back(vertex_counter);
			AddVertexAndEdgesForSequence(oG, label, vertex_counter, graph_disconnect);
			vertex_counter++;
			graph_disconnect = false;
		}
	}
	vertex_component_list.push_back(vertex_component);
	ManageDirectedAndMultiComponent(oG, vertex_component_list);
}

void Data::SetGraphFromSequenceTokenFile(istream& in, GraphClass& oG) {
	vector<vector<unsigned> > vertex_component_list;
	vector<unsigned> vertex_component;
	bool graph_disconnect = true;
	string line;
	getline(in, line);
	if (line == "")
		return;
	stringstream ss;
	ss << line << endl;
	unsigned vertex_counter = 0;
	while (!ss.eof() && ss.good()) {
		//add vertex
		string label;
		ss >> label;
		if (label != "") {
			if (label == "|") {
				graph_disconnect = true;
				vertex_component_list.push_back(vertex_component);
				vertex_component.clear();
			} else {
				vertex_component.push_back(vertex_counter);
				AddVertexAndEdgesForSequence(oG, label, vertex_counter, graph_disconnect);
				vertex_counter++;
				graph_disconnect = false;
			}
		}
	}
	vertex_component_list.push_back(vertex_component);
	ManageDirectedAndMultiComponent(oG, vertex_component_list);
}

void Data::SetGraphFromSequenceMultiLineFile(istream& in, GraphClass& oG) {
	vector<vector<unsigned> > vertex_component_list;
	vector<unsigned> vertex_component;
	bool graph_disconnect = true;
	vector<string> line(mpParameters->mSequenceDegree);
	for (unsigned i = 0; i < mpParameters->mSequenceDegree; ++i) {
		getline(in, line[i]);
	}
	unsigned sequence_length = line[0].length();
	unsigned vertex_counter = 0;
	for (unsigned j = 0; j < sequence_length; j++) {
		for (unsigned i = 0; i < mpParameters->mSequenceDegree; ++i) {
			if (line[i] == "")
				return;
			char char_label = line[i].at(j);
			string label = stream_cast<string>(char_label);
			if (label == "|") {
				if (i == 0) { //process the first | symbol
					graph_disconnect = true;
					vertex_component_list.push_back(vertex_component);
					vertex_component.clear();
				} else { //skip the remaining | symbols
					//do nothing
				}
			} else {
				vertex_component.push_back(vertex_counter);
				AddVertexAndEdgesForSequence(oG, label, vertex_counter, graph_disconnect);
				vertex_counter++;
				graph_disconnect = false;
			}
		}
	}
	//at last get the last vertex_component in
	vertex_component_list.push_back(vertex_component);
	ManageDirectedAndMultiComponent(oG, vertex_component_list);
}

void Data::SetGraphFromSequenceMultiLineTokenFile(istream& in, GraphClass& oG) {
	vector<vector<unsigned> > vertex_component_list;
	vector<unsigned> vertex_component;
	bool graph_disconnect = true;
	vector<vector<string> > multi_line;
	for (unsigned i = 0; i < mpParameters->mSequenceDegree; ++i) {
		vector<string> single_line;
		string line;
		getline(in, line);
		stringstream ss;
		ss << line << endl;
		while (!ss.eof() && ss.good()) {
			string label;
			ss >> label;
			if (label != "") {
				single_line.push_back(label);
			}
		}
		if (single_line.size() > 0) {
			multi_line.push_back(single_line);
		}
	}

	if (multi_line.size() > 0) {
		unsigned sequence_length = multi_line[0].size();
		for (unsigned i = 0; i < mpParameters->mSequenceDegree; ++i)
			assert(multi_line[i].size()==sequence_length);

		unsigned vertex_counter = 0;
		for (unsigned j = 0; j < sequence_length; j++) {
			for (unsigned i = 0; i < mpParameters->mSequenceDegree; ++i) {
				string label = multi_line[i][j];
				if (label == "|") {
					if (i == 0) { //process the first | symbol
						graph_disconnect = true;
						vertex_component_list.push_back(vertex_component);
						vertex_component.clear();
					} else { //skip the remaining | symbols
						//do nothing
					}
				} else {
					vertex_component.push_back(vertex_counter);
					AddVertexAndEdgesForSequence(oG, label, vertex_counter, graph_disconnect);
					vertex_counter++;
					graph_disconnect = false;
				}
			}
		}
		//at last get the last vertex_component in
		vertex_component_list.push_back(vertex_component);
		ManageDirectedAndMultiComponent(oG, vertex_component_list);
	}
}

void Data::ManageDirectedAndMultiComponent(GraphClass& oG, vector<vector<unsigned> >& aVertexComponentList) {
	if (mpParameters->mGraphType == "DIRECTED" && aVertexComponentList.size() > 1) {
		//create the components for the reversed direction graph
		vector<vector<unsigned> > reverse_vertex_component_list;
		for (unsigned u = 0; u < aVertexComponentList.size(); ++u) {
			vector<unsigned> reverse_vertex_component;
			for (unsigned t = 0; t < aVertexComponentList[u].size(); ++t) {
				unsigned id = aVertexComponentList[u][t];
				reverse_vertex_component.push_back(id + oG.VertexSize());
			}
			reverse_vertex_component_list.push_back(reverse_vertex_component);
		}
		//add the reverse direction components to the component list
		aVertexComponentList.insert(aVertexComponentList.end(), reverse_vertex_component_list.begin(), reverse_vertex_component_list.end());
	}

	if (mpParameters->mGraphType == "DIRECTED")
		AddReverseGraph(oG);

	if (mpParameters->mSequencePairwiseInteraction)
		if (aVertexComponentList.size() > 1)
			AddAbstractConnections(oG, aVertexComponentList);
}

void Data::AddVertexAndEdgesForSequence(GraphClass& oG, string aLabel, unsigned aVertexCounter, bool aGraphDisconnect) {
	//set (once) boolean status vectors
	static vector<bool> vertex_status(5, false);
	vertex_status[0] = true; //kernel point
	vertex_status[1] = true; //kind
	vertex_status[2] = true; //viewpoint
	//vertex_status[3] = false; //dead
	//vertex_status[4] = false; //abstraction

	static vector<bool> edge_status(3, false);
	//edge_status[0] = false; //edge dead
	//edge_status[1] = false; //edge abstraction_of
	//edge_status[2] = false; //edge part_of

	unsigned real_vertex_index = oG.InsertVertex();
	vector<string> vertex_symbolic_attribute_list;
	vertex_symbolic_attribute_list.push_back(aLabel);
	oG.SetVertexSymbolicAttributeList(real_vertex_index, vertex_symbolic_attribute_list);
	oG.SetVertexStatusAttributeList(real_vertex_index, vertex_status);
	if (aVertexCounter % mpParameters->mSequenceDegree != 0) {
		oG.SetVertexViewPoint(real_vertex_index, false);
	}
	if (aGraphDisconnect == false) {
		//add edge
		unsigned real_src_index;
		unsigned real_dest_index;
		if (aVertexCounter % mpParameters->mSequenceDegree != 0) { //add edge to preceding vertex
			real_src_index = aVertexCounter;
			real_dest_index = aVertexCounter - 1;
		} else { //vertices with position multiple than mSequenceDegree are connected in sequence
			real_src_index = aVertexCounter;
			real_dest_index = aVertexCounter - mpParameters->mSequenceDegree;
		}
		vector<string> edge_symbolic_attribute_list;
		edge_symbolic_attribute_list.push_back("-"); //NOTE: default edge label is '-'
		unsigned edge_index = oG.InsertEdge(real_src_index, real_dest_index);
		oG.SetEdgeSymbolicAttributeList(edge_index, edge_symbolic_attribute_list);
		oG.SetEdgeStatusAttributeList(edge_index, edge_status);
		if (mpParameters->mGraphType == "UNDIRECTED" || aVertexCounter % mpParameters->mSequenceDegree != 0) { //add reverse edge in case the graph is undirected or for the attribute vertices, so that in both directions these are accessible
			unsigned reverse_edge_index = oG.InsertEdge(real_dest_index, real_src_index);
			oG.SetEdgeSymbolicAttributeList(reverse_edge_index, oG.GetEdgeSymbolicAttributeList(edge_index));
			oG.SetEdgeStatusAttributeList(reverse_edge_index, oG.GetEdgeStatusAttributeList(edge_index));
		}
	}
}

void Data::AddAbstractConnections(GraphClass& oG, vector<vector<unsigned> >& aVertexComponentList) {
	//set (once) boolean status vectors
	static vector<bool> vertex_status(5, false);
	//vertex_status[0] = false; //kernel point
	//vertex_status[1] = false; //kind
	//vertex_status[2] = false; //viewpoint
	//vertex_status[3] = false; //dead
	vertex_status[4] = true; //abstraction

	static vector<bool> edge_status(3, false);
	//edge_status[0] = false; //edge dead
	//edge_status[1] = false; //edge abstraction_of
	//edge_status[2] = false; //edge part_of

	//for all pairs of components
	for (unsigned i = 0; i < aVertexComponentList.size(); ++i) {
		for (unsigned j = i + 1; j < aVertexComponentList.size(); ++j) {
			//join all vertices in one component to all other vertices in the other component
			//add 1 abstract vertex
			unsigned real_vertex_index = oG.InsertVertex();
			vector<string> vertex_symbolic_attribute_list;
			vertex_symbolic_attribute_list.push_back("^L");
			oG.SetVertexSymbolicAttributeList(real_vertex_index, vertex_symbolic_attribute_list);
			oG.SetVertexStatusAttributeList(real_vertex_index, vertex_status);

			for (unsigned ii = 0; ii < aVertexComponentList[i].size(); ii++) { //add part_of edges
				unsigned real_src_index = real_vertex_index;
				unsigned real_dest_index = aVertexComponentList[i][ii];
				//only add edges to point vertices
				if (oG.GetVertexViewPoint(real_dest_index)) {
					vector<string> edge_symbolic_attribute_list;
					edge_symbolic_attribute_list.push_back("@-");
					unsigned edge_index = oG.InsertEdge(real_src_index, real_dest_index);
					oG.SetEdgeSymbolicAttributeList(edge_index, edge_symbolic_attribute_list);
					oG.SetEdgeStatusAttributeList(edge_index, edge_status);
					oG.SetEdgePartOf(edge_index, true);
				}
			}

			for (unsigned jj = 0; jj < aVertexComponentList[j].size(); jj++) { //add abstraction_of edges
				unsigned real_src_index = real_vertex_index;
				unsigned real_dest_index = aVertexComponentList[j][jj];
				if (oG.GetVertexViewPoint(real_dest_index)) {
					vector<string> edge_symbolic_attribute_list;
					edge_symbolic_attribute_list.push_back("^-");
					unsigned edge_index = oG.InsertEdge(real_src_index, real_dest_index);
					oG.SetEdgeSymbolicAttributeList(edge_index, edge_symbolic_attribute_list);
					oG.SetEdgeStatusAttributeList(edge_index, edge_status);
					oG.SetEdgeAbstractionOf(edge_index, true);
				}
			}
		}
	}
}

void Data::SetGraphFromGraphGspanFile(istream& in, GraphClass& oG) {
	//status
	vector<bool> vertex_status(5, false);
	vertex_status[0] = true; //kernel point
	vertex_status[1] = true; //kind
	vertex_status[2] = true; //viewpoint
	vertex_status[3] = false; //dead
	vertex_status[4] = false; //abstraction

	vector<bool> edge_status(3, false);
	edge_status[0] = false; //edge dead
	edge_status[1] = false; //edge abstraction_of
	edge_status[2] = false; //edge part_of

	map<string, int> index_map_nominal_to_real;
	//string gid;
	unsigned line_counter = 0;
	bool instance_started = false;
	do {
		char c = in.peek();
		if (c == 't' && instance_started == true)
			break;

		line_counter++;
		string line;
		getline(in, line);
		if (line == "")
			break;
		stringstream ss;
		ss << line << endl;
		char code;
		ss >> code;
		if (code == 't') {
			instance_started = true;
		} else if (code == 'v' || code == 'V' || code == 'W') {
			//extract vertex id and make map nominal_id -> real_id
			string nominal_vertex_index;
			ss >> nominal_vertex_index;
			unsigned real_vertex_index = oG.InsertVertex();
			index_map_nominal_to_real[nominal_vertex_index] = real_vertex_index;
			//label
			vector<string> vertex_symbolic_attribute_list;
			string label;
			ss >> label;
			vertex_symbolic_attribute_list.push_back(label);
			oG.SetVertexSymbolicAttributeList(real_vertex_index, vertex_symbolic_attribute_list);
			oG.SetVertexStatusAttributeList(real_vertex_index, vertex_status);
			if (code == 'V')
				oG.SetVertexViewPoint(real_vertex_index, false);
			if (code == 'W') {
				oG.SetVertexViewPoint(real_vertex_index, false);
				oG.SetVertexKernelPoint(real_vertex_index, false);
			}
			char vertex_abstraction_code = label.at(0);
			if (vertex_abstraction_code == '^') {
				oG.SetVertexAbstraction(real_vertex_index, true);
				oG.SetVertexViewPoint(real_vertex_index, false);
				oG.SetVertexKernelPoint(real_vertex_index, false);
			}
		} else if (code == 'e') {
			//extract src and dest vertex id
			string nominal_src_index, nominal_dest_index;
			string label;
			ss >> nominal_src_index >> nominal_dest_index >> label;
			if (index_map_nominal_to_real.count(nominal_src_index) == 0)
				throw range_error("ERROR2.22: Did not find nominal src index: " + nominal_src_index + " at line: " + stream_cast<string>(line_counter));
			if (index_map_nominal_to_real.count(nominal_dest_index) == 0)
				throw range_error("ERROR2.22: Did not find nominal dest index: " + nominal_dest_index + " at line: " + stream_cast<string>(line_counter));
			vector<string> edge_symbolic_attribute_list;
			edge_symbolic_attribute_list.push_back(label);
			unsigned real_src_index = index_map_nominal_to_real[nominal_src_index];
			unsigned real_dest_index = index_map_nominal_to_real[nominal_dest_index];
			unsigned edge_index = oG.InsertEdge(real_src_index, real_dest_index);
			oG.SetEdgeSymbolicAttributeList(edge_index, edge_symbolic_attribute_list);
			oG.SetEdgeStatusAttributeList(edge_index, edge_status);

			char edge_abstraction_code = label.at(0);
			if (edge_abstraction_code == '^')
				oG.SetEdgeAbstractionOf(edge_index, true);
			if (edge_abstraction_code == '@')
				oG.SetEdgePartOf(edge_index, true);

			if (mpParameters->mGraphType == "UNDIRECTED" || edge_abstraction_code == '^' || edge_abstraction_code == '@') { //NOTE: edges that are part of the abstraction mechanism should be treated as undirected
				unsigned reverse_edge_index = oG.InsertEdge(real_dest_index, real_src_index);
				oG.SetEdgeSymbolicAttributeList(reverse_edge_index, oG.GetEdgeSymbolicAttributeList(edge_index));
				oG.SetEdgeStatusAttributeList(reverse_edge_index, oG.GetEdgeStatusAttributeList(edge_index));
			}
		} else {
		} //NOTE: ignore other markers
	} while (!in.eof() && in.good());
	if (mpParameters->mGraphType == "DIRECTED")
		AddReverseGraph(oG);
}

void Data::AddReverseGraph(GraphClass& oG) {
	unsigned vsize = oG.VertexSize();
	//add a copy of all vertices
	for (unsigned i = 0; i < vsize; i++) {
		unsigned real_vertex_index = oG.InsertVertex();
		assert(real_vertex_index == i + vsize);
		vector<string> vertex_symbolic_attribute_list = oG.GetVertexSymbolicAttributeList(i);
		for (unsigned t = 0; t < vertex_symbolic_attribute_list.size(); t++) //prepend a prefix to mark the reverse direction
			vertex_symbolic_attribute_list[t] = "r." + vertex_symbolic_attribute_list[t];
		oG.SetVertexSymbolicAttributeList(real_vertex_index, vertex_symbolic_attribute_list);
		oG.SetVertexStatusAttributeList(real_vertex_index, oG.GetVertexStatusAttributeList(i)); //assign original status vector
	}
	//copy all edges swapping src with dest
	for (unsigned i = 0; i < vsize; i++) {
		//get all edges
		vector<unsigned> adj = oG.GetVertexAdjacentList(i);
		for (unsigned j = 0; j < adj.size(); j++) {
			unsigned orig_src = i;
			unsigned orig_dest = adj[j];
			unsigned reverse_src = orig_dest + vsize;
			unsigned reverse_dest = orig_src + vsize;
			unsigned edge_index = oG.InsertEdge(reverse_src, reverse_dest);
			oG.SetEdgeSymbolicAttributeList(edge_index, oG.GetEdgeSymbolicAttributeList(orig_src, orig_dest));
			oG.SetEdgeStatusAttributeList(edge_index, oG.GetEdgeStatusAttributeList(orig_src, orig_dest));
		}
	}
}

unsigned Data::Size() {
	return mVectorList.size();
}
