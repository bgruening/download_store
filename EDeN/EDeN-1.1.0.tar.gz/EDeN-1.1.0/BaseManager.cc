#include "BaseManager.h"

BaseManager::BaseManager(Parameters* apParameters, Data* apData) {
	Init(apParameters, apData);
}

void BaseManager::Init(Parameters* apParameters, Data* apData) {
	mpParameters = apParameters;
	mpData = apData;
}

//--------------------------------------------------------------------------------------
OutputManager::OutputManager(string aFileName, string aDirectoryPath) :
		mFileName(aFileName), mDirectoryPath(aDirectoryPath) {
	if (mDirectoryPath != "") {
		//check that directory exists otherwise make one
		int status;
		status = mkdir(mDirectoryPath.c_str(), 0777);
		if (status == -1) {
			if (errno == EEXIST) {
			} //ignore the issue if the directory exists already
			else {
				//otherwise bail out
				string error_code=stream_cast<string>(strerror(errno));
				string msg="ERROR " + error_code + ": Cannot access directory:" + mDirectoryPath;
				throw range_error(msg);
			}
		}
	}

	//check that file can be opened in w mode
	string output_filename = GetFullPathFileName();
	mOut.open(output_filename.c_str(),std::ofstream::trunc);
	if (!mOut)
		throw range_error("ERROR: Cannot open file:" + output_filename);
}

string OutputManager::GetFullPathFileName() {
	string output_filename;
	if (mDirectoryPath != "")
		output_filename = mDirectoryPath + "/" + mFileName;
	else output_filename = mFileName;
	return output_filename;
}
