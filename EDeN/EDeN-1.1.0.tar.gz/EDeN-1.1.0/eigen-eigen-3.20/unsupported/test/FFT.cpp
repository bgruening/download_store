#define test_FFTW test_FFT
#include "FFTW.cpp"
