/* -*- mode:c++ -*- */
#ifndef NEAREST_NEIGHBOR_H
#define NEAREST_NEIGHBOR_H

#include "BaseManager.h"
#include "MinHashEncoder.h"

using namespace std;

class NearestNeighbor: public BaseManager {
protected:
	MinHashEncoder mMinHashEncoder;
	vector<vector<unsigned> > mNeighborhoodCache;

public:
	NearestNeighbor(Parameters* apParameters, Data* apData);
	void Init(Parameters* apParameters, Data* apData);
	void CacheReset();
	vector<unsigned> ComputeNeighborhood(unsigned aID);
	vector<unsigned> ComputeTrueSubNeighborhood(unsigned aID, vector<unsigned>& aApproximateNeighborhoodList);
	vector<unsigned> ComputeTrueNeighborhood(unsigned aID);
	vector<unsigned> ComputeApproximateNeighborhood(unsigned aID);
	double ComputeSharedNeighborhoodSimilarity(unsigned aI, unsigned aJ);
	unsigned ComputeNeighborhoodIntersection(unsigned aI, unsigned aJ);
};

#endif /* NEAREST_NEIGHBOR_H */
