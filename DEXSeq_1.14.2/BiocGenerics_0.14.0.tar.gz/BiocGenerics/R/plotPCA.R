setGeneric("plotPCA", function(object, ...) {
    standardGeneric("plotPCA")
})
