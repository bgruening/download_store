setMethod("initialize",
          signature(.Object="MultiSet"),
          function(.Object, ...) callNextMethod())
