PUBLIC int int22_37[NBPAIRS+1][NBPAIRS+1][5][5][5][5] =
{{{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 }
,{{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   200,   160,   200,   150,   200}
    ,{   200,   160,   200,   150,   200}
    ,{   180,   140,   180,   140,   180}
    ,{   200,   160,   200,   150,   200}
    ,{   170,   130,   170,   120,   170}
    }
   ,{{   160,   120,   160,   110,   160}
    ,{   160,   120,   160,   110,   160}
    ,{   150,   110,   150,   110,   150}
    ,{   110,    20,   110,    20,    90}
    ,{   150,   110,   150,   110,   150}
    }
   ,{{   200,   160,   200,   150,   200}
    ,{   200,   160,   200,   150,   200}
    ,{   180,   140,   180,   140,   180}
    ,{   200,   160,   200,   150,   200}
    ,{   170,   130,   170,   120,   170}
    }
   ,{{   150,   110,   150,   110,   150}
    ,{   110,    20,   110,    20,    90}
    ,{   150,   110,   150,   110,   150}
    ,{    80,     0,    10,    80,    20}
    ,{   150,   110,   150,   110,   150}
    }
   ,{{   200,   160,   200,   150,   200}
    ,{   200,   160,   200,   150,   200}
    ,{   170,   130,   170,   120,   170}
    ,{   200,   160,   200,   150,   200}
    ,{   100,   100,    80,    30,    80}
    }
   }
  ,{{{   200,   160,   200,   110,   200}
    ,{   200,   160,   200,    60,   200}
    ,{   180,   140,   180,   110,   180}
    ,{   200,   160,   200,    60,   200}
    ,{   170,   130,   170,    90,   170}
    }
   ,{{   160,   120,   160,    20,   160}
    ,{   160,   120,   160,    20,   160}
    ,{   150,   110,   150,    20,   150}
    ,{    60,    20,    60,   -70,    60}
    ,{   150,   110,   150,    20,   150}
    }
   ,{{   200,   160,   200,   110,   200}
    ,{   200,   160,   200,    60,   200}
    ,{   180,   140,   180,   110,   180}
    ,{   200,   160,   200,    60,   200}
    ,{   170,   130,   170,    90,   170}
    }
   ,{{   150,   110,   150,    20,   150}
    ,{    60,    20,    60,   -70,    60}
    ,{   150,   110,   150,    20,   150}
    ,{    10,   -30,    10,     0,    10}
    ,{   150,   110,   150,    20,   150}
    }
   ,{{   200,   160,   200,    90,   200}
    ,{   200,   160,   200,    60,   200}
    ,{   170,   130,   170,    90,   170}
    ,{   200,   160,   200,    60,   200}
    ,{   100,   100,    80,   -50,    80}
    }
   }
  ,{{{   180,   150,   180,   150,   170}
    ,{   180,   150,   180,   150,   170}
    ,{   170,   140,   170,   140,   150}
    ,{   180,   150,   180,   150,   170}
    ,{   150,   120,   150,   120,   140}
    }
   ,{{   140,   110,   140,   110,   130}
    ,{   140,   110,   140,   110,   130}
    ,{   140,   110,   140,   110,   120}
    ,{   110,    20,   110,    20,    90}
    ,{   140,   110,   140,   110,   120}
    }
   ,{{   180,   150,   180,   150,   170}
    ,{   180,   150,   180,   150,   170}
    ,{   170,   140,   170,   140,   150}
    ,{   180,   150,   180,   150,   170}
    ,{   150,   120,   150,   120,   140}
    }
   ,{{   140,   110,   140,   110,   120}
    ,{   110,    20,   110,    20,    90}
    ,{   140,   110,   140,   110,   120}
    ,{   -10,   -40,   -10,   -40,   -20}
    ,{   140,   110,   140,   110,   120}
    }
   ,{{   180,   150,   180,   150,   170}
    ,{   180,   150,   180,   150,   170}
    ,{   150,   120,   150,   120,   140}
    ,{   180,   150,   180,   150,   170}
    ,{    60,    30,    60,    30,    50}
    }
   }
  ,{{{   200,   110,   200,    80,   200}
    ,{   200,    60,   200,    10,   200}
    ,{   180,   110,   180,   -10,   180}
    ,{   200,    60,   200,    80,   200}
    ,{   170,    90,   170,    20,   170}
    }
   ,{{   160,    20,   160,     0,   160}
    ,{   160,    20,   160,   -30,   160}
    ,{   150,    20,   150,   -40,   150}
    ,{    60,   -70,    60,     0,    60}
    ,{   150,    20,   150,   -40,   150}
    }
   ,{{   200,   110,   200,    10,   200}
    ,{   200,    60,   200,    10,   200}
    ,{   180,   110,   180,   -10,   180}
    ,{   200,    60,   200,    10,   200}
    ,{   170,    90,   170,   -20,   170}
    }
   ,{{   150,    20,   150,    80,   150}
    ,{    60,   -70,    60,     0,    60}
    ,{   150,    20,   150,   -40,   150}
    ,{    80,     0,    10,    80,    10}
    ,{   150,    20,   150,   -40,   150}
    }
   ,{{   200,    90,   200,    20,   200}
    ,{   200,    60,   200,    10,   200}
    ,{   170,    90,   170,   -20,   170}
    ,{   200,    60,   200,    10,   200}
    ,{    80,   -50,    80,    20,    80}
    }
   }
  ,{{{   170,   150,   170,   150,   100}
    ,{   170,   150,   170,   150,   100}
    ,{   150,   140,   150,   140,    60}
    ,{   170,   150,   170,   150,    80}
    ,{   140,   120,   140,   120,    50}
    }
   ,{{   130,   110,   130,   110,   100}
    ,{   130,   110,   130,   110,   100}
    ,{   120,   110,   120,   110,    30}
    ,{    90,    20,    90,    20,   -50}
    ,{   120,   110,   120,   110,    30}
    }
   ,{{   170,   150,   170,   150,    80}
    ,{   170,   150,   170,   150,    80}
    ,{   150,   140,   150,   140,    60}
    ,{   170,   150,   170,   150,    80}
    ,{   140,   120,   140,   120,    50}
    }
   ,{{   120,   110,   120,   110,    30}
    ,{    90,    20,    90,    20,   -50}
    ,{   120,   110,   120,   110,    30}
    ,{    20,   -40,   -20,   -40,    20}
    ,{   120,   110,   120,   110,    30}
    }
   ,{{   170,   150,   170,   150,    80}
    ,{   170,   150,   170,   150,    80}
    ,{   140,   120,   140,   120,    50}
    ,{   170,   150,   170,   150,    80}
    ,{    50,    30,    50,    30,   -40}
    }
   }
  }
 ,{{{{   220,   150,   220,   140,   170}
    ,{   220,   130,   220,   130,   170}
    ,{   150,   110,   150,   110,   150}
    ,{   140,   100,   140,   100,   140}
    ,{   170,   150,   150,   140,   170}
    }
   ,{{   220,   130,   220,   130,   170}
    ,{   220,   130,   220,   130,   170}
    ,{   150,   110,   150,   100,   150}
    ,{    70,   -30,    70,   -70,    50}
    ,{   150,   110,   150,   100,   150}
    }
   ,{{   190,   110,   190,   100,   170}
    ,{   190,   110,   190,   100,   140}
    ,{   150,   110,   150,   100,   150}
    ,{   140,   100,   140,   100,   140}
    ,{   170,   110,   150,   100,   170}
    }
   ,{{   150,   110,   150,   100,   150}
    ,{   140,    70,    70,   -10,   140}
    ,{   150,   110,   150,   100,   150}
    ,{    80,   -30,    10,    80,    70}
    ,{   150,   110,   150,   100,   150}
    }
   ,{{   150,   150,   150,   140,   150}
    ,{   140,   100,   140,   100,   140}
    ,{   150,   110,   150,   110,   150}
    ,{   140,   100,   140,   100,   140}
    ,{   150,   150,    70,   140,    70}
    }
   }
  ,{{{   170,   150,   150,    90,   170}
    ,{   170,   130,   140,    10,   170}
    ,{   150,   110,   150,    80,   150}
    ,{   140,   100,   140,    10,   140}
    ,{   150,   150,   150,    90,   150}
    }
   ,{{   170,   130,   150,    10,   170}
    ,{   170,   130,    60,     0,   170}
    ,{   150,   110,   150,   -70,   150}
    ,{    10,   -30,    10,  -160,   -30}
    ,{   150,   110,   150,    10,   150}
    }
   ,{{   150,   110,   150,    70,   150}
    ,{   140,   100,    50,  -100,   140}
    ,{   150,   110,   150,   -60,   150}
    ,{   140,   100,   140,    10,   140}
    ,{   150,   110,   150,    70,   150}
    }
   ,{{   150,   110,   150,    10,   150}
    ,{    40,    40,    30,   -70,    30}
    ,{   150,   110,   150,    10,   150}
    ,{    10,   -30,   -30,     0,    10}
    ,{   150,   110,   150,    10,   150}
    }
   ,{{   150,   150,   150,    90,   150}
    ,{   140,   100,   140,    10,   140}
    ,{   150,   110,   150,    80,   150}
    ,{   140,   100,   140,    10,   140}
    ,{   150,   150,     0,    90,    70}
    }
   }
  ,{{{   220,   130,   220,   130,   170}
    ,{   220,   130,   220,   130,   140}
    ,{   140,   110,   140,   110,   120}
    ,{   130,   100,   130,   100,   110}
    ,{   170,   100,   130,   100,   170}
    }
   ,{{   220,   130,   220,   130,   140}
    ,{   220,   130,   220,   130,   140}
    ,{   130,   100,   130,   100,   120}
    ,{    70,   -70,    70,   -70,     0}
    ,{   130,   100,   130,   100,   120}
    }
   ,{{   190,   110,   190,   100,   170}
    ,{   190,   110,   190,   100,   110}
    ,{   130,   100,   130,   100,   120}
    ,{   130,   100,   130,   100,   110}
    ,{   170,   100,   130,   100,   170}
    }
   ,{{   130,   100,   130,   100,   120}
    ,{    70,    70,    70,   -10,    60}
    ,{   130,   100,   130,   100,   120}
    ,{    20,   -40,   -10,   -40,    20}
    ,{   130,   100,   130,   100,   120}
    }
   ,{{   140,   110,   140,   110,   120}
    ,{   130,   100,   130,   100,   110}
    ,{   140,   110,   140,   110,   120}
    ,{   130,   100,   130,   100,   110}
    ,{    30,   -20,   -10,    30,    20}
    }
   }
  ,{{{   170,    90,   170,   140,   170}
    ,{   170,    70,   170,   -10,   170}
    ,{   150,    80,   150,   -40,   150}
    ,{   140,    10,   140,    80,   140}
    ,{   150,    90,   150,   140,   150}
    }
   ,{{   170,    10,   170,   -10,   170}
    ,{   170,   -20,   170,   -10,   170}
    ,{   150,   -40,   150,   -40,   150}
    ,{   -30,  -170,   -30,   -90,   -30}
    ,{   150,    10,   150,   -40,   150}
    }
   ,{{   150,    70,   150,    20,   150}
    ,{   140,    70,   140,   -50,   140}
    ,{   150,    70,   150,   -40,   150}
    ,{   140,    10,   140,   -50,   140}
    ,{   150,    70,   150,    20,   150}
    }
   ,{{   150,    10,   150,    80,   150}
    ,{    30,   -50,    30,   -30,    30}
    ,{   150,    10,   150,   -40,   150}
    ,{    80,   -30,    10,    80,    10}
    ,{   150,    10,   150,   -40,   150}
    }
   ,{{   150,    90,   150,   140,   150}
    ,{   140,    10,   140,   -50,   140}
    ,{   150,    80,   150,   -50,   150}
    ,{   140,    10,   140,   -50,   140}
    ,{   140,    90,    70,   140,    70}
    }
   }
  ,{{{   140,   130,   140,   130,   140}
    ,{   140,   130,   140,   130,   140}
    ,{   120,   110,   120,   110,    30}
    ,{   110,   100,   110,   100,    70}
    ,{   120,   100,   120,   100,    30}
    }
   ,{{   140,   130,   140,   130,   140}
    ,{   140,   130,   140,   130,   140}
    ,{   120,   100,   120,   100,    30}
    ,{    50,   -70,     0,   -70,    50}
    ,{   120,   100,   120,   100,    30}
    }
   ,{{   120,   100,   120,   100,    30}
    ,{   110,   100,   110,   100,    30}
    ,{   120,   100,   120,   100,    30}
    ,{   110,   100,   110,   100,    20}
    ,{   120,   100,   120,   100,    30}
    }
   ,{{   140,   100,   120,   100,   140}
    ,{   140,   -10,    50,   -10,   140}
    ,{   120,   100,   120,   100,    30}
    ,{    70,   -40,   -60,   -40,    70}
    ,{   120,   100,   120,   100,    30}
    }
   ,{{   120,   110,   120,   110,    30}
    ,{   110,   100,   110,   100,    20}
    ,{   120,   110,   120,   110,    30}
    ,{   110,   100,   110,   100,    20}
    ,{    40,    30,    40,    30,   -60}
    }
   }
  }
 ,{{{{   300,   290,   300,   260,   300}
    ,{   300,   270,   300,   260,   300}
    ,{   270,   230,   270,   220,   270}
    ,{   270,   230,   270,   220,   270}
    ,{   290,   290,   270,   220,   270}
    }
   ,{{   300,   270,   300,   260,   300}
    ,{   300,   270,   300,   260,   300}
    ,{   270,   230,   270,   220,   270}
    ,{   230,   150,   230,   140,   220}
    ,{   270,   230,   270,   220,   270}
    }
   ,{{   270,   230,   270,   220,   270}
    ,{   270,   230,   270,   220,   270}
    ,{   270,   230,   270,   220,   270}
    ,{   270,   230,   270,   220,   270}
    ,{   270,   230,   270,   220,   270}
    }
   ,{{   270,   230,   270,   220,   270}
    ,{   270,   190,   270,   180,   260}
    ,{   270,   230,   270,   220,   270}
    ,{   210,   130,   140,   210,   150}
    ,{   270,   230,   270,   220,   270}
    }
   ,{{   290,   290,   270,   220,   270}
    ,{   270,   230,   270,   220,   270}
    ,{   270,   230,   270,   220,   270}
    ,{   270,   230,   270,   220,   270}
    ,{   290,   290,   270,   220,   270}
    }
   }
  ,{{{   300,   290,   300,   190,   300}
    ,{   300,   270,   300,   170,   300}
    ,{   270,   230,   270,   190,   270}
    ,{   270,   230,   270,   130,   270}
    ,{   290,   290,   270,   190,   270}
    }
   ,{{   300,   270,   300,   170,   300}
    ,{   300,   270,   300,   170,   300}
    ,{   270,   230,   270,   130,   270}
    ,{   190,   150,   190,    50,   190}
    ,{   270,   230,   270,   130,   270}
    }
   ,{{   270,   230,   270,   190,   270}
    ,{   270,   230,   270,   130,   270}
    ,{   270,   230,   270,   190,   270}
    ,{   270,   230,   270,   130,   270}
    ,{   270,   230,   270,   190,   270}
    }
   ,{{   270,   230,   270,   130,   270}
    ,{   230,   190,   230,    90,   230}
    ,{   270,   230,   270,   130,   270}
    ,{   140,   100,   140,   130,   140}
    ,{   270,   230,   270,   130,   270}
    }
   ,{{   290,   290,   270,   190,   270}
    ,{   270,   230,   270,   130,   270}
    ,{   270,   230,   270,   190,   270}
    ,{   270,   230,   270,   130,   270}
    ,{   290,   290,   270,   130,   270}
    }
   }
  ,{{{   290,   260,   290,   260,   270}
    ,{   290,   260,   290,   260,   270}
    ,{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    }
   ,{{   290,   260,   290,   260,   270}
    ,{   290,   260,   290,   260,   270}
    ,{   250,   220,   250,   220,   240}
    ,{   230,   140,   230,   140,   220}
    ,{   250,   220,   250,   220,   240}
    }
   ,{{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    }
   ,{{   270,   220,   270,   220,   260}
    ,{   270,   180,   270,   180,   260}
    ,{   250,   220,   250,   220,   240}
    ,{   120,    90,   120,    90,   110}
    ,{   250,   220,   250,   220,   240}
    }
   ,{{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    }
   }
  ,{{{   300,   190,   300,   210,   300}
    ,{   300,   170,   300,   170,   300}
    ,{   270,   190,   270,    80,   270}
    ,{   270,   130,   270,   210,   270}
    ,{   270,   190,   270,   210,   270}
    }
   ,{{   300,   170,   300,   130,   300}
    ,{   300,   170,   300,   110,   300}
    ,{   270,   130,   270,    80,   270}
    ,{   190,    50,   190,   130,   190}
    ,{   270,   130,   270,    80,   270}
    }
   ,{{   270,   190,   270,    80,   270}
    ,{   270,   130,   270,    80,   270}
    ,{   270,   190,   270,    80,   270}
    ,{   270,   130,   270,    80,   270}
    ,{   270,   190,   270,    80,   270}
    }
   ,{{   270,   130,   270,   210,   270}
    ,{   230,    90,   230,   170,   230}
    ,{   270,   130,   270,    80,   270}
    ,{   210,   130,   140,   210,   140}
    ,{   270,   130,   270,    80,   270}
    }
   ,{{   270,   190,   270,   210,   270}
    ,{   270,   130,   270,    80,   270}
    ,{   270,   190,   270,    80,   270}
    ,{   270,   130,   270,    80,   270}
    ,{   270,   130,   270,   210,   270}
    }
   }
  ,{{{   270,   260,   270,   260,   240}
    ,{   270,   260,   270,   260,   240}
    ,{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    }
   ,{{   270,   260,   270,   260,   240}
    ,{   270,   260,   270,   260,   240}
    ,{   240,   220,   240,   220,   150}
    ,{   220,   140,   220,   140,    70}
    ,{   240,   220,   240,   220,   150}
    }
   ,{{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    }
   ,{{   260,   220,   260,   220,   150}
    ,{   260,   180,   260,   180,   110}
    ,{   240,   220,   240,   220,   150}
    ,{   150,    90,   110,    90,   150}
    ,{   240,   220,   240,   220,   150}
    }
   ,{{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    }
   }
  }
 ,{{{{   310,   260,   310,   220,   300}
    ,{   310,   230,   310,   220,   300}
    ,{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    ,{   260,   260,   240,   190,   240}
    }
   ,{{   240,   200,   240,   190,   240}
    ,{   200,   160,   200,   160,   200}
    ,{   240,   200,   240,   190,   240}
    ,{   150,    60,   150,    60,   130}
    ,{   240,   200,   240,   190,   240}
    }
   ,{{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    }
   ,{{   310,   230,   310,   220,   300}
    ,{   310,   230,   310,   220,   300}
    ,{   240,   200,   240,   190,   240}
    ,{   180,   100,   110,   180,   120}
    ,{   240,   200,   240,   190,   240}
    }
   ,{{   260,   260,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    ,{   260,   260,   240,   190,   240}
    }
   }
  ,{{{   270,   260,   270,   160,   270}
    ,{   270,   230,   270,   130,   270}
    ,{   240,   200,   240,   160,   240}
    ,{   240,   200,   240,   100,   240}
    ,{   260,   260,   240,   160,   240}
    }
   ,{{   240,   200,   240,   100,   240}
    ,{   200,   160,   200,    70,   200}
    ,{   240,   200,   240,   100,   240}
    ,{   100,    60,   100,   -30,   100}
    ,{   240,   200,   240,   100,   240}
    }
   ,{{   240,   200,   240,   160,   240}
    ,{   240,   200,   240,   100,   240}
    ,{   240,   200,   240,   160,   240}
    ,{   240,   200,   240,   100,   240}
    ,{   240,   200,   240,   160,   240}
    }
   ,{{   270,   230,   270,   130,   270}
    ,{   270,   230,   270,   130,   270}
    ,{   240,   200,   240,   100,   240}
    ,{   110,    70,   110,   100,   110}
    ,{   240,   200,   240,   100,   240}
    }
   ,{{   260,   260,   240,   160,   240}
    ,{   240,   200,   240,   100,   240}
    ,{   240,   200,   240,   160,   240}
    ,{   240,   200,   240,   100,   240}
    ,{   260,   260,   240,   100,   240}
    }
   }
  ,{{{   310,   220,   310,   220,   300}
    ,{   310,   220,   310,   220,   300}
    ,{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    }
   ,{{   220,   190,   220,   190,   210}
    ,{   190,   160,   190,   160,   170}
    ,{   220,   190,   220,   190,   210}
    ,{   150,    60,   150,    60,   130}
    ,{   220,   190,   220,   190,   210}
    }
   ,{{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    }
   ,{{   310,   220,   310,   220,   300}
    ,{   310,   220,   310,   220,   300}
    ,{   220,   190,   220,   190,   210}
    ,{    90,    60,    90,    60,    80}
    ,{   220,   190,   220,   190,   210}
    }
   ,{{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    }
   }
  ,{{{   270,   160,   270,   210,   270}
    ,{   270,   130,   270,   210,   270}
    ,{   240,   160,   240,    50,   240}
    ,{   240,   100,   240,   180,   240}
    ,{   240,   160,   240,   180,   240}
    }
   ,{{   240,   100,   240,    50,   240}
    ,{   200,    70,   200,    10,   200}
    ,{   240,   100,   240,    50,   240}
    ,{   100,   -30,   100,    40,   100}
    ,{   240,   100,   240,    50,   240}
    }
   ,{{   240,   160,   240,    50,   240}
    ,{   240,   100,   240,    50,   240}
    ,{   240,   160,   240,    50,   240}
    ,{   240,   100,   240,    50,   240}
    ,{   240,   160,   240,    50,   240}
    }
   ,{{   270,   130,   270,   210,   270}
    ,{   270,   130,   270,   210,   270}
    ,{   240,   100,   240,    50,   240}
    ,{   180,   100,   110,   180,   110}
    ,{   240,   100,   240,    50,   240}
    }
   ,{{   240,   160,   240,   180,   240}
    ,{   240,   100,   240,    50,   240}
    ,{   240,   160,   240,    50,   240}
    ,{   240,   100,   240,    50,   240}
    ,{   240,   100,   240,   180,   240}
    }
   }
  ,{{{   300,   220,   300,   220,   150}
    ,{   300,   220,   300,   220,   150}
    ,{   210,   190,   210,   190,   120}
    ,{   210,   190,   210,   190,   120}
    ,{   210,   190,   210,   190,   120}
    }
   ,{{   210,   190,   210,   190,   140}
    ,{   170,   160,   170,   160,   140}
    ,{   210,   190,   210,   190,   120}
    ,{   130,    60,   130,    60,   -10}
    ,{   210,   190,   210,   190,   120}
    }
   ,{{   210,   190,   210,   190,   120}
    ,{   210,   190,   210,   190,   120}
    ,{   210,   190,   210,   190,   120}
    ,{   210,   190,   210,   190,   120}
    ,{   210,   190,   210,   190,   120}
    }
   ,{{   300,   220,   300,   220,   150}
    ,{   300,   220,   300,   220,   150}
    ,{   210,   190,   210,   190,   120}
    ,{   120,    60,    80,    60,   120}
    ,{   210,   190,   210,   190,   120}
    }
   ,{{   210,   190,   210,   190,   120}
    ,{   210,   190,   210,   190,   120}
    ,{   210,   190,   210,   190,   120}
    ,{   210,   190,   210,   190,   120}
    ,{   210,   190,   210,   190,   120}
    }
   }
  }
 ,{{{{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    ,{   220,   180,   220,   170,   220}
    ,{   220,   180,   220,   180,   220}
    ,{   220,   180,   220,   170,   220}
    }
   ,{{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    ,{   210,   170,   210,   170,   210}
    ,{   160,    70,   160,    70,   140}
    ,{   210,   170,   210,   170,   210}
    }
   ,{{   220,   180,   220,   180,   220}
    ,{   220,   180,   220,   180,   220}
    ,{   220,   180,   220,   170,   220}
    ,{   220,   180,   220,   180,   220}
    ,{   220,   180,   220,   170,   220}
    }
   ,{{   230,   170,   230,   170,   210}
    ,{   230,   140,   230,   140,   210}
    ,{   210,   170,   210,   170,   210}
    ,{   130,    60,    60,   130,    70}
    ,{   210,   170,   210,   170,   210}
    }
   ,{{   220,   180,   220,   180,   220}
    ,{   220,   180,   220,   180,   220}
    ,{   220,   180,   220,   170,   220}
    ,{   220,   180,   220,   180,   220}
    ,{   150,   150,   130,    80,   130}
    }
   }
  ,{{{   240,   200,   240,   140,   240}
    ,{   240,   200,   240,   100,   240}
    ,{   220,   180,   220,   140,   220}
    ,{   220,   180,   220,    90,   220}
    ,{   220,   180,   220,   140,   220}
    }
   ,{{   240,   200,   240,   100,   240}
    ,{   240,   200,   240,   100,   240}
    ,{   210,   170,   210,    80,   210}
    ,{   110,    70,   110,   -20,   110}
    ,{   210,   170,   210,    80,   210}
    }
   ,{{   220,   180,   220,   140,   220}
    ,{   220,   180,   220,    90,   220}
    ,{   220,   180,   220,   140,   220}
    ,{   220,   180,   220,    90,   220}
    ,{   220,   180,   220,   140,   220}
    }
   ,{{   210,   170,   210,    80,   210}
    ,{   180,   140,   180,    50,   180}
    ,{   210,   170,   210,    80,   210}
    ,{    60,    20,    60,    60,    60}
    ,{   210,   170,   210,    80,   210}
    }
   ,{{   220,   180,   220,   140,   220}
    ,{   220,   180,   220,    90,   220}
    ,{   220,   180,   220,   140,   220}
    ,{   220,   180,   220,    90,   220}
    ,{   150,   150,   130,     0,   130}
    }
   }
  ,{{{   230,   190,   230,   190,   210}
    ,{   230,   190,   230,   190,   210}
    ,{   200,   170,   200,   170,   190}
    ,{   210,   180,   210,   180,   190}
    ,{   200,   170,   200,   170,   190}
    }
   ,{{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    ,{   200,   170,   200,   170,   180}
    ,{   160,    70,   160,    70,   140}
    ,{   200,   170,   200,   170,   180}
    }
   ,{{   210,   180,   210,   180,   190}
    ,{   210,   180,   210,   180,   190}
    ,{   200,   170,   200,   170,   190}
    ,{   210,   180,   210,   180,   190}
    ,{   200,   170,   200,   170,   190}
    }
   ,{{   230,   170,   230,   170,   210}
    ,{   230,   140,   230,   140,   210}
    ,{   200,   170,   200,   170,   180}
    ,{    50,    20,    50,    20,    30}
    ,{   200,   170,   200,   170,   180}
    }
   ,{{   210,   180,   210,   180,   190}
    ,{   210,   180,   210,   180,   190}
    ,{   200,   170,   200,   170,   190}
    ,{   210,   180,   210,   180,   190}
    ,{   110,    80,   110,    80,   100}
    }
   }
  ,{{{   240,   140,   240,   130,   240}
    ,{   240,   100,   240,   120,   240}
    ,{   220,   140,   220,    30,   220}
    ,{   220,    90,   220,   130,   220}
    ,{   220,   140,   220,    70,   220}
    }
   ,{{   240,   100,   240,    50,   240}
    ,{   240,   100,   240,    50,   240}
    ,{   210,    80,   210,    20,   210}
    ,{   110,   -20,   110,    50,   110}
    ,{   210,    80,   210,    20,   210}
    }
   ,{{   220,   140,   220,    30,   220}
    ,{   220,    90,   220,    30,   220}
    ,{   220,   140,   220,    30,   220}
    ,{   220,    90,   220,    30,   220}
    ,{   220,   140,   220,    30,   220}
    }
   ,{{   210,    80,   210,   130,   210}
    ,{   180,    50,   180,   120,   180}
    ,{   210,    80,   210,    20,   210}
    ,{   130,    60,    60,   130,    60}
    ,{   210,    80,   210,    20,   210}
    }
   ,{{   220,   140,   220,    70,   220}
    ,{   220,    90,   220,    30,   220}
    ,{   220,   140,   220,    30,   220}
    ,{   220,    90,   220,    30,   220}
    ,{   130,     0,   130,    70,   130}
    }
   }
  ,{{{   210,   190,   210,   190,   180}
    ,{   210,   190,   210,   190,   180}
    ,{   190,   170,   190,   170,   100}
    ,{   190,   180,   190,   180,   100}
    ,{   190,   170,   190,   170,   100}
    }
   ,{{   210,   190,   210,   190,   180}
    ,{   210,   190,   210,   190,   180}
    ,{   180,   170,   180,   170,    90}
    ,{   140,    70,   140,    70,     0}
    ,{   180,   170,   180,   170,    90}
    }
   ,{{   190,   180,   190,   180,   100}
    ,{   190,   180,   190,   180,   100}
    ,{   190,   170,   190,   170,   100}
    ,{   190,   180,   190,   180,   100}
    ,{   190,   170,   190,   170,   100}
    }
   ,{{   210,   170,   210,   170,    90}
    ,{   210,   140,   210,   140,    60}
    ,{   180,   170,   180,   170,    90}
    ,{    70,    20,    30,    20,    70}
    ,{   180,   170,   180,   170,    90}
    }
   ,{{   190,   180,   190,   180,   100}
    ,{   190,   180,   190,   180,   100}
    ,{   190,   170,   190,   170,   100}
    ,{   190,   180,   190,   180,   100}
    ,{   100,    80,   100,    80,    10}
    }
   }
  }
 ,{{{{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    }
   ,{{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    ,{   190,   150,   190,   150,   190}
    ,{   180,    90,   180,    90,   160}
    ,{   190,   150,   190,   150,   190}
    }
   ,{{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    }
   ,{{   190,   150,   190,   150,   190}
    ,{   190,   100,   190,   100,   170}
    ,{   190,   150,   190,   150,   190}
    ,{   150,    80,    80,   150,    90}
    ,{   190,   150,   190,   150,   190}
    }
   ,{{   240,   200,   240,   190,   240}
    ,{   240,   200,   240,   190,   240}
    ,{   210,   170,   210,   160,   210}
    ,{   240,   200,   240,   190,   240}
    ,{   170,   170,   150,   110,   150}
    }
   }
  ,{{{   240,   200,   240,   160,   240}
    ,{   240,   200,   240,   100,   240}
    ,{   240,   200,   240,   160,   240}
    ,{   240,   200,   240,   100,   240}
    ,{   240,   200,   240,   160,   240}
    }
   ,{{   240,   200,   240,   100,   240}
    ,{   240,   200,   240,   100,   240}
    ,{   190,   150,   190,    60,   190}
    ,{   130,    90,   130,     0,   130}
    ,{   190,   150,   190,    60,   190}
    }
   ,{{   240,   200,   240,   160,   240}
    ,{   240,   200,   240,   100,   240}
    ,{   240,   200,   240,   160,   240}
    ,{   240,   200,   240,   100,   240}
    ,{   240,   200,   240,   160,   240}
    }
   ,{{   190,   150,   190,    80,   190}
    ,{   140,   100,   140,    10,   140}
    ,{   190,   150,   190,    60,   190}
    ,{    80,    40,    80,    80,    80}
    ,{   190,   150,   190,    60,   190}
    }
   ,{{   240,   200,   240,   130,   240}
    ,{   240,   200,   240,   100,   240}
    ,{   210,   170,   210,   130,   210}
    ,{   240,   200,   240,   100,   240}
    ,{   170,   170,   150,    20,   150}
    }
   }
  ,{{{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    }
   ,{{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    ,{   180,   150,   180,   150,   160}
    ,{   180,    90,   180,    90,   160}
    ,{   180,   150,   180,   150,   160}
    }
   ,{{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    }
   ,{{   190,   150,   190,   150,   170}
    ,{   190,   100,   190,   100,   170}
    ,{   180,   150,   180,   150,   160}
    ,{    70,    40,    70,    40,    50}
    ,{   180,   150,   180,   150,   160}
    }
   ,{{   220,   190,   220,   190,   210}
    ,{   220,   190,   220,   190,   210}
    ,{   190,   160,   190,   160,   180}
    ,{   220,   190,   220,   190,   210}
    ,{   140,   110,   140,   110,   120}
    }
   }
  ,{{{   240,   160,   240,   150,   240}
    ,{   240,   100,   240,    80,   240}
    ,{   240,   160,   240,    50,   240}
    ,{   240,   100,   240,   150,   240}
    ,{   240,   160,   240,    90,   240}
    }
   ,{{   240,   100,   240,    70,   240}
    ,{   240,   100,   240,    50,   240}
    ,{   190,    60,   190,     0,   190}
    ,{   130,     0,   130,    70,   130}
    ,{   190,    60,   190,     0,   190}
    }
   ,{{   240,   160,   240,    50,   240}
    ,{   240,   100,   240,    50,   240}
    ,{   240,   160,   240,    50,   240}
    ,{   240,   100,   240,    50,   240}
    ,{   240,   160,   240,    50,   240}
    }
   ,{{   190,    80,   190,   150,   190}
    ,{   140,    10,   140,    80,   140}
    ,{   190,    60,   190,     0,   190}
    ,{   150,    80,    80,   150,    80}
    ,{   190,    60,   190,     0,   190}
    }
   ,{{   240,   130,   240,    90,   240}
    ,{   240,   100,   240,    50,   240}
    ,{   210,   130,   210,    20,   210}
    ,{   240,   100,   240,    50,   240}
    ,{   150,    20,   150,    90,   150}
    }
   }
  ,{{{   210,   190,   210,   190,   180}
    ,{   210,   190,   210,   190,   180}
    ,{   210,   190,   210,   190,   120}
    ,{   210,   190,   210,   190,   120}
    ,{   210,   190,   210,   190,   120}
    }
   ,{{   210,   190,   210,   190,   180}
    ,{   210,   190,   210,   190,   180}
    ,{   160,   150,   160,   150,    70}
    ,{   160,    90,   160,    90,    10}
    ,{   160,   150,   160,   150,    70}
    }
   ,{{   210,   190,   210,   190,   120}
    ,{   210,   190,   210,   190,   120}
    ,{   210,   190,   210,   190,   120}
    ,{   210,   190,   210,   190,   120}
    ,{   210,   190,   210,   190,   120}
    }
   ,{{   170,   150,   170,   150,    90}
    ,{   170,   100,   170,   100,    20}
    ,{   160,   150,   160,   150,    70}
    ,{    90,    40,    50,    40,    90}
    ,{   160,   150,   160,   150,    70}
    }
   ,{{   210,   190,   210,   190,   120}
    ,{   210,   190,   210,   190,   120}
    ,{   180,   160,   180,   160,    90}
    ,{   210,   190,   210,   190,   120}
    ,{   120,   110,   120,   110,    30}
    }
   }
  }
 ,{{{{   310,   290,   310,   260,   300}
    ,{   310,   270,   310,   260,   300}
    ,{   270,   230,   270,   220,   270}
    ,{   270,   230,   270,   220,   270}
    ,{   290,   290,   270,   220,   270}
    }
   ,{{   300,   270,   300,   260,   300}
    ,{   300,   270,   300,   260,   300}
    ,{   270,   230,   270,   220,   270}
    ,{   230,   150,   230,   140,   220}
    ,{   270,   230,   270,   220,   270}
    }
   ,{{   270,   230,   270,   220,   270}
    ,{   270,   230,   270,   220,   270}
    ,{   270,   230,   270,   220,   270}
    ,{   270,   230,   270,   220,   270}
    ,{   270,   230,   270,   220,   270}
    }
   ,{{   310,   230,   310,   220,   300}
    ,{   310,   230,   310,   220,   300}
    ,{   270,   230,   270,   220,   270}
    ,{   210,   130,   140,   210,   150}
    ,{   270,   230,   270,   220,   270}
    }
   ,{{   290,   290,   270,   220,   270}
    ,{   270,   230,   270,   220,   270}
    ,{   270,   230,   270,   220,   270}
    ,{   270,   230,   270,   220,   270}
    ,{   290,   290,   270,   220,   270}
    }
   }
  ,{{{   300,   290,   300,   190,   300}
    ,{   300,   270,   300,   170,   300}
    ,{   270,   230,   270,   190,   270}
    ,{   270,   230,   270,   130,   270}
    ,{   290,   290,   270,   190,   270}
    }
   ,{{   300,   270,   300,   170,   300}
    ,{   300,   270,   300,   170,   300}
    ,{   270,   230,   270,   130,   270}
    ,{   190,   150,   190,    50,   190}
    ,{   270,   230,   270,   130,   270}
    }
   ,{{   270,   230,   270,   190,   270}
    ,{   270,   230,   270,   130,   270}
    ,{   270,   230,   270,   190,   270}
    ,{   270,   230,   270,   130,   270}
    ,{   270,   230,   270,   190,   270}
    }
   ,{{   270,   230,   270,   130,   270}
    ,{   270,   230,   270,   130,   270}
    ,{   270,   230,   270,   130,   270}
    ,{   140,   100,   140,   130,   140}
    ,{   270,   230,   270,   130,   270}
    }
   ,{{   290,   290,   270,   190,   270}
    ,{   270,   230,   270,   130,   270}
    ,{   270,   230,   270,   190,   270}
    ,{   270,   230,   270,   130,   270}
    ,{   290,   290,   270,   130,   270}
    }
   }
  ,{{{   310,   260,   310,   260,   300}
    ,{   310,   260,   310,   260,   300}
    ,{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    }
   ,{{   290,   260,   290,   260,   270}
    ,{   290,   260,   290,   260,   270}
    ,{   250,   220,   250,   220,   240}
    ,{   230,   140,   230,   140,   220}
    ,{   250,   220,   250,   220,   240}
    }
   ,{{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    }
   ,{{   310,   220,   310,   220,   300}
    ,{   310,   220,   310,   220,   300}
    ,{   250,   220,   250,   220,   240}
    ,{   120,    90,   120,    90,   110}
    ,{   250,   220,   250,   220,   240}
    }
   ,{{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    ,{   250,   220,   250,   220,   240}
    }
   }
  ,{{{   300,   190,   300,   210,   300}
    ,{   300,   170,   300,   210,   300}
    ,{   270,   190,   270,    80,   270}
    ,{   270,   130,   270,   210,   270}
    ,{   270,   190,   270,   210,   270}
    }
   ,{{   300,   170,   300,   130,   300}
    ,{   300,   170,   300,   110,   300}
    ,{   270,   130,   270,    80,   270}
    ,{   190,    50,   190,   130,   190}
    ,{   270,   130,   270,    80,   270}
    }
   ,{{   270,   190,   270,    80,   270}
    ,{   270,   130,   270,    80,   270}
    ,{   270,   190,   270,    80,   270}
    ,{   270,   130,   270,    80,   270}
    ,{   270,   190,   270,    80,   270}
    }
   ,{{   270,   130,   270,   210,   270}
    ,{   270,   130,   270,   210,   270}
    ,{   270,   130,   270,    80,   270}
    ,{   210,   130,   140,   210,   140}
    ,{   270,   130,   270,    80,   270}
    }
   ,{{   270,   190,   270,   210,   270}
    ,{   270,   130,   270,    80,   270}
    ,{   270,   190,   270,    80,   270}
    ,{   270,   130,   270,    80,   270}
    ,{   270,   130,   270,   210,   270}
    }
   }
  ,{{{   300,   260,   300,   260,   240}
    ,{   300,   260,   300,   260,   240}
    ,{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    }
   ,{{   270,   260,   270,   260,   240}
    ,{   270,   260,   270,   260,   240}
    ,{   240,   220,   240,   220,   150}
    ,{   220,   140,   220,   140,    70}
    ,{   240,   220,   240,   220,   150}
    }
   ,{{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    }
   ,{{   300,   220,   300,   220,   150}
    ,{   300,   220,   300,   220,   150}
    ,{   240,   220,   240,   220,   150}
    ,{   150,    90,   110,    90,   150}
    ,{   240,   220,   240,   220,   150}
    }
   ,{{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    ,{   240,   220,   240,   220,   150}
    }
   }
  }
 }
,{{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   220,   220,   190,   150,   150}
    ,{   170,   170,   150,   150,   150}
    ,{   220,   220,   190,   130,   140}
    ,{   170,   170,   150,   150,   150}
    ,{   140,   140,   120,   140,   120}
    }
   ,{{   150,   130,   110,   110,   150}
    ,{   150,   130,   110,   110,   150}
    ,{   130,   130,   110,   100,   110}
    ,{    90,    10,    70,    10,    90}
    ,{   130,   130,   100,   100,   110}
    }
   ,{{   220,   220,   190,   150,   150}
    ,{   150,   150,   150,   150,   150}
    ,{   220,   220,   190,   130,   140}
    ,{   170,   170,   150,   150,   150}
    ,{   140,   140,   120,   120,   120}
    }
   ,{{   140,   130,   100,   100,   140}
    ,{    90,    10,    70,    10,    90}
    ,{   130,   130,   100,   100,   110}
    ,{   140,   -10,    20,    80,   140}
    ,{   130,   130,   100,   100,   110}
    }
   ,{{   170,   170,   170,   150,   150}
    ,{   170,   170,   150,   150,   150}
    ,{   170,   140,   170,   120,   120}
    ,{   170,   170,   150,   150,   150}
    ,{   140,   140,    30,   140,    30}
    }
   }
  ,{{{   220,   220,   190,   140,   140}
    ,{   170,   170,   140,    40,   140}
    ,{   220,   220,   190,    70,   130}
    ,{   170,   170,   140,    30,   140}
    ,{   140,   140,   110,   140,   110}
    }
   ,{{   130,   130,   110,    70,   100}
    ,{   130,   130,   100,    40,   100}
    ,{   130,   130,   110,    70,   100}
    ,{    70,   -20,    70,   -50,    10}
    ,{   130,   130,   100,   -10,   100}
    }
   ,{{   220,   220,   190,    70,   140}
    ,{   140,    60,    50,    30,   140}
    ,{   220,   220,   190,    70,   130}
    ,{   170,   170,   140,    30,   140}
    ,{   140,   140,   110,    50,   110}
    }
   ,{{   130,   130,   100,   -10,   100}
    ,{    10,     0,  -100,   -70,    10}
    ,{   130,   130,   100,   -10,   100}
    ,{   -10,   -10,   -50,   -30,   -50}
    ,{   130,   130,   100,   -10,   100}
    }
   ,{{   170,   170,   140,   140,   140}
    ,{   170,   170,   140,    30,   140}
    ,{   140,   140,   110,    60,   110}
    ,{   170,   170,   140,    30,   140}
    ,{   140,   140,    30,   140,    20}
    }
   }
  ,{{{   150,   150,   150,   150,   150}
    ,{   150,   150,   150,   150,   150}
    ,{   140,   130,   130,   130,   140}
    ,{   150,   150,   150,   150,   150}
    ,{   120,   120,   120,   120,   120}
    }
   ,{{   110,   110,   110,   110,   110}
    ,{   110,   110,   110,   110,   110}
    ,{   110,   100,   100,   100,   110}
    ,{    80,   -40,    70,    10,    80}
    ,{   110,   100,   100,   100,   110}
    }
   ,{{   150,   150,   150,   150,   150}
    ,{   150,   150,   150,   150,   150}
    ,{   140,   130,   130,   130,   140}
    ,{   150,   150,   150,   150,   150}
    ,{   120,   120,   120,   120,   120}
    }
   ,{{   110,   100,   100,   100,   110}
    ,{    80,   -70,   -60,    10,    80}
    ,{   110,   100,   100,   100,   110}
    ,{   -40,   -40,   -40,   -40,   -50}
    ,{   110,   100,   100,   100,   110}
    }
   ,{{   150,   150,   150,   150,   150}
    ,{   150,   150,   150,   150,   150}
    ,{   120,   120,   120,   120,   120}
    ,{   150,   150,   150,   150,   150}
    ,{    30,    30,    30,    30,    30}
    }
   }
  ,{{{   140,    70,   140,    80,   140}
    ,{   140,    10,   140,    10,   140}
    ,{   130,    70,   130,    20,   130}
    ,{   140,   -30,   140,    80,   140}
    ,{   110,    50,   110,    70,   110}
    }
   ,{{   100,   -30,   100,   -30,   100}
    ,{   100,   -30,   100,   -30,   100}
    ,{   100,   -70,   100,   -40,   100}
    ,{    10,  -170,    10,   -30,    10}
    ,{   100,   -70,   100,   -40,   100}
    }
   ,{{   140,    70,   140,    10,   140}
    ,{   140,    10,   140,   -30,   140}
    ,{   130,    70,   130,   -10,   130}
    ,{   140,   -30,   140,    10,   140}
    ,{   110,     0,   110,   -60,   110}
    }
   ,{{   100,   -70,   100,    80,   100}
    ,{    10,  -160,    10,     0,    10}
    ,{   100,   -70,   100,   -40,   100}
    ,{    80,   -90,   -50,    80,   -50}
    ,{   100,   -70,   100,   -40,   100}
    }
   ,{{   140,    50,   140,    70,   140}
    ,{   140,   -30,   140,    10,   140}
    ,{   110,     0,   110,    20,   110}
    ,{   140,   -30,   140,    10,   140}
    ,{    70,    50,    20,    70,    20}
    }
   }
  ,{{{   170,   150,   170,   150,   150}
    ,{   150,   150,   150,   150,   150}
    ,{   170,   130,   170,   130,    30}
    ,{   150,   150,   150,   150,   140}
    ,{   120,   120,   120,   120,    40}
    }
   ,{{   150,   110,   110,   110,   150}
    ,{   150,   110,   110,   110,   150}
    ,{   100,   100,   100,   100,   -20}
    ,{    90,    10,    70,    10,    90}
    ,{   100,   100,   100,   100,    30}
    }
   ,{{   150,   150,   150,   150,    70}
    ,{   150,   150,   150,   150,     0}
    ,{   130,   130,   130,   130,   -10}
    ,{   150,   150,   150,   150,    70}
    ,{   120,   120,   120,   120,    40}
    }
   ,{{   140,   100,   100,   100,   140}
    ,{    90,    10,    70,    10,    90}
    ,{   100,   100,   100,   100,    30}
    ,{   140,   -40,    20,   -40,   140}
    ,{   100,   100,   100,   100,    30}
    }
   ,{{   170,   150,   170,   150,    70}
    ,{   150,   150,   150,   150,    70}
    ,{   170,   120,   170,   120,    20}
    ,{   150,   150,   150,   150,    70}
    ,{    30,    30,    30,    30,   -60}
    }
   }
  }
 ,{{{{   150,   150,   120,   120,   130}
    ,{   150,   150,   120,   120,   130}
    ,{   130,   130,   100,   100,   110}
    ,{   120,   120,    90,    90,   100}
    ,{   120,   120,   100,   100,   100}
    }
   ,{{   150,   150,   120,   120,   130}
    ,{   150,   150,   120,   120,   130}
    ,{   120,   120,   100,   100,   100}
    ,{   -10,   -50,   -20,   -80,   -10}
    ,{   120,   120,   100,   100,   100}
    }
   ,{{   120,   120,   100,   100,   100}
    ,{   120,   120,    90,    90,   100}
    ,{   120,   120,   100,   100,   100}
    ,{   120,   120,    90,    90,   100}
    ,{   120,   120,   100,   100,   100}
    }
   ,{{   120,   120,   100,   100,   100}
    ,{    50,    10,    50,   -10,    50}
    ,{   120,   120,   100,   100,   100}
    ,{    80,   -20,   -40,    80,    10}
    ,{   120,   120,   100,   100,   100}
    }
   ,{{   130,   130,   100,   100,   110}
    ,{   120,   120,    90,    90,   100}
    ,{   130,   130,   100,   100,   110}
    ,{   120,   120,    90,    90,   100}
    ,{   110,   110,    20,    20,    30}
    }
   }
  ,{{{   150,   150,   120,    50,   120}
    ,{   150,   150,   120,    10,   120}
    ,{   130,   130,   100,    50,   100}
    ,{   120,   120,    90,   -20,    90}
    ,{   120,   120,    90,    50,    90}
    }
   ,{{   150,   150,   120,    10,   120}
    ,{   150,   150,   120,    10,   120}
    ,{   120,   120,    90,   -10,    90}
    ,{   -50,   -50,   -80,  -190,   -80}
    ,{   120,   120,    90,   -10,    90}
    }
   ,{{   120,   120,    90,    50,    90}
    ,{   120,   120,    90,   -20,    90}
    ,{   120,   120,    90,    50,    90}
    ,{   120,   120,    90,   -20,    90}
    ,{   120,   120,    90,    50,    90}
    }
   ,{{   120,   120,    90,   -10,    90}
    ,{    10,    10,   -20,  -130,   -20}
    ,{   120,   120,    90,   -10,    90}
    ,{   -20,   -20,   -50,   -20,   -50}
    ,{   120,   120,    90,   -10,    90}
    }
   ,{{   130,   130,   100,    50,   100}
    ,{   120,   120,    90,   -20,    90}
    ,{   130,   130,   100,    50,   100}
    ,{   120,   120,    90,   -20,    90}
    ,{   110,   110,    20,   -90,    20}
    }
   }
  ,{{{   130,   120,   120,   120,   130}
    ,{   130,   120,   120,   120,   130}
    ,{   110,   100,   100,   100,   110}
    ,{   100,    90,    90,    90,   100}
    ,{   100,   100,   100,   100,   100}
    }
   ,{{   130,   120,   120,   120,   130}
    ,{   130,   120,   120,   120,   130}
    ,{   100,   100,   100,   100,   100}
    ,{   -10,   -80,   -20,   -80,   -10}
    ,{   100,   100,   100,   100,   100}
    }
   ,{{   100,   100,   100,   100,   100}
    ,{   100,    90,    90,    90,   100}
    ,{   100,   100,   100,   100,   100}
    ,{   100,    90,    90,    90,   100}
    ,{   100,   100,   100,   100,   100}
    }
   ,{{   100,   100,   100,   100,   100}
    ,{    50,   -10,    50,   -10,    50}
    ,{   100,   100,   100,   100,   100}
    ,{   -40,   -40,   -40,   -40,   -40}
    ,{   100,   100,   100,   100,   100}
    }
   ,{{   110,   100,   100,   100,   110}
    ,{   100,    90,    90,    90,   100}
    ,{   110,   100,   100,   100,   110}
    ,{   100,    90,    90,    90,   100}
    ,{    30,    20,    20,    20,    30}
    }
   }
  ,{{{   120,   -10,   120,    80,   120}
    ,{   120,   -50,   120,   -20,   120}
    ,{   100,   -10,   100,   -40,   100}
    ,{    90,   -80,    90,    80,    90}
    ,{    90,   -20,    90,    10,    90}
    }
   ,{{   120,   -50,   120,   -20,   120}
    ,{   120,   -50,   120,   -20,   120}
    ,{    90,   -80,    90,   -40,    90}
    ,{   -80,  -260,   -80,   -90,   -80}
    ,{    90,   -80,    90,   -40,    90}
    }
   ,{{    90,   -20,    90,   -40,    90}
    ,{    90,   -80,    90,   -50,    90}
    ,{    90,   -20,    90,   -40,    90}
    ,{    90,   -80,    90,   -50,    90}
    ,{    90,   -20,    90,   -40,    90}
    }
   ,{{    90,   -80,    90,    80,    90}
    ,{   -20,  -190,   -20,   -20,   -20}
    ,{    90,   -80,    90,   -40,    90}
    ,{    80,   -90,   -50,    80,   -50}
    ,{    90,   -80,    90,   -40,    90}
    }
   ,{{   100,   -10,   100,    10,   100}
    ,{    90,   -80,    90,   -50,    90}
    ,{   100,   -10,   100,   -40,   100}
    ,{    90,   -80,    90,   -50,    90}
    ,{    20,  -150,    20,    10,    20}
    }
   }
  ,{{{   120,   120,   120,   120,   110}
    ,{   120,   120,   120,   120,   110}
    ,{   100,   100,   100,   100,    30}
    ,{    90,    90,    90,    90,    20}
    ,{   100,   100,   100,   100,    20}
    }
   ,{{   120,   120,   120,   120,   110}
    ,{   120,   120,   120,   120,   110}
    ,{   100,   100,   100,   100,    20}
    ,{   -20,   -80,   -20,   -80,  -150}
    ,{   100,   100,   100,   100,    20}
    }
   ,{{   100,   100,   100,   100,    20}
    ,{    90,    90,    90,    90,    20}
    ,{   100,   100,   100,   100,    20}
    ,{    90,    90,    90,    90,    20}
    ,{   100,   100,   100,   100,    20}
    }
   ,{{   100,   100,   100,   100,    20}
    ,{    50,   -10,    50,   -10,   -90}
    ,{   100,   100,   100,   100,    20}
    ,{    10,   -40,   -40,   -40,    10}
    ,{   100,   100,   100,   100,    20}
    }
   ,{{   100,   100,   100,   100,    30}
    ,{    90,    90,    90,    90,    20}
    ,{   100,   100,   100,   100,    30}
    ,{    90,    90,    90,    90,    20}
    ,{    20,    20,    20,    20,   -50}
    }
   }
  }
 ,{{{{   300,   300,   250,   250,   260}
    ,{   280,   280,   250,   250,   260}
    ,{   240,   240,   220,   220,   220}
    ,{   240,   240,   220,   220,   220}
    ,{   300,   300,   220,   220,   220}
    }
   ,{{   280,   280,   250,   250,   260}
    ,{   280,   280,   250,   250,   260}
    ,{   240,   240,   220,   220,   220}
    ,{   200,   160,   200,   140,   200}
    ,{   240,   240,   220,   220,   220}
    }
   ,{{   240,   240,   220,   220,   220}
    ,{   240,   240,   220,   220,   220}
    ,{   240,   240,   220,   220,   220}
    ,{   240,   240,   220,   220,   220}
    ,{   240,   240,   220,   220,   220}
    }
   ,{{   240,   240,   240,   220,   240}
    ,{   240,   200,   240,   180,   240}
    ,{   240,   240,   220,   220,   220}
    ,{   210,   110,    90,   210,   140}
    ,{   240,   240,   220,   220,   220}
    }
   ,{{   300,   300,   220,   220,   220}
    ,{   240,   240,   220,   220,   220}
    ,{   240,   240,   220,   220,   220}
    ,{   240,   240,   220,   220,   220}
    ,{   300,   300,   220,   220,   220}
    }
   }
  ,{{{   300,   300,   250,   160,   250}
    ,{   280,   280,   250,   140,   250}
    ,{   240,   240,   210,   160,   210}
    ,{   240,   240,   210,   100,   210}
    ,{   300,   300,   210,   160,   210}
    }
   ,{{   280,   280,   250,   140,   250}
    ,{   280,   280,   250,   140,   250}
    ,{   240,   240,   210,   100,   210}
    ,{   160,   160,   130,    20,   130}
    ,{   240,   240,   210,   100,   210}
    }
   ,{{   240,   240,   210,   160,   210}
    ,{   240,   240,   210,   100,   210}
    ,{   240,   240,   210,   160,   210}
    ,{   240,   240,   210,   100,   210}
    ,{   240,   240,   210,   160,   210}
    }
   ,{{   240,   240,   210,   100,   210}
    ,{   200,   200,   170,    60,   170}
    ,{   240,   240,   210,   100,   210}
    ,{   110,   110,    80,   100,    80}
    ,{   240,   240,   210,   100,   210}
    }
   ,{{   300,   300,   210,   160,   210}
    ,{   240,   240,   210,   100,   210}
    ,{   240,   240,   210,   160,   210}
    ,{   240,   240,   210,   100,   210}
    ,{   300,   300,   210,   100,   210}
    }
   }
  ,{{{   260,   250,   250,   250,   260}
    ,{   260,   250,   250,   250,   260}
    ,{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   260,   250,   250,   250,   260}
    ,{   260,   250,   250,   250,   260}
    ,{   220,   220,   220,   220,   220}
    ,{   200,   140,   200,   140,   200}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   240,   220,   240,   220,   240}
    ,{   240,   180,   240,   180,   240}
    ,{   220,   220,   220,   220,   220}
    ,{    90,    90,    90,    90,    90}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    }
   }
  ,{{{   250,   100,   250,   210,   250}
    ,{   250,    70,   250,   170,   250}
    ,{   210,   100,   210,    80,   210}
    ,{   210,    40,   210,   210,   210}
    ,{   210,   100,   210,   210,   210}
    }
   ,{{   250,    70,   250,   130,   250}
    ,{   250,    70,   250,   110,   250}
    ,{   210,    40,   210,    80,   210}
    ,{   130,   -40,   130,   130,   130}
    ,{   210,    40,   210,    80,   210}
    }
   ,{{   210,   100,   210,    80,   210}
    ,{   210,    40,   210,    80,   210}
    ,{   210,   100,   210,    80,   210}
    ,{   210,    40,   210,    80,   210}
    ,{   210,   100,   210,    80,   210}
    }
   ,{{   210,    40,   210,   210,   210}
    ,{   170,     0,   170,   170,   170}
    ,{   210,    40,   210,    80,   210}
    ,{   210,    40,    80,   210,    80}
    ,{   210,    40,   210,    80,   210}
    }
   ,{{   210,   100,   210,   210,   210}
    ,{   210,    40,   210,    80,   210}
    ,{   210,   100,   210,    80,   210}
    ,{   210,    40,   210,    80,   210}
    ,{   210,    40,   210,   210,   210}
    }
   }
  ,{{{   250,   250,   250,   250,   240}
    ,{   250,   250,   250,   250,   240}
    ,{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    }
   ,{{   250,   250,   250,   250,   240}
    ,{   250,   250,   250,   250,   240}
    ,{   220,   220,   220,   220,   140}
    ,{   200,   140,   200,   140,    60}
    ,{   220,   220,   220,   220,   140}
    }
   ,{{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    }
   ,{{   240,   220,   240,   220,   140}
    ,{   240,   180,   240,   180,   100}
    ,{   220,   220,   220,   220,   140}
    ,{   140,    90,    90,    90,   140}
    ,{   220,   220,   220,   220,   140}
    }
   ,{{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    }
   }
  }
 ,{{{{   280,   270,   280,   220,   280}
    ,{   280,   240,   280,   220,   280}
    ,{   210,   210,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    ,{   270,   270,   190,   190,   190}
    }
   ,{{   210,   210,   190,   190,   190}
    ,{   190,   190,   150,   150,   160}
    ,{   210,   210,   190,   190,   190}
    ,{   120,    80,   110,    50,   120}
    ,{   210,   210,   190,   190,   190}
    }
   ,{{   210,   210,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    }
   ,{{   280,   240,   280,   220,   280}
    ,{   280,   240,   280,   220,   280}
    ,{   210,   210,   190,   190,   190}
    ,{   180,    80,    60,   180,   110}
    ,{   210,   210,   190,   190,   190}
    }
   ,{{   270,   270,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    ,{   270,   270,   190,   190,   190}
    }
   }
  ,{{{   270,   270,   210,   130,   210}
    ,{   240,   240,   210,   100,   210}
    ,{   210,   210,   180,   130,   180}
    ,{   210,   210,   180,    70,   180}
    ,{   270,   270,   180,   130,   180}
    }
   ,{{   210,   210,   180,    70,   180}
    ,{   190,   190,   150,    40,   150}
    ,{   210,   210,   180,    70,   180}
    ,{    80,    80,    50,   -60,    50}
    ,{   210,   210,   180,    70,   180}
    }
   ,{{   210,   210,   180,   130,   180}
    ,{   210,   210,   180,    70,   180}
    ,{   210,   210,   180,   130,   180}
    ,{   210,   210,   180,    70,   180}
    ,{   210,   210,   180,   130,   180}
    }
   ,{{   240,   240,   210,   100,   210}
    ,{   240,   240,   210,   100,   210}
    ,{   210,   210,   180,    70,   180}
    ,{    80,    80,    50,    70,    50}
    ,{   210,   210,   180,    70,   180}
    }
   ,{{   270,   270,   180,   130,   180}
    ,{   210,   210,   180,    70,   180}
    ,{   210,   210,   180,   130,   180}
    ,{   210,   210,   180,    70,   180}
    ,{   270,   270,   180,    70,   180}
    }
   }
  ,{{{   280,   220,   280,   220,   280}
    ,{   280,   220,   280,   220,   280}
    ,{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    }
   ,{{   190,   190,   190,   190,   190}
    ,{   160,   150,   150,   150,   160}
    ,{   190,   190,   190,   190,   190}
    ,{   120,    50,   110,    50,   120}
    ,{   190,   190,   190,   190,   190}
    }
   ,{{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    }
   ,{{   280,   220,   280,   220,   280}
    ,{   280,   220,   280,   220,   280}
    ,{   190,   190,   190,   190,   190}
    ,{    60,    60,    60,    60,    60}
    ,{   190,   190,   190,   190,   190}
    }
   ,{{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    }
   }
  ,{{{   210,    70,   210,   210,   210}
    ,{   210,    40,   210,   210,   210}
    ,{   180,    70,   180,    50,   180}
    ,{   180,    10,   180,   180,   180}
    ,{   180,    70,   180,   180,   180}
    }
   ,{{   180,    10,   180,    50,   180}
    ,{   150,   -20,   150,    10,   150}
    ,{   180,    10,   180,    50,   180}
    ,{    50,  -120,    50,    40,    50}
    ,{   180,    10,   180,    50,   180}
    }
   ,{{   180,    70,   180,    50,   180}
    ,{   180,    10,   180,    50,   180}
    ,{   180,    70,   180,    50,   180}
    ,{   180,    10,   180,    50,   180}
    ,{   180,    70,   180,    50,   180}
    }
   ,{{   210,    40,   210,   210,   210}
    ,{   210,    40,   210,   210,   210}
    ,{   180,    10,   180,    50,   180}
    ,{   180,    10,    50,   180,    50}
    ,{   180,    10,   180,    50,   180}
    }
   ,{{   180,    70,   180,   180,   180}
    ,{   180,    10,   180,    50,   180}
    ,{   180,    70,   180,    50,   180}
    ,{   180,    10,   180,    50,   180}
    ,{   180,    10,   180,   180,   180}
    }
   }
  ,{{{   280,   220,   280,   220,   140}
    ,{   280,   220,   280,   220,   140}
    ,{   190,   190,   190,   190,   110}
    ,{   190,   190,   190,   190,   110}
    ,{   190,   190,   190,   190,   110}
    }
   ,{{   190,   190,   190,   190,   140}
    ,{   150,   150,   150,   150,   140}
    ,{   190,   190,   190,   190,   110}
    ,{   110,    50,   110,    50,   -20}
    ,{   190,   190,   190,   190,   110}
    }
   ,{{   190,   190,   190,   190,   110}
    ,{   190,   190,   190,   190,   110}
    ,{   190,   190,   190,   190,   110}
    ,{   190,   190,   190,   190,   110}
    ,{   190,   190,   190,   190,   110}
    }
   ,{{   280,   220,   280,   220,   140}
    ,{   280,   220,   280,   220,   140}
    ,{   190,   190,   190,   190,   110}
    ,{   110,    60,    60,    60,   110}
    ,{   190,   190,   190,   190,   110}
    }
   ,{{   190,   190,   190,   190,   110}
    ,{   190,   190,   190,   190,   110}
    ,{   190,   190,   190,   190,   110}
    ,{   190,   190,   190,   190,   110}
    ,{   190,   190,   190,   190,   110}
    }
   }
  }
 ,{{{{   210,   210,   190,   190,   200}
    ,{   210,   210,   190,   190,   200}
    ,{   190,   190,   170,   170,   170}
    ,{   200,   200,   170,   170,   180}
    ,{   190,   190,   170,   170,   170}
    }
   ,{{   210,   210,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    ,{   190,   190,   160,   160,   170}
    ,{   130,    90,   120,    60,   130}
    ,{   190,   190,   160,   160,   170}
    }
   ,{{   200,   200,   170,   170,   180}
    ,{   200,   200,   170,   170,   180}
    ,{   190,   190,   170,   170,   170}
    ,{   200,   200,   170,   170,   180}
    ,{   190,   190,   170,   170,   170}
    }
   ,{{   200,   190,   190,   160,   200}
    ,{   200,   160,   190,   130,   200}
    ,{   190,   190,   160,   160,   170}
    ,{   130,    40,    10,   130,    70}
    ,{   190,   190,   160,   160,   170}
    }
   ,{{   200,   200,   170,   170,   180}
    ,{   200,   200,   170,   170,   180}
    ,{   190,   190,   170,   170,   170}
    ,{   200,   200,   170,   170,   180}
    ,{   160,   160,    80,    80,    80}
    }
   }
  ,{{{   210,   210,   180,   110,   180}
    ,{   210,   210,   180,    70,   180}
    ,{   190,   190,   160,   110,   160}
    ,{   200,   200,   170,    60,   170}
    ,{   190,   190,   160,   110,   160}
    }
   ,{{   210,   210,   180,    70,   180}
    ,{   210,   210,   180,    70,   180}
    ,{   190,   190,   160,    50,   160}
    ,{    90,    90,    60,   -50,    60}
    ,{   190,   190,   160,    50,   160}
    }
   ,{{   200,   200,   170,   110,   170}
    ,{   200,   200,   170,    60,   170}
    ,{   190,   190,   160,   110,   160}
    ,{   200,   200,   170,    60,   170}
    ,{   190,   190,   160,   110,   160}
    }
   ,{{   190,   190,   160,    50,   160}
    ,{   160,   160,   130,    20,   130}
    ,{   190,   190,   160,    50,   160}
    ,{    40,    40,    10,    30,    10}
    ,{   190,   190,   160,    50,   160}
    }
   ,{{   200,   200,   170,   110,   170}
    ,{   200,   200,   170,    60,   170}
    ,{   190,   190,   160,   110,   160}
    ,{   200,   200,   170,    60,   170}
    ,{   160,   160,    70,   -30,    70}
    }
   }
  ,{{{   200,   190,   190,   190,   200}
    ,{   200,   190,   190,   190,   200}
    ,{   170,   170,   170,   170,   170}
    ,{   180,   170,   170,   170,   180}
    ,{   170,   170,   170,   170,   170}
    }
   ,{{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    ,{   170,   160,   160,   160,   170}
    ,{   130,    60,   120,    60,   130}
    ,{   170,   160,   160,   160,   170}
    }
   ,{{   180,   170,   170,   170,   180}
    ,{   180,   170,   170,   170,   180}
    ,{   170,   170,   170,   170,   170}
    ,{   180,   170,   170,   170,   180}
    ,{   170,   170,   170,   170,   170}
    }
   ,{{   200,   160,   190,   160,   200}
    ,{   200,   130,   190,   130,   200}
    ,{   170,   160,   160,   160,   170}
    ,{    20,    10,    10,    10,    20}
    ,{   170,   160,   160,   160,   170}
    }
   ,{{   180,   170,   170,   170,   180}
    ,{   180,   170,   170,   170,   180}
    ,{   170,   170,   170,   170,   170}
    ,{   180,   170,   170,   170,   180}
    ,{    80,    80,    80,    80,    80}
    }
   }
  ,{{{   180,    50,   180,   130,   180}
    ,{   180,    10,   180,   120,   180}
    ,{   160,    50,   160,    30,   160}
    ,{   170,     0,   170,   130,   170}
    ,{   160,    50,   160,    70,   160}
    }
   ,{{   180,    10,   180,    50,   180}
    ,{   180,    10,   180,    50,   180}
    ,{   160,   -10,   160,    20,   160}
    ,{    60,  -110,    60,    50,    60}
    ,{   160,   -10,   160,    20,   160}
    }
   ,{{   170,    50,   170,    30,   170}
    ,{   170,     0,   170,    30,   170}
    ,{   160,    50,   160,    30,   160}
    ,{   170,     0,   170,    30,   170}
    ,{   160,    50,   160,    30,   160}
    }
   ,{{   160,   -10,   160,   130,   160}
    ,{   130,   -40,   130,   120,   130}
    ,{   160,   -10,   160,    20,   160}
    ,{   130,   -30,    10,   130,    10}
    ,{   160,   -10,   160,    20,   160}
    }
   ,{{   170,    50,   170,    70,   170}
    ,{   170,     0,   170,    30,   170}
    ,{   160,    50,   160,    30,   160}
    ,{   170,     0,   170,    30,   170}
    ,{    70,  -100,    70,    70,    70}
    }
   }
  ,{{{   190,   190,   190,   190,   170}
    ,{   190,   190,   190,   190,   170}
    ,{   170,   170,   170,   170,    90}
    ,{   170,   170,   170,   170,   100}
    ,{   170,   170,   170,   170,    90}
    }
   ,{{   190,   190,   190,   190,   170}
    ,{   190,   190,   190,   190,   170}
    ,{   160,   160,   160,   160,    90}
    ,{   120,    60,   120,    60,   -10}
    ,{   160,   160,   160,   160,    90}
    }
   ,{{   170,   170,   170,   170,   100}
    ,{   170,   170,   170,   170,   100}
    ,{   170,   170,   170,   170,    90}
    ,{   170,   170,   170,   170,   100}
    ,{   170,   170,   170,   170,    90}
    }
   ,{{   190,   160,   190,   160,    90}
    ,{   190,   130,   190,   130,    60}
    ,{   160,   160,   160,   160,    90}
    ,{    70,    10,    10,    10,    70}
    ,{   160,   160,   160,   160,    90}
    }
   ,{{   170,   170,   170,   170,   100}
    ,{   170,   170,   170,   170,   100}
    ,{   170,   170,   170,   170,    90}
    ,{   170,   170,   170,   170,   100}
    ,{    80,    80,    80,    80,     0}
    }
   }
  }
 ,{{{{   210,   210,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    }
   ,{{   210,   210,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    ,{   170,   170,   140,   140,   150}
    ,{   150,   110,   140,    80,   150}
    ,{   170,   170,   140,   140,   150}
    }
   ,{{   210,   210,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    }
   ,{{   170,   170,   150,   150,   160}
    ,{   160,   120,   150,    90,   160}
    ,{   170,   170,   140,   140,   150}
    ,{   150,    60,    30,   150,    90}
    ,{   170,   170,   140,   140,   150}
    }
   ,{{   210,   210,   190,   190,   190}
    ,{   210,   210,   190,   190,   190}
    ,{   180,   180,   160,   160,   160}
    ,{   210,   210,   190,   190,   190}
    ,{   190,   190,   100,   100,   110}
    }
   }
  ,{{{   210,   210,   180,   130,   180}
    ,{   210,   210,   180,    70,   180}
    ,{   210,   210,   180,   130,   180}
    ,{   210,   210,   180,    70,   180}
    ,{   210,   210,   180,   130,   180}
    }
   ,{{   210,   210,   180,    70,   180}
    ,{   210,   210,   180,    70,   180}
    ,{   170,   170,   140,    30,   140}
    ,{   110,   110,    80,   -30,    80}
    ,{   170,   170,   140,    30,   140}
    }
   ,{{   210,   210,   180,   130,   180}
    ,{   210,   210,   180,    70,   180}
    ,{   210,   210,   180,   130,   180}
    ,{   210,   210,   180,    70,   180}
    ,{   210,   210,   180,   130,   180}
    }
   ,{{   170,   170,   140,    50,   140}
    ,{   120,   120,    90,   -20,    90}
    ,{   170,   170,   140,    30,   140}
    ,{    60,    60,    30,    50,    30}
    ,{   170,   170,   140,    30,   140}
    }
   ,{{   210,   210,   180,   100,   180}
    ,{   210,   210,   180,    70,   180}
    ,{   180,   180,   150,   100,   150}
    ,{   210,   210,   180,    70,   180}
    ,{   190,   190,   100,   -10,   100}
    }
   }
  ,{{{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    }
   ,{{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    ,{   150,   140,   140,   140,   150}
    ,{   150,    80,   140,    80,   150}
    ,{   150,   140,   140,   140,   150}
    }
   ,{{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    }
   ,{{   160,   140,   150,   140,   160}
    ,{   160,    90,   150,    90,   160}
    ,{   150,   140,   140,   140,   150}
    ,{    40,    30,    30,    30,    40}
    ,{   150,   140,   140,   140,   150}
    }
   ,{{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    ,{   160,   160,   160,   160,   160}
    ,{   190,   190,   190,   190,   190}
    ,{   110,   100,   100,   100,   110}
    }
   }
  ,{{{   180,    70,   180,   150,   180}
    ,{   180,    10,   180,    80,   180}
    ,{   180,    70,   180,    50,   180}
    ,{   180,    10,   180,   150,   180}
    ,{   180,    70,   180,    90,   180}
    }
   ,{{   180,    10,   180,    70,   180}
    ,{   180,    10,   180,    50,   180}
    ,{   140,   -30,   140,     0,   140}
    ,{    80,   -90,    80,    70,    80}
    ,{   140,   -30,   140,     0,   140}
    }
   ,{{   180,    70,   180,    50,   180}
    ,{   180,    10,   180,    50,   180}
    ,{   180,    70,   180,    50,   180}
    ,{   180,    10,   180,    50,   180}
    ,{   180,    70,   180,    50,   180}
    }
   ,{{   150,   -10,   140,   150,   140}
    ,{    90,   -80,    90,    80,    90}
    ,{   140,   -30,   140,     0,   140}
    ,{   150,   -10,    30,   150,    30}
    ,{   140,   -30,   140,     0,   140}
    }
   ,{{   180,    40,   180,    90,   180}
    ,{   180,    10,   180,    50,   180}
    ,{   150,    40,   150,    20,   150}
    ,{   180,    10,   180,    50,   180}
    ,{   100,   -70,   100,    90,   100}
    }
   }
  ,{{{   190,   190,   190,   190,   170}
    ,{   190,   190,   190,   190,   170}
    ,{   190,   190,   190,   190,   110}
    ,{   190,   190,   190,   190,   110}
    ,{   190,   190,   190,   190,   110}
    }
   ,{{   190,   190,   190,   190,   170}
    ,{   190,   190,   190,   190,   170}
    ,{   140,   140,   140,   140,    70}
    ,{   140,    80,   140,    80,    10}
    ,{   140,   140,   140,   140,    70}
    }
   ,{{   190,   190,   190,   190,   110}
    ,{   190,   190,   190,   190,   110}
    ,{   190,   190,   190,   190,   110}
    ,{   190,   190,   190,   190,   110}
    ,{   190,   190,   190,   190,   110}
    }
   ,{{   150,   140,   150,   140,    90}
    ,{   150,    90,   150,    90,    20}
    ,{   140,   140,   140,   140,    70}
    ,{    90,    30,    30,    30,    90}
    ,{   140,   140,   140,   140,    70}
    }
   ,{{   190,   190,   190,   190,   110}
    ,{   190,   190,   190,   190,   110}
    ,{   160,   160,   160,   160,    80}
    ,{   190,   190,   190,   190,   110}
    ,{   100,   100,   100,   100,    30}
    }
   }
  }
 ,{{{{   300,   300,   280,   250,   280}
    ,{   280,   280,   280,   250,   280}
    ,{   240,   240,   220,   220,   220}
    ,{   240,   240,   220,   220,   220}
    ,{   300,   300,   220,   220,   220}
    }
   ,{{   280,   280,   250,   250,   260}
    ,{   280,   280,   250,   250,   260}
    ,{   240,   240,   220,   220,   220}
    ,{   200,   160,   200,   140,   200}
    ,{   240,   240,   220,   220,   220}
    }
   ,{{   240,   240,   220,   220,   220}
    ,{   240,   240,   220,   220,   220}
    ,{   240,   240,   220,   220,   220}
    ,{   240,   240,   220,   220,   220}
    ,{   240,   240,   220,   220,   220}
    }
   ,{{   280,   240,   280,   220,   280}
    ,{   280,   240,   280,   220,   280}
    ,{   240,   240,   220,   220,   220}
    ,{   210,   110,    90,   210,   140}
    ,{   240,   240,   220,   220,   220}
    }
   ,{{   300,   300,   220,   220,   220}
    ,{   240,   240,   220,   220,   220}
    ,{   240,   240,   220,   220,   220}
    ,{   240,   240,   220,   220,   220}
    ,{   300,   300,   220,   220,   220}
    }
   }
  ,{{{   300,   300,   250,   160,   250}
    ,{   280,   280,   250,   140,   250}
    ,{   240,   240,   210,   160,   210}
    ,{   240,   240,   210,   100,   210}
    ,{   300,   300,   210,   160,   210}
    }
   ,{{   280,   280,   250,   140,   250}
    ,{   280,   280,   250,   140,   250}
    ,{   240,   240,   210,   100,   210}
    ,{   160,   160,   130,    20,   130}
    ,{   240,   240,   210,   100,   210}
    }
   ,{{   240,   240,   210,   160,   210}
    ,{   240,   240,   210,   100,   210}
    ,{   240,   240,   210,   160,   210}
    ,{   240,   240,   210,   100,   210}
    ,{   240,   240,   210,   160,   210}
    }
   ,{{   240,   240,   210,   100,   210}
    ,{   240,   240,   210,   100,   210}
    ,{   240,   240,   210,   100,   210}
    ,{   110,   110,    80,   100,    80}
    ,{   240,   240,   210,   100,   210}
    }
   ,{{   300,   300,   210,   160,   210}
    ,{   240,   240,   210,   100,   210}
    ,{   240,   240,   210,   160,   210}
    ,{   240,   240,   210,   100,   210}
    ,{   300,   300,   210,   140,   210}
    }
   }
  ,{{{   280,   250,   280,   250,   280}
    ,{   280,   250,   280,   250,   280}
    ,{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   260,   250,   250,   250,   260}
    ,{   260,   250,   250,   250,   260}
    ,{   220,   220,   220,   220,   220}
    ,{   200,   140,   200,   140,   200}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   280,   220,   280,   220,   280}
    ,{   280,   220,   280,   220,   280}
    ,{   220,   220,   220,   220,   220}
    ,{    90,    90,    90,    90,    90}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    ,{   220,   220,   220,   220,   220}
    }
   }
  ,{{{   250,   100,   250,   210,   250}
    ,{   250,    70,   250,   210,   250}
    ,{   210,   100,   210,    80,   210}
    ,{   210,    40,   210,   210,   210}
    ,{   210,   100,   210,   210,   210}
    }
   ,{{   250,    70,   250,   130,   250}
    ,{   250,    70,   250,   110,   250}
    ,{   210,    40,   210,    80,   210}
    ,{   130,   -40,   130,   130,   130}
    ,{   210,    40,   210,    80,   210}
    }
   ,{{   210,   100,   210,    80,   210}
    ,{   210,    40,   210,    80,   210}
    ,{   210,   100,   210,    80,   210}
    ,{   210,    40,   210,    80,   210}
    ,{   210,   100,   210,    80,   210}
    }
   ,{{   210,    40,   210,   210,   210}
    ,{   210,    40,   210,   210,   210}
    ,{   210,    40,   210,    80,   210}
    ,{   210,    40,    80,   210,    80}
    ,{   210,    40,   210,    80,   210}
    }
   ,{{   210,   100,   210,   210,   210}
    ,{   210,    40,   210,    80,   210}
    ,{   210,   100,   210,    80,   210}
    ,{   210,    40,   210,    80,   210}
    ,{   210,    50,   210,   210,   210}
    }
   }
  ,{{{   280,   250,   280,   250,   240}
    ,{   280,   250,   280,   250,   240}
    ,{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    }
   ,{{   250,   250,   250,   250,   240}
    ,{   250,   250,   250,   250,   240}
    ,{   220,   220,   220,   220,   140}
    ,{   200,   140,   200,   140,    90}
    ,{   220,   220,   220,   220,   140}
    }
   ,{{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    }
   ,{{   280,   220,   280,   220,   140}
    ,{   280,   220,   280,   220,   140}
    ,{   220,   220,   220,   220,   140}
    ,{   140,    90,    90,    90,   140}
    ,{   220,   220,   220,   220,   140}
    }
   ,{{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    ,{   220,   220,   220,   220,   140}
    }
   }
  }
 }
,{{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   300,   300,   270,   270,   290}
    ,{   300,   300,   270,   270,   290}
    ,{   290,   290,   250,   270,   250}
    ,{   300,   300,   270,   270,   270}
    ,{   270,   270,   240,   260,   240}
    }
   ,{{   290,   270,   230,   230,   290}
    ,{   290,   270,   230,   230,   290}
    ,{   260,   260,   220,   220,   220}
    ,{   190,   170,   190,   130,   190}
    ,{   260,   260,   220,   220,   220}
    }
   ,{{   300,   300,   270,   270,   270}
    ,{   300,   300,   270,   270,   270}
    ,{   290,   290,   250,   270,   250}
    ,{   300,   300,   270,   270,   270}
    ,{   270,   270,   240,   260,   240}
    }
   ,{{   260,   260,   220,   220,   220}
    ,{   190,   170,   190,   130,   190}
    ,{   260,   260,   220,   220,   220}
    ,{   210,   130,    80,   210,   210}
    ,{   260,   260,   220,   220,   220}
    }
   ,{{   300,   300,   270,   270,   270}
    ,{   300,   300,   270,   270,   270}
    ,{   270,   270,   240,   260,   240}
    ,{   300,   300,   270,   270,   270}
    ,{   240,   240,   150,   150,   150}
    }
   }
  ,{{{   300,   300,   270,   270,   270}
    ,{   300,   300,   270,   230,   270}
    ,{   290,   290,   250,   270,   250}
    ,{   300,   300,   270,   230,   270}
    ,{   270,   270,   240,   260,   240}
    }
   ,{{   270,   270,   230,   190,   230}
    ,{   270,   270,   230,   190,   230}
    ,{   260,   260,   220,   180,   220}
    ,{   170,   170,   130,    90,   130}
    ,{   260,   260,   220,   180,   220}
    }
   ,{{   300,   300,   270,   270,   270}
    ,{   300,   300,   270,   230,   270}
    ,{   290,   290,   250,   270,   250}
    ,{   300,   300,   270,   230,   270}
    ,{   270,   270,   240,   260,   240}
    }
   ,{{   260,   260,   220,   180,   220}
    ,{   170,   170,   130,    90,   130}
    ,{   260,   260,   220,   180,   220}
    ,{   170,   110,    80,   170,    80}
    ,{   260,   260,   220,   180,   220}
    }
   ,{{   300,   300,   270,   260,   270}
    ,{   300,   300,   270,   230,   270}
    ,{   270,   270,   240,   260,   240}
    ,{   300,   300,   270,   230,   270}
    ,{   240,   240,   150,   110,   150}
    }
   }
  ,{{{   270,   270,   270,   270,   270}
    ,{   270,   270,   270,   270,   270}
    ,{   250,   250,   250,   250,   250}
    ,{   270,   270,   270,   270,   270}
    ,{   240,   240,   240,   240,   240}
    }
   ,{{   230,   230,   230,   230,   230}
    ,{   230,   230,   230,   230,   230}
    ,{   220,   220,   220,   220,   220}
    ,{   190,   130,   190,   130,   190}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   270,   270,   270,   270,   270}
    ,{   270,   270,   270,   270,   270}
    ,{   250,   250,   250,   250,   250}
    ,{   270,   270,   270,   270,   270}
    ,{   240,   240,   240,   240,   240}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   190,   130,   190,   130,   190}
    ,{   220,   220,   220,   220,   220}
    ,{    80,    80,    80,    80,    80}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   270,   270,   270,   270,   270}
    ,{   270,   270,   270,   270,   270}
    ,{   240,   240,   240,   240,   240}
    ,{   270,   270,   270,   270,   270}
    ,{   150,   150,   150,   150,   150}
    }
   }
  ,{{{   270,   230,   270,   210,   270}
    ,{   270,   190,   270,   140,   270}
    ,{   250,   230,   250,   120,   250}
    ,{   270,   190,   270,   210,   270}
    ,{   240,   220,   240,   150,   240}
    }
   ,{{   230,   150,   230,   130,   230}
    ,{   230,   150,   230,   100,   230}
    ,{   220,   140,   220,    90,   220}
    ,{   130,    50,   130,   130,   130}
    ,{   220,   140,   220,    90,   220}
    }
   ,{{   270,   230,   270,   140,   270}
    ,{   270,   190,   270,   140,   270}
    ,{   250,   230,   250,   120,   250}
    ,{   270,   190,   270,   140,   270}
    ,{   240,   220,   240,   110,   240}
    }
   ,{{   220,   140,   220,   210,   220}
    ,{   130,    50,   130,   130,   130}
    ,{   220,   140,   220,    90,   220}
    ,{   210,   130,    80,   210,    80}
    ,{   220,   140,   220,    90,   220}
    }
   ,{{   270,   220,   270,   150,   270}
    ,{   270,   190,   270,   140,   270}
    ,{   240,   220,   240,   110,   240}
    ,{   270,   190,   270,   140,   270}
    ,{   150,    70,   150,   150,   150}
    }
   }
  ,{{{   290,   270,   270,   270,   290}
    ,{   290,   270,   270,   270,   290}
    ,{   250,   250,   250,   250,   250}
    ,{   270,   270,   270,   270,   270}
    ,{   240,   240,   240,   240,   240}
    }
   ,{{   290,   230,   230,   230,   290}
    ,{   290,   230,   230,   230,   290}
    ,{   220,   220,   220,   220,   220}
    ,{   190,   130,   190,   130,   130}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   270,   270,   270,   270,   270}
    ,{   270,   270,   270,   270,   270}
    ,{   250,   250,   250,   250,   250}
    ,{   270,   270,   270,   270,   270}
    ,{   240,   240,   240,   240,   240}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   190,   130,   190,   130,   130}
    ,{   220,   220,   220,   220,   220}
    ,{   210,    80,    80,    80,   210}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   270,   270,   270,   270,   270}
    ,{   270,   270,   270,   270,   270}
    ,{   240,   240,   240,   240,   240}
    ,{   270,   270,   270,   270,   270}
    ,{   150,   150,   150,   150,   150}
    }
   }
  }
 ,{{{{   300,   280,   240,   240,   300}
    ,{   300,   280,   240,   240,   300}
    ,{   260,   260,   220,   240,   220}
    ,{   250,   250,   210,   210,   210}
    ,{   250,   250,   220,   240,   220}
    }
   ,{{   300,   280,   240,   240,   300}
    ,{   300,   280,   240,   240,   300}
    ,{   250,   250,   220,   220,   220}
    ,{   100,    70,   100,    40,   100}
    ,{   250,   250,   220,   220,   220}
    }
   ,{{   250,   250,   220,   240,   220}
    ,{   250,   250,   210,   210,   210}
    ,{   250,   250,   220,   240,   220}
    ,{   250,   250,   210,   210,   210}
    ,{   250,   250,   220,   240,   220}
    }
   ,{{   250,   250,   220,   220,   220}
    ,{   160,   140,   160,   100,   160}
    ,{   250,   250,   220,   220,   220}
    ,{   210,   130,    80,   210,   210}
    ,{   250,   250,   220,   220,   220}
    }
   ,{{   260,   260,   220,   240,   220}
    ,{   250,   250,   210,   210,   210}
    ,{   260,   260,   220,   240,   220}
    ,{   250,   250,   210,   210,   210}
    ,{   240,   240,   140,   140,   140}
    }
   }
  ,{{{   280,   280,   240,   240,   240}
    ,{   280,   280,   240,   200,   240}
    ,{   260,   260,   220,   240,   220}
    ,{   250,   250,   210,   170,   210}
    ,{   250,   250,   220,   240,   220}
    }
   ,{{   280,   280,   240,   200,   240}
    ,{   280,   280,   240,   200,   240}
    ,{   250,   250,   220,   180,   220}
    ,{    70,    70,    40,     0,    40}
    ,{   250,   250,   220,   180,   220}
    }
   ,{{   250,   250,   220,   240,   220}
    ,{   250,   250,   210,   170,   210}
    ,{   250,   250,   220,   240,   220}
    ,{   250,   250,   210,   170,   210}
    ,{   250,   250,   220,   240,   220}
    }
   ,{{   250,   250,   220,   180,   220}
    ,{   140,   140,   100,    60,   100}
    ,{   250,   250,   220,   180,   220}
    ,{   170,   110,    80,   170,    80}
    ,{   250,   250,   220,   180,   220}
    }
   ,{{   260,   260,   220,   240,   220}
    ,{   250,   250,   210,   170,   210}
    ,{   260,   260,   220,   240,   220}
    ,{   250,   250,   210,   170,   210}
    ,{   240,   240,   140,   100,   140}
    }
   }
  ,{{{   240,   240,   240,   240,   240}
    ,{   240,   240,   240,   240,   240}
    ,{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   240,   240,   240,   240,   240}
    ,{   240,   240,   240,   240,   240}
    ,{   220,   220,   220,   220,   220}
    ,{   100,    40,   100,    40,   100}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   160,   100,   160,   100,   160}
    ,{   220,   220,   220,   220,   220}
    ,{    80,    80,    80,    80,    80}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   140,   140,   140,   140,   140}
    }
   }
  ,{{{   240,   200,   240,   210,   240}
    ,{   240,   160,   240,   110,   240}
    ,{   220,   200,   220,    90,   220}
    ,{   210,   130,   210,   210,   210}
    ,{   220,   200,   220,   140,   220}
    }
   ,{{   240,   160,   240,   110,   240}
    ,{   240,   160,   240,   110,   240}
    ,{   220,   140,   220,    90,   220}
    ,{    40,   -40,    40,    40,    40}
    ,{   220,   140,   220,    90,   220}
    }
   ,{{   220,   200,   220,    90,   220}
    ,{   210,   130,   210,    80,   210}
    ,{   220,   200,   220,    90,   220}
    ,{   210,   130,   210,    80,   210}
    ,{   220,   200,   220,    90,   220}
    }
   ,{{   220,   140,   220,   210,   220}
    ,{   100,    20,   100,   100,   100}
    ,{   220,   140,   220,    90,   220}
    ,{   210,   130,    80,   210,    80}
    ,{   220,   140,   220,    90,   220}
    }
   ,{{   220,   200,   220,   140,   220}
    ,{   210,   130,   210,    80,   210}
    ,{   220,   200,   220,    90,   220}
    ,{   210,   130,   210,    80,   210}
    ,{   140,    60,   140,   140,   140}
    }
   }
  ,{{{   300,   240,   240,   240,   300}
    ,{   300,   240,   240,   240,   300}
    ,{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   300,   240,   240,   240,   300}
    ,{   300,   240,   240,   240,   300}
    ,{   220,   220,   220,   220,   220}
    ,{   100,    40,   100,    40,    40}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   160,   100,   160,   100,   100}
    ,{   220,   220,   220,   220,   220}
    ,{   210,    80,    80,    80,   210}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   140,   140,   140,   140,   140}
    }
   }
  }
 ,{{{{   430,   430,   370,   370,   430}
    ,{   430,   410,   370,   370,   430}
    ,{   370,   370,   340,   360,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   430,   430,   340,   360,   340}
    }
   ,{{   430,   410,   370,   370,   430}
    ,{   430,   410,   370,   370,   430}
    ,{   370,   370,   340,   340,   340}
    ,{   320,   290,   320,   260,   320}
    ,{   370,   370,   340,   340,   340}
    }
   ,{{   370,   370,   340,   360,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   370,   370,   340,   360,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   370,   370,   340,   360,   340}
    }
   ,{{   370,   370,   360,   340,   360}
    ,{   360,   330,   360,   300,   360}
    ,{   370,   370,   340,   340,   340}
    ,{   340,   260,   210,   340,   340}
    ,{   370,   370,   340,   340,   340}
    }
   ,{{   430,   430,   340,   360,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   370,   370,   340,   360,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   430,   430,   340,   340,   340}
    }
   }
  ,{{{   430,   430,   370,   360,   370}
    ,{   410,   410,   370,   330,   370}
    ,{   370,   370,   340,   360,   340}
    ,{   370,   370,   340,   300,   340}
    ,{   430,   430,   340,   360,   340}
    }
   ,{{   410,   410,   370,   330,   370}
    ,{   410,   410,   370,   330,   370}
    ,{   370,   370,   340,   300,   340}
    ,{   290,   290,   260,   220,   260}
    ,{   370,   370,   340,   300,   340}
    }
   ,{{   370,   370,   340,   360,   340}
    ,{   370,   370,   340,   300,   340}
    ,{   370,   370,   340,   360,   340}
    ,{   370,   370,   340,   300,   340}
    ,{   370,   370,   340,   360,   340}
    }
   ,{{   370,   370,   340,   300,   340}
    ,{   330,   330,   300,   260,   300}
    ,{   370,   370,   340,   300,   340}
    ,{   300,   240,   210,   300,   210}
    ,{   370,   370,   340,   300,   340}
    }
   ,{{   430,   430,   340,   360,   340}
    ,{   370,   370,   340,   300,   340}
    ,{   370,   370,   340,   360,   340}
    ,{   370,   370,   340,   300,   340}
    ,{   430,   430,   340,   300,   340}
    }
   }
  ,{{{   370,   370,   370,   370,   370}
    ,{   370,   370,   370,   370,   370}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   370,   370,   370,   370,   370}
    ,{   370,   370,   370,   370,   370}
    ,{   340,   340,   340,   340,   340}
    ,{   320,   260,   320,   260,   320}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   360,   340,   360,   340,   360}
    ,{   360,   300,   360,   300,   360}
    ,{   340,   340,   340,   340,   340}
    ,{   210,   210,   210,   210,   210}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   }
  ,{{{   370,   320,   370,   340,   370}
    ,{   370,   290,   370,   300,   370}
    ,{   340,   320,   340,   210,   340}
    ,{   340,   260,   340,   340,   340}
    ,{   340,   320,   340,   340,   340}
    }
   ,{{   370,   290,   370,   260,   370}
    ,{   370,   290,   370,   240,   370}
    ,{   340,   260,   340,   210,   340}
    ,{   260,   180,   260,   260,   260}
    ,{   340,   260,   340,   210,   340}
    }
   ,{{   340,   320,   340,   210,   340}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   320,   340,   210,   340}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   320,   340,   210,   340}
    }
   ,{{   340,   260,   340,   340,   340}
    ,{   300,   220,   300,   300,   300}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   260,   210,   340,   210}
    ,{   340,   260,   340,   210,   340}
    }
   ,{{   340,   320,   340,   340,   340}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   320,   340,   210,   340}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   260,   340,   340,   340}
    }
   }
  ,{{{   430,   370,   370,   370,   430}
    ,{   430,   370,   370,   370,   430}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   430,   370,   370,   370,   430}
    ,{   430,   370,   370,   370,   430}
    ,{   340,   340,   340,   340,   340}
    ,{   320,   260,   320,   260,   260}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   360,   340,   360,   340,   340}
    ,{   360,   300,   360,   300,   300}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   210,   210,   210,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   }
  }
 ,{{{{   400,   400,   400,   360,   400}
    ,{   400,   370,   400,   360,   400}
    ,{   340,   340,   310,   330,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   400,   400,   310,   330,   310}
    }
   ,{{   360,   360,   310,   360,   330}
    ,{   360,   360,   270,   360,   330}
    ,{   340,   340,   310,   310,   310}
    ,{   230,   220,   230,   170,   230}
    ,{   340,   340,   310,   310,   310}
    }
   ,{{   340,   340,   310,   330,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   340,   340,   310,   330,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   340,   340,   310,   330,   310}
    }
   ,{{   400,   370,   400,   340,   400}
    ,{   400,   370,   400,   340,   400}
    ,{   340,   340,   310,   310,   310}
    ,{   310,   230,   180,   310,   310}
    ,{   340,   340,   310,   310,   310}
    }
   ,{{   400,   400,   310,   330,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   340,   340,   310,   330,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   400,   400,   310,   310,   310}
    }
   }
  ,{{{   400,   400,   340,   360,   340}
    ,{   370,   370,   340,   360,   340}
    ,{   340,   340,   310,   330,   310}
    ,{   340,   340,   310,   270,   310}
    ,{   400,   400,   310,   330,   310}
    }
   ,{{   360,   360,   310,   360,   310}
    ,{   360,   360,   270,   360,   270}
    ,{   340,   340,   310,   270,   310}
    ,{   220,   220,   170,   130,   170}
    ,{   340,   340,   310,   270,   310}
    }
   ,{{   340,   340,   310,   330,   310}
    ,{   340,   340,   310,   270,   310}
    ,{   340,   340,   310,   330,   310}
    ,{   340,   340,   310,   270,   310}
    ,{   340,   340,   310,   330,   310}
    }
   ,{{   370,   370,   340,   300,   340}
    ,{   370,   370,   340,   300,   340}
    ,{   340,   340,   310,   270,   310}
    ,{   270,   210,   180,   270,   180}
    ,{   340,   340,   310,   270,   310}
    }
   ,{{   400,   400,   310,   330,   310}
    ,{   340,   340,   310,   270,   310}
    ,{   340,   340,   310,   330,   310}
    ,{   340,   340,   310,   270,   310}
    ,{   400,   400,   310,   270,   310}
    }
   }
  ,{{{   400,   340,   400,   340,   400}
    ,{   400,   340,   400,   340,   400}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   270,   270,   270,   270,   270}
    ,{   310,   310,   310,   310,   310}
    ,{   230,   170,   230,   170,   230}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   400,   340,   400,   340,   400}
    ,{   400,   340,   400,   340,   400}
    ,{   310,   310,   310,   310,   310}
    ,{   180,   180,   180,   180,   180}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   }
  ,{{{   340,   290,   340,   340,   340}
    ,{   340,   260,   340,   340,   340}
    ,{   310,   290,   310,   180,   310}
    ,{   310,   230,   310,   310,   310}
    ,{   310,   290,   310,   310,   310}
    }
   ,{{   310,   230,   310,   180,   310}
    ,{   270,   190,   270,   140,   270}
    ,{   310,   230,   310,   180,   310}
    ,{   170,    20,   170,   170,   170}
    ,{   310,   230,   310,   180,   310}
    }
   ,{{   310,   290,   310,   180,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   290,   310,   180,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   290,   310,   180,   310}
    }
   ,{{   340,   260,   340,   340,   340}
    ,{   340,   260,   340,   340,   340}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   230,   180,   310,   180}
    ,{   310,   230,   310,   180,   310}
    }
   ,{{   310,   290,   310,   310,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   290,   310,   180,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   230,   310,   310,   310}
    }
   }
  ,{{{   400,   340,   400,   340,   340}
    ,{   400,   340,   400,   340,   340}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   330,   310,   310,   310,   330}
    ,{   330,   270,   270,   270,   330}
    ,{   310,   310,   310,   310,   310}
    ,{   230,   170,   230,   170,   170}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   400,   340,   400,   340,   340}
    ,{   400,   340,   400,   340,   340}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   180,   180,   180,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   }
  }
 ,{{{{   370,   340,   310,   310,   370}
    ,{   370,   340,   310,   310,   370}
    ,{   320,   320,   290,   310,   290}
    ,{   330,   330,   290,   290,   290}
    ,{   320,   320,   290,   310,   290}
    }
   ,{{   370,   340,   310,   310,   370}
    ,{   370,   340,   310,   310,   370}
    ,{   320,   320,   280,   280,   280}
    ,{   240,   220,   240,   180,   240}
    ,{   320,   320,   280,   280,   280}
    }
   ,{{   330,   330,   290,   310,   290}
    ,{   330,   330,   290,   290,   290}
    ,{   320,   320,   290,   310,   290}
    ,{   330,   330,   290,   290,   290}
    ,{   320,   320,   290,   310,   290}
    }
   ,{{   320,   320,   310,   280,   310}
    ,{   310,   290,   310,   250,   310}
    ,{   320,   320,   280,   280,   280}
    ,{   260,   180,   130,   260,   260}
    ,{   320,   320,   280,   280,   280}
    }
   ,{{   330,   330,   290,   310,   290}
    ,{   330,   330,   290,   290,   290}
    ,{   320,   320,   290,   310,   290}
    ,{   330,   330,   290,   290,   290}
    ,{   290,   290,   200,   200,   200}
    }
   }
  ,{{{   340,   340,   310,   310,   310}
    ,{   340,   340,   310,   270,   310}
    ,{   320,   320,   290,   310,   290}
    ,{   330,   330,   290,   250,   290}
    ,{   320,   320,   290,   310,   290}
    }
   ,{{   340,   340,   310,   270,   310}
    ,{   340,   340,   310,   270,   310}
    ,{   320,   320,   280,   240,   280}
    ,{   220,   220,   180,   140,   180}
    ,{   320,   320,   280,   240,   280}
    }
   ,{{   330,   330,   290,   310,   290}
    ,{   330,   330,   290,   250,   290}
    ,{   320,   320,   290,   310,   290}
    ,{   330,   330,   290,   250,   290}
    ,{   320,   320,   290,   310,   290}
    }
   ,{{   320,   320,   280,   240,   280}
    ,{   290,   290,   250,   210,   250}
    ,{   320,   320,   280,   240,   280}
    ,{   220,   170,   130,   220,   130}
    ,{   320,   320,   280,   240,   280}
    }
   ,{{   330,   330,   290,   310,   290}
    ,{   330,   330,   290,   250,   290}
    ,{   320,   320,   290,   310,   290}
    ,{   330,   330,   290,   250,   290}
    ,{   290,   290,   200,   160,   200}
    }
   }
  ,{{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   280,   280,   280,   280,   280}
    ,{   240,   180,   240,   180,   240}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    }
   ,{{   310,   280,   310,   280,   310}
    ,{   310,   250,   310,   250,   310}
    ,{   280,   280,   280,   280,   280}
    ,{   130,   130,   130,   130,   130}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   200,   200,   200,   200,   200}
    }
   }
  ,{{{   310,   270,   310,   260,   310}
    ,{   310,   230,   310,   250,   310}
    ,{   290,   270,   290,   160,   290}
    ,{   290,   210,   290,   260,   290}
    ,{   290,   270,   290,   200,   290}
    }
   ,{{   310,   230,   310,   180,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   280,   200,   280,   150,   280}
    ,{   180,   100,   180,   180,   180}
    ,{   280,   200,   280,   150,   280}
    }
   ,{{   290,   270,   290,   160,   290}
    ,{   290,   210,   290,   160,   290}
    ,{   290,   270,   290,   160,   290}
    ,{   290,   210,   290,   160,   290}
    ,{   290,   270,   290,   160,   290}
    }
   ,{{   280,   200,   280,   260,   280}
    ,{   250,   170,   250,   250,   250}
    ,{   280,   200,   280,   150,   280}
    ,{   260,   180,   130,   260,   130}
    ,{   280,   200,   280,   150,   280}
    }
   ,{{   290,   270,   290,   200,   290}
    ,{   290,   210,   290,   160,   290}
    ,{   290,   270,   290,   160,   290}
    ,{   290,   210,   290,   160,   290}
    ,{   200,   120,   200,   200,   200}
    }
   }
  ,{{{   370,   310,   310,   310,   370}
    ,{   370,   310,   310,   310,   370}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    }
   ,{{   370,   310,   310,   310,   370}
    ,{   370,   310,   310,   310,   370}
    ,{   280,   280,   280,   280,   280}
    ,{   240,   180,   240,   180,   180}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    }
   ,{{   310,   280,   310,   280,   280}
    ,{   310,   250,   310,   250,   250}
    ,{   280,   280,   280,   280,   280}
    ,{   260,   130,   130,   130,   260}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   200,   200,   200,   200,   200}
    }
   }
  }
 ,{{{{   370,   340,   310,   330,   370}
    ,{   370,   340,   310,   310,   370}
    ,{   340,   340,   310,   330,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   340,   340,   310,   330,   310}
    }
   ,{{   370,   340,   310,   310,   370}
    ,{   370,   340,   310,   310,   370}
    ,{   300,   300,   260,   260,   260}
    ,{   260,   240,   260,   200,   260}
    ,{   300,   300,   260,   260,   260}
    }
   ,{{   340,   340,   310,   330,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   340,   340,   310,   330,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   340,   340,   310,   330,   310}
    }
   ,{{   300,   300,   270,   280,   280}
    ,{   270,   250,   270,   210,   270}
    ,{   300,   300,   260,   260,   260}
    ,{   280,   200,   150,   280,   280}
    ,{   300,   300,   260,   260,   260}
    }
   ,{{   340,   340,   310,   310,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   310,   310,   280,   300,   280}
    ,{   340,   340,   310,   310,   310}
    ,{   320,   320,   220,   220,   220}
    }
   }
  ,{{{   340,   340,   310,   330,   310}
    ,{   340,   340,   310,   270,   310}
    ,{   340,   340,   310,   330,   310}
    ,{   340,   340,   310,   270,   310}
    ,{   340,   340,   310,   330,   310}
    }
   ,{{   340,   340,   310,   270,   310}
    ,{   340,   340,   310,   270,   310}
    ,{   300,   300,   260,   220,   260}
    ,{   240,   240,   200,   160,   200}
    ,{   300,   300,   260,   220,   260}
    }
   ,{{   340,   340,   310,   330,   310}
    ,{   340,   340,   310,   270,   310}
    ,{   340,   340,   310,   330,   310}
    ,{   340,   340,   310,   270,   310}
    ,{   340,   340,   310,   330,   310}
    }
   ,{{   300,   300,   260,   240,   260}
    ,{   250,   250,   210,   170,   210}
    ,{   300,   300,   260,   220,   260}
    ,{   240,   190,   150,   240,   150}
    ,{   300,   300,   260,   220,   260}
    }
   ,{{   340,   340,   310,   300,   310}
    ,{   340,   340,   310,   270,   310}
    ,{   310,   310,   280,   300,   280}
    ,{   340,   340,   310,   270,   310}
    ,{   320,   320,   220,   180,   220}
    }
   }
  ,{{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   260,   260,   260,   260,   260}
    ,{   260,   200,   260,   200,   260}
    ,{   260,   260,   260,   260,   260}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   270,   260,   270,   260,   270}
    ,{   270,   210,   270,   210,   270}
    ,{   260,   260,   260,   260,   260}
    ,{   150,   150,   150,   150,   150}
    ,{   260,   260,   260,   260,   260}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   280,   280,   280,   280,   280}
    ,{   310,   310,   310,   310,   310}
    ,{   220,   220,   220,   220,   220}
    }
   }
  ,{{{   310,   290,   310,   280,   310}
    ,{   310,   230,   310,   210,   310}
    ,{   310,   290,   310,   180,   310}
    ,{   310,   230,   310,   280,   310}
    ,{   310,   290,   310,   220,   310}
    }
   ,{{   310,   230,   310,   200,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   260,   180,   260,   130,   260}
    ,{   200,   120,   200,   200,   200}
    ,{   260,   180,   260,   130,   260}
    }
   ,{{   310,   290,   310,   180,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   290,   310,   180,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   290,   310,   180,   310}
    }
   ,{{   280,   200,   260,   280,   260}
    ,{   210,   130,   210,   210,   210}
    ,{   260,   180,   260,   130,   260}
    ,{   280,   200,   150,   280,   150}
    ,{   260,   180,   260,   130,   260}
    }
   ,{{   310,   260,   310,   220,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   280,   260,   280,   150,   280}
    ,{   310,   230,   310,   180,   310}
    ,{   220,   140,   220,   220,   220}
    }
   }
  ,{{{   370,   310,   310,   310,   370}
    ,{   370,   310,   310,   310,   370}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   370,   310,   310,   310,   370}
    ,{   370,   310,   310,   310,   370}
    ,{   260,   260,   260,   260,   260}
    ,{   260,   200,   260,   200,   200}
    ,{   260,   260,   260,   260,   260}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   280,   260,   270,   260,   280}
    ,{   270,   210,   270,   210,   210}
    ,{   260,   260,   260,   260,   260}
    ,{   280,   150,   150,   150,   280}
    ,{   260,   260,   260,   260,   260}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   280,   280,   280,   280,   280}
    ,{   310,   310,   310,   310,   310}
    ,{   220,   220,   220,   220,   220}
    }
   }
  }
 ,{{{{   430,   430,   400,   370,   430}
    ,{   430,   410,   400,   370,   430}
    ,{   370,   370,   340,   360,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   430,   430,   340,   360,   340}
    }
   ,{{   430,   410,   370,   370,   430}
    ,{   430,   410,   370,   370,   430}
    ,{   370,   370,   340,   340,   340}
    ,{   320,   290,   320,   260,   320}
    ,{   370,   370,   340,   340,   340}
    }
   ,{{   370,   370,   340,   360,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   370,   370,   340,   360,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   370,   370,   340,   360,   340}
    }
   ,{{   400,   370,   400,   340,   400}
    ,{   400,   370,   400,   340,   400}
    ,{   370,   370,   340,   340,   340}
    ,{   340,   260,   210,   340,   340}
    ,{   370,   370,   340,   340,   340}
    }
   ,{{   430,   430,   340,   360,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   370,   370,   340,   360,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   430,   430,   340,   340,   340}
    }
   }
  ,{{{   430,   430,   370,   360,   370}
    ,{   410,   410,   370,   360,   370}
    ,{   370,   370,   340,   360,   340}
    ,{   370,   370,   340,   300,   340}
    ,{   430,   430,   340,   360,   340}
    }
   ,{{   410,   410,   370,   360,   370}
    ,{   410,   410,   370,   360,   370}
    ,{   370,   370,   340,   300,   340}
    ,{   290,   290,   260,   220,   260}
    ,{   370,   370,   340,   300,   340}
    }
   ,{{   370,   370,   340,   360,   340}
    ,{   370,   370,   340,   300,   340}
    ,{   370,   370,   340,   360,   340}
    ,{   370,   370,   340,   300,   340}
    ,{   370,   370,   340,   360,   340}
    }
   ,{{   370,   370,   340,   300,   340}
    ,{   370,   370,   340,   300,   340}
    ,{   370,   370,   340,   300,   340}
    ,{   300,   240,   210,   300,   210}
    ,{   370,   370,   340,   300,   340}
    }
   ,{{   430,   430,   340,   360,   340}
    ,{   370,   370,   340,   300,   340}
    ,{   370,   370,   340,   360,   340}
    ,{   370,   370,   340,   300,   340}
    ,{   430,   430,   340,   300,   340}
    }
   }
  ,{{{   400,   370,   400,   370,   400}
    ,{   400,   370,   400,   370,   400}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   370,   370,   370,   370,   370}
    ,{   370,   370,   370,   370,   370}
    ,{   340,   340,   340,   340,   340}
    ,{   320,   260,   320,   260,   320}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   400,   340,   400,   340,   400}
    ,{   400,   340,   400,   340,   400}
    ,{   340,   340,   340,   340,   340}
    ,{   210,   210,   210,   210,   210}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   }
  ,{{{   370,   320,   370,   340,   370}
    ,{   370,   290,   370,   340,   370}
    ,{   340,   320,   340,   210,   340}
    ,{   340,   260,   340,   340,   340}
    ,{   340,   320,   340,   340,   340}
    }
   ,{{   370,   290,   370,   260,   370}
    ,{   370,   290,   370,   240,   370}
    ,{   340,   260,   340,   210,   340}
    ,{   260,   180,   260,   260,   260}
    ,{   340,   260,   340,   210,   340}
    }
   ,{{   340,   320,   340,   210,   340}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   320,   340,   210,   340}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   320,   340,   210,   340}
    }
   ,{{   340,   260,   340,   340,   340}
    ,{   340,   260,   340,   340,   340}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   260,   210,   340,   210}
    ,{   340,   260,   340,   210,   340}
    }
   ,{{   340,   320,   340,   340,   340}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   320,   340,   210,   340}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   260,   340,   340,   340}
    }
   }
  ,{{{   430,   370,   400,   370,   430}
    ,{   430,   370,   400,   370,   430}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   430,   370,   370,   370,   430}
    ,{   430,   370,   370,   370,   430}
    ,{   340,   340,   340,   340,   340}
    ,{   320,   260,   320,   260,   260}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   400,   340,   400,   340,   340}
    ,{   400,   340,   400,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   210,   210,   210,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   }
  }
 }
,{{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   310,   240,   240,   310,   260}
    ,{   270,   240,   240,   270,   260}
    ,{   310,   220,   220,   310,   220}
    ,{   270,   240,   240,   270,   240}
    ,{   300,   210,   210,   300,   210}
    }
   ,{{   260,   200,   200,   230,   260}
    ,{   260,   200,   200,   230,   260}
    ,{   220,   190,   190,   220,   190}
    ,{   160,   100,   160,   130,   160}
    ,{   220,   190,   190,   220,   190}
    }
   ,{{   310,   240,   240,   310,   240}
    ,{   270,   240,   240,   270,   240}
    ,{   310,   220,   220,   310,   220}
    ,{   270,   240,   240,   270,   240}
    ,{   300,   210,   210,   300,   210}
    }
   ,{{   220,   190,   190,   220,   190}
    ,{   160,   100,   160,   130,   160}
    ,{   220,   190,   190,   220,   190}
    ,{   210,    50,    50,   210,   180}
    ,{   220,   190,   190,   220,   190}
    }
   ,{{   300,   240,   240,   300,   240}
    ,{   270,   240,   240,   270,   240}
    ,{   300,   210,   210,   300,   210}
    ,{   270,   240,   240,   270,   240}
    ,{   150,   140,   120,   150,   120}
    }
   }
  ,{{{   310,   200,   240,   310,   240}
    ,{   270,   200,   240,   270,   240}
    ,{   310,   190,   220,   310,   220}
    ,{   270,   200,   240,   270,   240}
    ,{   300,   170,   210,   300,   210}
    }
   ,{{   230,   160,   200,   230,   200}
    ,{   230,   160,   200,   230,   200}
    ,{   220,   160,   190,   220,   190}
    ,{   130,    70,   100,   130,   100}
    ,{   220,   160,   190,   220,   190}
    }
   ,{{   310,   200,   240,   310,   240}
    ,{   270,   200,   240,   270,   240}
    ,{   310,   190,   220,   310,   220}
    ,{   270,   200,   240,   270,   240}
    ,{   300,   170,   210,   300,   210}
    }
   ,{{   220,   160,   190,   220,   190}
    ,{   130,    70,   100,   130,   100}
    ,{   220,   160,   190,   220,   190}
    ,{   210,    10,    50,   210,    50}
    ,{   220,   160,   190,   220,   190}
    }
   ,{{   300,   200,   240,   300,   240}
    ,{   270,   200,   240,   270,   240}
    ,{   300,   170,   210,   300,   210}
    ,{   270,   200,   240,   270,   240}
    ,{   150,   140,   120,   150,   120}
    }
   }
  ,{{{   240,   240,   240,   240,   240}
    ,{   240,   240,   240,   240,   240}
    ,{   220,   220,   220,   220,   220}
    ,{   240,   240,   240,   240,   240}
    ,{   210,   210,   210,   210,   210}
    }
   ,{{   200,   200,   200,   200,   200}
    ,{   200,   200,   200,   200,   200}
    ,{   190,   190,   190,   190,   190}
    ,{   160,   100,   160,   100,   160}
    ,{   190,   190,   190,   190,   190}
    }
   ,{{   240,   240,   240,   240,   240}
    ,{   240,   240,   240,   240,   240}
    ,{   220,   220,   220,   220,   220}
    ,{   240,   240,   240,   240,   240}
    ,{   210,   210,   210,   210,   210}
    }
   ,{{   190,   190,   190,   190,   190}
    ,{   160,   100,   160,   100,   160}
    ,{   190,   190,   190,   190,   190}
    ,{    50,    50,    50,    50,    50}
    ,{   190,   190,   190,   190,   190}
    }
   ,{{   240,   240,   240,   240,   240}
    ,{   240,   240,   240,   240,   240}
    ,{   210,   210,   210,   210,   210}
    ,{   240,   240,   240,   240,   240}
    ,{   120,   120,   120,   120,   120}
    }
   }
  ,{{{   240,   150,   240,   180,   240}
    ,{   240,   100,   240,   110,   240}
    ,{   220,   150,   220,    90,   220}
    ,{   240,   100,   240,   180,   240}
    ,{   210,   130,   210,   120,   210}
    }
   ,{{   200,    60,   200,   100,   200}
    ,{   200,    60,   200,    70,   200}
    ,{   190,    60,   190,    60,   190}
    ,{   100,   -30,   100,   100,   100}
    ,{   190,    60,   190,    60,   190}
    }
   ,{{   240,   150,   240,   110,   240}
    ,{   240,   100,   240,   110,   240}
    ,{   220,   150,   220,    90,   220}
    ,{   240,   100,   240,   110,   240}
    ,{   210,   130,   210,    80,   210}
    }
   ,{{   190,    60,   190,   180,   190}
    ,{   100,   -30,   100,   100,   100}
    ,{   190,    60,   190,    60,   190}
    ,{   180,    40,    50,   180,    50}
    ,{   190,    60,   190,    60,   190}
    }
   ,{{   240,   130,   240,   120,   240}
    ,{   240,   100,   240,   110,   240}
    ,{   210,   130,   210,    80,   210}
    ,{   240,   100,   240,   110,   240}
    ,{   120,   -10,   120,   120,   120}
    }
   }
  ,{{{   260,   240,   240,   240,   260}
    ,{   260,   240,   240,   240,   260}
    ,{   220,   220,   220,   220,   220}
    ,{   240,   240,   240,   240,   240}
    ,{   210,   210,   210,   210,   210}
    }
   ,{{   260,   200,   200,   200,   260}
    ,{   260,   200,   200,   200,   260}
    ,{   190,   190,   190,   190,   190}
    ,{   160,   100,   160,   100,   100}
    ,{   190,   190,   190,   190,   190}
    }
   ,{{   240,   240,   240,   240,   240}
    ,{   240,   240,   240,   240,   240}
    ,{   220,   220,   220,   220,   220}
    ,{   240,   240,   240,   240,   240}
    ,{   210,   210,   210,   210,   210}
    }
   ,{{   190,   190,   190,   190,   190}
    ,{   160,   100,   160,   100,   100}
    ,{   190,   190,   190,   190,   190}
    ,{   180,    50,    50,    50,   180}
    ,{   190,   190,   190,   190,   190}
    }
   ,{{   240,   240,   240,   240,   240}
    ,{   240,   240,   240,   240,   240}
    ,{   210,   210,   210,   210,   210}
    ,{   240,   240,   240,   240,   240}
    ,{   120,   120,   120,   120,   120}
    }
   }
  }
 ,{{{{   280,   210,   210,   280,   270}
    ,{   270,   210,   210,   240,   270}
    ,{   280,   190,   190,   280,   190}
    ,{   210,   180,   180,   210,   180}
    ,{   280,   190,   190,   280,   190}
    }
   ,{{   270,   210,   210,   240,   270}
    ,{   270,   210,   210,   240,   270}
    ,{   220,   190,   190,   220,   190}
    ,{    70,    10,    70,    40,    70}
    ,{   220,   190,   190,   220,   190}
    }
   ,{{   280,   190,   190,   280,   190}
    ,{   210,   180,   180,   210,   180}
    ,{   280,   190,   190,   280,   190}
    ,{   210,   180,   180,   210,   180}
    ,{   280,   190,   190,   280,   190}
    }
   ,{{   220,   190,   190,   220,   190}
    ,{   130,    70,   130,   100,   130}
    ,{   220,   190,   190,   220,   190}
    ,{   210,    50,    50,   210,   180}
    ,{   220,   190,   190,   220,   190}
    }
   ,{{   280,   190,   190,   280,   190}
    ,{   210,   180,   180,   210,   180}
    ,{   280,   190,   190,   280,   190}
    ,{   210,   180,   180,   210,   180}
    ,{   140,   140,   110,   140,   110}
    }
   }
  ,{{{   280,   190,   210,   280,   210}
    ,{   240,   190,   210,   240,   210}
    ,{   280,   160,   190,   280,   190}
    ,{   210,   150,   180,   210,   180}
    ,{   280,   150,   190,   280,   190}
    }
   ,{{   240,   190,   210,   240,   210}
    ,{   240,   190,   210,   240,   210}
    ,{   220,   150,   190,   220,   190}
    ,{    40,   -20,    10,    40,    10}
    ,{   220,   150,   190,   220,   190}
    }
   ,{{   280,   150,   190,   280,   190}
    ,{   210,   150,   180,   210,   180}
    ,{   280,   150,   190,   280,   190}
    ,{   210,   150,   180,   210,   180}
    ,{   280,   150,   190,   280,   190}
    }
   ,{{   220,   150,   190,   220,   190}
    ,{   100,    40,    70,   100,    70}
    ,{   220,   150,   190,   220,   190}
    ,{   210,    10,    50,   210,    50}
    ,{   220,   150,   190,   220,   190}
    }
   ,{{   280,   160,   190,   280,   190}
    ,{   210,   150,   180,   210,   180}
    ,{   280,   160,   190,   280,   190}
    ,{   210,   150,   180,   210,   180}
    ,{   140,   140,   110,   140,   110}
    }
   }
  ,{{{   210,   210,   210,   210,   210}
    ,{   210,   210,   210,   210,   210}
    ,{   190,   190,   190,   190,   190}
    ,{   180,   180,   180,   180,   180}
    ,{   190,   190,   190,   190,   190}
    }
   ,{{   210,   210,   210,   210,   210}
    ,{   210,   210,   210,   210,   210}
    ,{   190,   190,   190,   190,   190}
    ,{    70,    10,    70,    10,    70}
    ,{   190,   190,   190,   190,   190}
    }
   ,{{   190,   190,   190,   190,   190}
    ,{   180,   180,   180,   180,   180}
    ,{   190,   190,   190,   190,   190}
    ,{   180,   180,   180,   180,   180}
    ,{   190,   190,   190,   190,   190}
    }
   ,{{   190,   190,   190,   190,   190}
    ,{   130,    70,   130,    70,   130}
    ,{   190,   190,   190,   190,   190}
    ,{    50,    50,    50,    50,    50}
    ,{   190,   190,   190,   190,   190}
    }
   ,{{   190,   190,   190,   190,   190}
    ,{   180,   180,   180,   180,   180}
    ,{   190,   190,   190,   190,   190}
    ,{   180,   180,   180,   180,   180}
    ,{   110,   110,   110,   110,   110}
    }
   }
  ,{{{   210,   120,   210,   180,   210}
    ,{   210,    80,   210,    80,   210}
    ,{   190,   120,   190,    60,   190}
    ,{   180,    50,   180,   180,   180}
    ,{   190,   110,   190,   110,   190}
    }
   ,{{   210,    80,   210,    80,   210}
    ,{   210,    80,   210,    80,   210}
    ,{   190,    50,   190,    60,   190}
    ,{    10,  -120,    10,    10,    10}
    ,{   190,    50,   190,    60,   190}
    }
   ,{{   190,   110,   190,    60,   190}
    ,{   180,    50,   180,    50,   180}
    ,{   190,   110,   190,    60,   190}
    ,{   180,    50,   180,    50,   180}
    ,{   190,   110,   190,    60,   190}
    }
   ,{{   190,    50,   190,   180,   190}
    ,{    70,   -60,    70,    70,    70}
    ,{   190,    50,   190,    60,   190}
    ,{   180,    40,    50,   180,    50}
    ,{   190,    50,   190,    60,   190}
    }
   ,{{   190,   120,   190,   110,   190}
    ,{   180,    50,   180,    50,   180}
    ,{   190,   120,   190,    60,   190}
    ,{   180,    50,   180,    50,   180}
    ,{   110,   -20,   110,   110,   110}
    }
   }
  ,{{{   270,   210,   210,   210,   270}
    ,{   270,   210,   210,   210,   270}
    ,{   190,   190,   190,   190,   190}
    ,{   180,   180,   180,   180,   180}
    ,{   190,   190,   190,   190,   190}
    }
   ,{{   270,   210,   210,   210,   270}
    ,{   270,   210,   210,   210,   270}
    ,{   190,   190,   190,   190,   190}
    ,{    70,    10,    70,    10,    10}
    ,{   190,   190,   190,   190,   190}
    }
   ,{{   190,   190,   190,   190,   190}
    ,{   180,   180,   180,   180,   180}
    ,{   190,   190,   190,   190,   190}
    ,{   180,   180,   180,   180,   180}
    ,{   190,   190,   190,   190,   190}
    }
   ,{{   190,   190,   190,   190,   190}
    ,{   130,    70,   130,    70,    70}
    ,{   190,   190,   190,   190,   190}
    ,{   180,    50,    50,    50,   180}
    ,{   190,   190,   190,   190,   190}
    }
   ,{{   190,   190,   190,   190,   190}
    ,{   180,   180,   180,   180,   180}
    ,{   190,   190,   190,   190,   190}
    ,{   180,   180,   180,   180,   180}
    ,{   110,   110,   110,   110,   110}
    }
   }
  }
 ,{{{{   400,   360,   340,   400,   400}
    ,{   400,   360,   340,   370,   400}
    ,{   400,   310,   310,   400,   310}
    ,{   340,   310,   310,   340,   310}
    ,{   400,   330,   310,   400,   310}
    }
   ,{{   400,   360,   340,   370,   400}
    ,{   400,   360,   340,   370,   400}
    ,{   340,   310,   310,   340,   310}
    ,{   290,   230,   290,   260,   290}
    ,{   340,   310,   310,   340,   310}
    }
   ,{{   400,   310,   310,   400,   310}
    ,{   340,   310,   310,   340,   310}
    ,{   400,   310,   310,   400,   310}
    ,{   340,   310,   310,   340,   310}
    ,{   400,   310,   310,   400,   310}
    }
   ,{{   360,   360,   330,   340,   330}
    ,{   360,   360,   330,   300,   330}
    ,{   340,   310,   310,   340,   310}
    ,{   340,   180,   180,   340,   310}
    ,{   340,   310,   310,   340,   310}
    }
   ,{{   400,   330,   310,   400,   310}
    ,{   340,   310,   310,   340,   310}
    ,{   400,   310,   310,   400,   310}
    ,{   340,   310,   310,   340,   310}
    ,{   340,   330,   310,   340,   310}
    }
   }
  ,{{{   400,   360,   340,   400,   340}
    ,{   370,   360,   340,   370,   340}
    ,{   400,   270,   310,   400,   310}
    ,{   340,   270,   310,   340,   310}
    ,{   400,   330,   310,   400,   310}
    }
   ,{{   370,   360,   340,   370,   340}
    ,{   370,   360,   340,   370,   340}
    ,{   340,   270,   310,   340,   310}
    ,{   260,   190,   230,   260,   230}
    ,{   340,   270,   310,   340,   310}
    }
   ,{{   400,   270,   310,   400,   310}
    ,{   340,   270,   310,   340,   310}
    ,{   400,   270,   310,   400,   310}
    ,{   340,   270,   310,   340,   310}
    ,{   400,   270,   310,   400,   310}
    }
   ,{{   360,   360,   310,   340,   310}
    ,{   360,   360,   270,   300,   270}
    ,{   340,   270,   310,   340,   310}
    ,{   340,   140,   180,   340,   180}
    ,{   340,   270,   310,   340,   310}
    }
   ,{{   400,   330,   310,   400,   310}
    ,{   340,   270,   310,   340,   310}
    ,{   400,   270,   310,   400,   310}
    ,{   340,   270,   310,   340,   310}
    ,{   340,   330,   310,   340,   310}
    }
   }
  ,{{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   310,   310,   310,   310,   310}
    ,{   290,   230,   290,   230,   290}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   330,   310,   330,   310,   330}
    ,{   330,   270,   330,   270,   330}
    ,{   310,   310,   310,   310,   310}
    ,{   180,   180,   180,   180,   180}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   }
  ,{{{   340,   230,   340,   310,   340}
    ,{   340,   220,   340,   270,   340}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   170,   310,   310,   310}
    ,{   310,   230,   310,   310,   310}
    }
   ,{{   340,   220,   340,   230,   340}
    ,{   340,   220,   340,   210,   340}
    ,{   310,   170,   310,   180,   310}
    ,{   230,    20,   230,   230,   230}
    ,{   310,   170,   310,   180,   310}
    }
   ,{{   310,   230,   310,   180,   310}
    ,{   310,   170,   310,   180,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   170,   310,   180,   310}
    ,{   310,   230,   310,   180,   310}
    }
   ,{{   310,   170,   310,   310,   310}
    ,{   270,   130,   270,   270,   270}
    ,{   310,   170,   310,   180,   310}
    ,{   310,   170,   180,   310,   180}
    ,{   310,   170,   310,   180,   310}
    }
   ,{{   310,   230,   310,   310,   310}
    ,{   310,   170,   310,   180,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   170,   310,   180,   310}
    ,{   310,   170,   310,   310,   310}
    }
   }
  ,{{{   400,   340,   340,   340,   400}
    ,{   400,   340,   340,   340,   400}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   400,   340,   340,   340,   400}
    ,{   400,   340,   340,   340,   400}
    ,{   310,   310,   310,   310,   310}
    ,{   290,   230,   290,   230,   230}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   330,   310,   330,   310,   310}
    ,{   330,   270,   330,   270,   270}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   180,   180,   180,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   }
  }
 ,{{{{   370,   310,   370,   370,   370}
    ,{   370,   310,   370,   340,   370}
    ,{   370,   280,   280,   370,   280}
    ,{   310,   280,   280,   310,   280}
    ,{   370,   300,   280,   370,   280}
    }
   ,{{   310,   280,   280,   310,   300}
    ,{   300,   240,   240,   270,   300}
    ,{   310,   280,   280,   310,   280}
    ,{   200,   140,   200,   170,   200}
    ,{   310,   280,   280,   310,   280}
    }
   ,{{   370,   280,   280,   370,   280}
    ,{   310,   280,   280,   310,   280}
    ,{   370,   280,   280,   370,   280}
    ,{   310,   280,   280,   310,   280}
    ,{   370,   280,   280,   370,   280}
    }
   ,{{   370,   310,   370,   340,   370}
    ,{   370,   310,   370,   340,   370}
    ,{   310,   280,   280,   310,   280}
    ,{   310,   150,   150,   310,   280}
    ,{   310,   280,   280,   310,   280}
    }
   ,{{   370,   300,   280,   370,   280}
    ,{   310,   280,   280,   310,   280}
    ,{   370,   280,   280,   370,   280}
    ,{   310,   280,   280,   310,   280}
    ,{   310,   300,   280,   310,   280}
    }
   }
  ,{{{   370,   300,   310,   370,   310}
    ,{   340,   270,   310,   340,   310}
    ,{   370,   240,   280,   370,   280}
    ,{   310,   240,   280,   310,   280}
    ,{   370,   300,   280,   370,   280}
    }
   ,{{   310,   240,   280,   310,   280}
    ,{   270,   210,   240,   270,   240}
    ,{   310,   240,   280,   310,   280}
    ,{   170,   110,   140,   170,   140}
    ,{   310,   240,   280,   310,   280}
    }
   ,{{   370,   240,   280,   370,   280}
    ,{   310,   240,   280,   310,   280}
    ,{   370,   240,   280,   370,   280}
    ,{   310,   240,   280,   310,   280}
    ,{   370,   240,   280,   370,   280}
    }
   ,{{   340,   270,   310,   340,   310}
    ,{   340,   270,   310,   340,   310}
    ,{   310,   240,   280,   310,   280}
    ,{   310,   110,   150,   310,   150}
    ,{   310,   240,   280,   310,   280}
    }
   ,{{   370,   300,   280,   370,   280}
    ,{   310,   240,   280,   310,   280}
    ,{   370,   240,   280,   370,   280}
    ,{   310,   240,   280,   310,   280}
    ,{   310,   300,   280,   310,   280}
    }
   }
  ,{{{   370,   310,   370,   310,   370}
    ,{   370,   310,   370,   310,   370}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   280,   280,   280,   280,   280}
    ,{   240,   240,   240,   240,   240}
    ,{   280,   280,   280,   280,   280}
    ,{   200,   140,   200,   140,   200}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   370,   310,   370,   310,   370}
    ,{   370,   310,   370,   310,   370}
    ,{   280,   280,   280,   280,   280}
    ,{   150,   150,   150,   150,   150}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    }
   }
  ,{{{   310,   200,   310,   310,   310}
    ,{   310,   170,   310,   310,   310}
    ,{   280,   200,   280,   150,   280}
    ,{   280,   140,   280,   280,   280}
    ,{   280,   200,   280,   280,   280}
    }
   ,{{   280,   140,   280,   150,   280}
    ,{   240,   110,   240,   110,   240}
    ,{   280,   140,   280,   150,   280}
    ,{   140,    10,   140,   140,   140}
    ,{   280,   140,   280,   150,   280}
    }
   ,{{   280,   200,   280,   150,   280}
    ,{   280,   140,   280,   150,   280}
    ,{   280,   200,   280,   150,   280}
    ,{   280,   140,   280,   150,   280}
    ,{   280,   200,   280,   150,   280}
    }
   ,{{   310,   170,   310,   310,   310}
    ,{   310,   170,   310,   310,   310}
    ,{   280,   140,   280,   150,   280}
    ,{   280,   140,   150,   280,   150}
    ,{   280,   140,   280,   150,   280}
    }
   ,{{   280,   200,   280,   280,   280}
    ,{   280,   140,   280,   150,   280}
    ,{   280,   200,   280,   150,   280}
    ,{   280,   140,   280,   150,   280}
    ,{   280,   140,   280,   280,   280}
    }
   }
  ,{{{   370,   310,   370,   310,   310}
    ,{   370,   310,   370,   310,   310}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   300,   280,   280,   280,   300}
    ,{   300,   240,   240,   240,   300}
    ,{   280,   280,   280,   280,   280}
    ,{   200,   140,   200,   140,   140}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   370,   310,   370,   310,   310}
    ,{   370,   310,   370,   310,   310}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   150,   150,   150,   280}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    }
   }
  }
 ,{{{{   350,   280,   280,   350,   340}
    ,{   340,   280,   280,   310,   340}
    ,{   350,   260,   260,   350,   260}
    ,{   290,   260,   260,   290,   260}
    ,{   350,   260,   260,   350,   260}
    }
   ,{{   340,   280,   280,   310,   340}
    ,{   340,   280,   280,   310,   340}
    ,{   280,   250,   250,   280,   250}
    ,{   210,   150,   210,   180,   210}
    ,{   280,   250,   250,   280,   250}
    }
   ,{{   350,   260,   260,   350,   260}
    ,{   290,   260,   260,   290,   260}
    ,{   350,   260,   260,   350,   260}
    ,{   290,   260,   260,   290,   260}
    ,{   350,   260,   260,   350,   260}
    }
   ,{{   280,   250,   280,   280,   280}
    ,{   280,   220,   280,   250,   280}
    ,{   280,   250,   250,   280,   250}
    ,{   260,   100,   100,   260,   230}
    ,{   280,   250,   250,   280,   250}
    }
   ,{{   350,   260,   260,   350,   260}
    ,{   290,   260,   260,   290,   260}
    ,{   350,   260,   260,   350,   260}
    ,{   290,   260,   260,   290,   260}
    ,{   200,   190,   170,   200,   170}
    }
   }
  ,{{{   350,   240,   280,   350,   280}
    ,{   310,   240,   280,   310,   280}
    ,{   350,   220,   260,   350,   260}
    ,{   290,   230,   260,   290,   260}
    ,{   350,   220,   260,   350,   260}
    }
   ,{{   310,   240,   280,   310,   280}
    ,{   310,   240,   280,   310,   280}
    ,{   280,   220,   250,   280,   250}
    ,{   180,   120,   150,   180,   150}
    ,{   280,   220,   250,   280,   250}
    }
   ,{{   350,   230,   260,   350,   260}
    ,{   290,   230,   260,   290,   260}
    ,{   350,   220,   260,   350,   260}
    ,{   290,   230,   260,   290,   260}
    ,{   350,   220,   260,   350,   260}
    }
   ,{{   280,   220,   250,   280,   250}
    ,{   250,   190,   220,   250,   220}
    ,{   280,   220,   250,   280,   250}
    ,{   260,    70,   100,   260,   100}
    ,{   280,   220,   250,   280,   250}
    }
   ,{{   350,   230,   260,   350,   260}
    ,{   290,   230,   260,   290,   260}
    ,{   350,   220,   260,   350,   260}
    ,{   290,   230,   260,   290,   260}
    ,{   200,   190,   170,   200,   170}
    }
   }
  ,{{{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   260,   260,   260,   260,   260}
    ,{   260,   260,   260,   260,   260}
    ,{   260,   260,   260,   260,   260}
    }
   ,{{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   250,   250,   250,   250,   250}
    ,{   210,   150,   210,   150,   210}
    ,{   250,   250,   250,   250,   250}
    }
   ,{{   260,   260,   260,   260,   260}
    ,{   260,   260,   260,   260,   260}
    ,{   260,   260,   260,   260,   260}
    ,{   260,   260,   260,   260,   260}
    ,{   260,   260,   260,   260,   260}
    }
   ,{{   280,   250,   280,   250,   280}
    ,{   280,   220,   280,   220,   280}
    ,{   250,   250,   250,   250,   250}
    ,{   100,   100,   100,   100,   100}
    ,{   250,   250,   250,   250,   250}
    }
   ,{{   260,   260,   260,   260,   260}
    ,{   260,   260,   260,   260,   260}
    ,{   260,   260,   260,   260,   260}
    ,{   260,   260,   260,   260,   260}
    ,{   170,   170,   170,   170,   170}
    }
   }
  ,{{{   280,   180,   280,   230,   280}
    ,{   280,   140,   280,   220,   280}
    ,{   260,   180,   260,   130,   260}
    ,{   260,   130,   260,   230,   260}
    ,{   260,   180,   260,   170,   260}
    }
   ,{{   280,   140,   280,   150,   280}
    ,{   280,   140,   280,   150,   280}
    ,{   250,   120,   250,   120,   250}
    ,{   150,    20,   150,   150,   150}
    ,{   250,   120,   250,   120,   250}
    }
   ,{{   260,   180,   260,   130,   260}
    ,{   260,   130,   260,   130,   260}
    ,{   260,   180,   260,   130,   260}
    ,{   260,   130,   260,   130,   260}
    ,{   260,   180,   260,   130,   260}
    }
   ,{{   250,   120,   250,   230,   250}
    ,{   220,    90,   220,   220,   220}
    ,{   250,   120,   250,   120,   250}
    ,{   230,   100,   100,   230,   100}
    ,{   250,   120,   250,   120,   250}
    }
   ,{{   260,   180,   260,   170,   260}
    ,{   260,   130,   260,   130,   260}
    ,{   260,   180,   260,   130,   260}
    ,{   260,   130,   260,   130,   260}
    ,{   170,    30,   170,   170,   170}
    }
   }
  ,{{{   340,   280,   280,   280,   340}
    ,{   340,   280,   280,   280,   340}
    ,{   260,   260,   260,   260,   260}
    ,{   260,   260,   260,   260,   260}
    ,{   260,   260,   260,   260,   260}
    }
   ,{{   340,   280,   280,   280,   340}
    ,{   340,   280,   280,   280,   340}
    ,{   250,   250,   250,   250,   250}
    ,{   210,   150,   210,   150,   150}
    ,{   250,   250,   250,   250,   250}
    }
   ,{{   260,   260,   260,   260,   260}
    ,{   260,   260,   260,   260,   260}
    ,{   260,   260,   260,   260,   260}
    ,{   260,   260,   260,   260,   260}
    ,{   260,   260,   260,   260,   260}
    }
   ,{{   280,   250,   280,   250,   250}
    ,{   280,   220,   280,   220,   220}
    ,{   250,   250,   250,   250,   250}
    ,{   230,   100,   100,   100,   230}
    ,{   250,   250,   250,   250,   250}
    }
   ,{{   260,   260,   260,   260,   260}
    ,{   260,   260,   260,   260,   260}
    ,{   260,   260,   260,   260,   260}
    ,{   260,   260,   260,   260,   260}
    ,{   170,   170,   170,   170,   170}
    }
   }
  }
 ,{{{{   370,   280,   280,   370,   340}
    ,{   340,   280,   280,   310,   340}
    ,{   370,   280,   280,   370,   280}
    ,{   310,   280,   280,   310,   280}
    ,{   370,   280,   280,   370,   280}
    }
   ,{{   340,   280,   280,   310,   340}
    ,{   340,   280,   280,   310,   340}
    ,{   260,   230,   230,   260,   230}
    ,{   230,   170,   230,   200,   230}
    ,{   260,   230,   230,   260,   230}
    }
   ,{{   370,   280,   280,   370,   280}
    ,{   310,   280,   280,   310,   280}
    ,{   370,   280,   280,   370,   280}
    ,{   310,   280,   280,   310,   280}
    ,{   370,   280,   280,   370,   280}
    }
   ,{{   280,   230,   240,   280,   250}
    ,{   240,   180,   240,   210,   240}
    ,{   260,   230,   230,   260,   230}
    ,{   280,   120,   120,   280,   250}
    ,{   260,   230,   230,   260,   230}
    }
   ,{{   340,   280,   280,   340,   280}
    ,{   310,   280,   280,   310,   280}
    ,{   340,   250,   250,   340,   250}
    ,{   310,   280,   280,   310,   280}
    ,{   220,   220,   190,   220,   190}
    }
   }
  ,{{{   370,   240,   280,   370,   280}
    ,{   310,   240,   280,   310,   280}
    ,{   370,   240,   280,   370,   280}
    ,{   310,   240,   280,   310,   280}
    ,{   370,   240,   280,   370,   280}
    }
   ,{{   310,   240,   280,   310,   280}
    ,{   310,   240,   280,   310,   280}
    ,{   260,   200,   230,   260,   230}
    ,{   200,   140,   170,   200,   170}
    ,{   260,   200,   230,   260,   230}
    }
   ,{{   370,   240,   280,   370,   280}
    ,{   310,   240,   280,   310,   280}
    ,{   370,   240,   280,   370,   280}
    ,{   310,   240,   280,   310,   280}
    ,{   370,   240,   280,   370,   280}
    }
   ,{{   280,   200,   230,   280,   230}
    ,{   210,   150,   180,   210,   180}
    ,{   260,   200,   230,   260,   230}
    ,{   280,    90,   120,   280,   120}
    ,{   260,   200,   230,   260,   230}
    }
   ,{{   340,   240,   280,   340,   280}
    ,{   310,   240,   280,   310,   280}
    ,{   340,   210,   250,   340,   250}
    ,{   310,   240,   280,   310,   280}
    ,{   220,   220,   190,   220,   190}
    }
   }
  ,{{{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   230,   230,   230,   230,   230}
    ,{   230,   170,   230,   170,   230}
    ,{   230,   230,   230,   230,   230}
    }
   ,{{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   240,   230,   240,   230,   240}
    ,{   240,   180,   240,   180,   240}
    ,{   230,   230,   230,   230,   230}
    ,{   120,   120,   120,   120,   120}
    ,{   230,   230,   230,   230,   230}
    }
   ,{{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   250,   250,   250,   250,   250}
    ,{   280,   280,   280,   280,   280}
    ,{   190,   190,   190,   190,   190}
    }
   }
  ,{{{   280,   200,   280,   250,   280}
    ,{   280,   140,   280,   180,   280}
    ,{   280,   200,   280,   150,   280}
    ,{   280,   140,   280,   250,   280}
    ,{   280,   200,   280,   190,   280}
    }
   ,{{   280,   140,   280,   170,   280}
    ,{   280,   140,   280,   150,   280}
    ,{   230,   100,   230,   100,   230}
    ,{   170,    40,   170,   170,   170}
    ,{   230,   100,   230,   100,   230}
    }
   ,{{   280,   200,   280,   150,   280}
    ,{   280,   140,   280,   150,   280}
    ,{   280,   200,   280,   150,   280}
    ,{   280,   140,   280,   150,   280}
    ,{   280,   200,   280,   150,   280}
    }
   ,{{   250,   120,   230,   250,   230}
    ,{   180,    50,   180,   180,   180}
    ,{   230,   100,   230,   100,   230}
    ,{   250,   120,   120,   250,   120}
    ,{   230,   100,   230,   100,   230}
    }
   ,{{   280,   170,   280,   190,   280}
    ,{   280,   140,   280,   150,   280}
    ,{   250,   170,   250,   120,   250}
    ,{   280,   140,   280,   150,   280}
    ,{   190,    60,   190,   190,   190}
    }
   }
  ,{{{   340,   280,   280,   280,   340}
    ,{   340,   280,   280,   280,   340}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   340,   280,   280,   280,   340}
    ,{   340,   280,   280,   280,   340}
    ,{   230,   230,   230,   230,   230}
    ,{   230,   170,   230,   170,   170}
    ,{   230,   230,   230,   230,   230}
    }
   ,{{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   250,   230,   240,   230,   250}
    ,{   240,   180,   240,   180,   180}
    ,{   230,   230,   230,   230,   230}
    ,{   250,   120,   120,   120,   250}
    ,{   230,   230,   230,   230,   230}
    }
   ,{{   280,   280,   280,   280,   280}
    ,{   280,   280,   280,   280,   280}
    ,{   250,   250,   250,   250,   250}
    ,{   280,   280,   280,   280,   280}
    ,{   190,   190,   190,   190,   190}
    }
   }
  }
 ,{{{{   400,   360,   370,   400,   400}
    ,{   400,   360,   370,   370,   400}
    ,{   400,   310,   310,   400,   310}
    ,{   340,   310,   310,   340,   310}
    ,{   400,   330,   310,   400,   310}
    }
   ,{{   400,   360,   340,   370,   400}
    ,{   400,   360,   340,   370,   400}
    ,{   340,   310,   310,   340,   310}
    ,{   290,   230,   290,   260,   290}
    ,{   340,   310,   310,   340,   310}
    }
   ,{{   400,   310,   310,   400,   310}
    ,{   340,   310,   310,   340,   310}
    ,{   400,   310,   310,   400,   310}
    ,{   340,   310,   310,   340,   310}
    ,{   400,   310,   310,   400,   310}
    }
   ,{{   370,   360,   370,   340,   370}
    ,{   370,   360,   370,   340,   370}
    ,{   340,   310,   310,   340,   310}
    ,{   340,   180,   180,   340,   310}
    ,{   340,   310,   310,   340,   310}
    }
   ,{{   400,   330,   310,   400,   310}
    ,{   340,   310,   310,   340,   310}
    ,{   400,   310,   310,   400,   310}
    ,{   340,   310,   310,   340,   310}
    ,{   340,   330,   310,   340,   310}
    }
   }
  ,{{{   400,   360,   340,   400,   340}
    ,{   370,   360,   340,   370,   340}
    ,{   400,   270,   310,   400,   310}
    ,{   340,   270,   310,   340,   310}
    ,{   400,   330,   310,   400,   310}
    }
   ,{{   370,   360,   340,   370,   340}
    ,{   370,   360,   340,   370,   340}
    ,{   340,   270,   310,   340,   310}
    ,{   260,   190,   230,   260,   230}
    ,{   340,   270,   310,   340,   310}
    }
   ,{{   400,   270,   310,   400,   310}
    ,{   340,   270,   310,   340,   310}
    ,{   400,   270,   310,   400,   310}
    ,{   340,   270,   310,   340,   310}
    ,{   400,   270,   310,   400,   310}
    }
   ,{{   360,   360,   310,   340,   310}
    ,{   360,   360,   310,   340,   310}
    ,{   340,   270,   310,   340,   310}
    ,{   340,   140,   180,   340,   180}
    ,{   340,   270,   310,   340,   310}
    }
   ,{{   400,   330,   310,   400,   310}
    ,{   340,   270,   310,   340,   310}
    ,{   400,   270,   310,   400,   310}
    ,{   340,   270,   310,   340,   310}
    ,{   340,   330,   310,   340,   310}
    }
   }
  ,{{{   370,   340,   370,   340,   370}
    ,{   370,   340,   370,   340,   370}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   310,   310,   310,   310,   310}
    ,{   290,   230,   290,   230,   290}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   370,   310,   370,   310,   370}
    ,{   370,   310,   370,   310,   370}
    ,{   310,   310,   310,   310,   310}
    ,{   180,   180,   180,   180,   180}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   }
  ,{{{   340,   230,   340,   310,   340}
    ,{   340,   220,   340,   310,   340}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   170,   310,   310,   310}
    ,{   310,   230,   310,   310,   310}
    }
   ,{{   340,   220,   340,   230,   340}
    ,{   340,   220,   340,   210,   340}
    ,{   310,   170,   310,   180,   310}
    ,{   230,    40,   230,   230,   230}
    ,{   310,   170,   310,   180,   310}
    }
   ,{{   310,   230,   310,   180,   310}
    ,{   310,   170,   310,   180,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   170,   310,   180,   310}
    ,{   310,   230,   310,   180,   310}
    }
   ,{{   310,   170,   310,   310,   310}
    ,{   310,   170,   310,   310,   310}
    ,{   310,   170,   310,   180,   310}
    ,{   310,   170,   180,   310,   180}
    ,{   310,   170,   310,   180,   310}
    }
   ,{{   310,   230,   310,   310,   310}
    ,{   310,   170,   310,   180,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   170,   310,   180,   310}
    ,{   310,   170,   310,   310,   310}
    }
   }
  ,{{{   400,   340,   370,   340,   400}
    ,{   400,   340,   370,   340,   400}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   400,   340,   340,   340,   400}
    ,{   400,   340,   340,   340,   400}
    ,{   310,   310,   310,   310,   310}
    ,{   290,   230,   290,   230,   230}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   370,   310,   370,   310,   310}
    ,{   370,   310,   370,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   180,   180,   180,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   }
  }
 }
,{{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   240,   240,   220,   230,   220}
    ,{   240,   240,   220,   210,   220}
    ,{   230,   220,   210,   230,   210}
    ,{   240,   240,   220,   210,   220}
    ,{   210,   210,   190,   210,   190}
    }
   ,{{   200,   200,   180,   170,   180}
    ,{   200,   200,   180,   170,   180}
    ,{   190,   190,   180,   170,   180}
    ,{   140,   100,   140,    80,   140}
    ,{   190,   190,   180,   170,   180}
    }
   ,{{   240,   240,   220,   230,   220}
    ,{   240,   240,   220,   210,   220}
    ,{   230,   220,   210,   230,   210}
    ,{   240,   240,   220,   210,   220}
    ,{   210,   210,   190,   210,   190}
    }
   ,{{   190,   190,   180,   170,   180}
    ,{   140,   100,   140,    80,   140}
    ,{   190,   190,   180,   170,   180}
    ,{   130,    50,    30,   130,    70}
    ,{   190,   190,   180,   170,   180}
    }
   ,{{   240,   240,   220,   210,   220}
    ,{   240,   240,   220,   210,   220}
    ,{   210,   210,   190,   210,   190}
    ,{   240,   240,   220,   210,   220}
    ,{   180,   180,   100,    90,   100}
    }
   }
  ,{{{   240,   240,   220,   230,   220}
    ,{   240,   240,   220,   180,   220}
    ,{   230,   220,   210,   230,   210}
    ,{   240,   240,   220,   180,   220}
    ,{   210,   210,   190,   210,   190}
    }
   ,{{   200,   200,   180,   140,   180}
    ,{   200,   200,   180,   140,   180}
    ,{   190,   190,   180,   140,   180}
    ,{   100,   100,    90,    50,    90}
    ,{   190,   190,   180,   140,   180}
    }
   ,{{   240,   240,   220,   230,   220}
    ,{   240,   240,   220,   180,   220}
    ,{   230,   220,   210,   230,   210}
    ,{   240,   240,   220,   180,   220}
    ,{   210,   210,   190,   210,   190}
    }
   ,{{   190,   190,   180,   140,   180}
    ,{   100,   100,    90,    50,    90}
    ,{   190,   190,   180,   140,   180}
    ,{   120,    50,    30,   120,    30}
    ,{   190,   190,   180,   140,   180}
    }
   ,{{   240,   240,   220,   210,   220}
    ,{   240,   240,   220,   180,   220}
    ,{   210,   210,   190,   210,   190}
    ,{   240,   240,   220,   180,   220}
    ,{   180,   180,   100,    60,   100}
    }
   }
  ,{{{   220,   210,   220,   210,   220}
    ,{   220,   210,   220,   210,   220}
    ,{   200,   200,   200,   200,   200}
    ,{   220,   210,   220,   210,   220}
    ,{   190,   180,   190,   180,   190}
    }
   ,{{   180,   170,   180,   170,   180}
    ,{   180,   170,   180,   170,   180}
    ,{   170,   170,   170,   170,   170}
    ,{   140,    80,   140,    80,   140}
    ,{   170,   170,   170,   170,   170}
    }
   ,{{   220,   210,   220,   210,   220}
    ,{   220,   210,   220,   210,   220}
    ,{   200,   200,   200,   200,   200}
    ,{   220,   210,   220,   210,   220}
    ,{   190,   180,   190,   180,   190}
    }
   ,{{   170,   170,   170,   170,   170}
    ,{   140,    80,   140,    80,   140}
    ,{   170,   170,   170,   170,   170}
    ,{    30,    20,    30,    20,    30}
    ,{   170,   170,   170,   170,   170}
    }
   ,{{   220,   210,   220,   210,   220}
    ,{   220,   210,   220,   210,   220}
    ,{   190,   180,   190,   180,   190}
    ,{   220,   210,   220,   210,   220}
    ,{   100,    90,   100,    90,   100}
    }
   }
  ,{{{   220,   160,   220,   130,   220}
    ,{   220,   110,   220,    60,   220}
    ,{   210,   160,   210,    50,   210}
    ,{   220,   110,   220,   130,   220}
    ,{   190,   140,   190,    70,   190}
    }
   ,{{   180,    70,   180,    60,   180}
    ,{   180,    70,   180,    20,   180}
    ,{   180,    70,   180,    20,   180}
    ,{    90,   -20,    90,    60,    90}
    ,{   180,    70,   180,    20,   180}
    }
   ,{{   220,   160,   220,    60,   220}
    ,{   220,   110,   220,    60,   220}
    ,{   210,   160,   210,    50,   210}
    ,{   220,   110,   220,    60,   220}
    ,{   190,   140,   190,    30,   190}
    }
   ,{{   180,    70,   180,   130,   180}
    ,{    90,   -20,    90,    60,    90}
    ,{   180,    70,   180,    20,   180}
    ,{   130,    50,    30,   130,    30}
    ,{   180,    70,   180,    20,   180}
    }
   ,{{   220,   140,   220,    70,   220}
    ,{   220,   110,   220,    60,   220}
    ,{   190,   140,   190,    30,   190}
    ,{   220,   110,   220,    60,   220}
    ,{   100,     0,   100,    70,   100}
    }
   }
  ,{{{   220,   210,   220,   210,   150}
    ,{   220,   210,   220,   210,   150}
    ,{   200,   200,   200,   200,   110}
    ,{   220,   210,   220,   210,   130}
    ,{   190,   180,   190,   180,   100}
    }
   ,{{   180,   170,   180,   170,   150}
    ,{   180,   170,   180,   170,   150}
    ,{   170,   170,   170,   170,    80}
    ,{   140,    80,   140,    80,     0}
    ,{   170,   170,   170,   170,    80}
    }
   ,{{   220,   210,   220,   210,   130}
    ,{   220,   210,   220,   210,   130}
    ,{   200,   200,   200,   200,   110}
    ,{   220,   210,   220,   210,   130}
    ,{   190,   180,   190,   180,   100}
    }
   ,{{   170,   170,   170,   170,    80}
    ,{   140,    80,   140,    80,     0}
    ,{   170,   170,   170,   170,    80}
    ,{    70,    20,    30,    20,    70}
    ,{   170,   170,   170,   170,    80}
    }
   ,{{   220,   210,   220,   210,   130}
    ,{   220,   210,   220,   210,   130}
    ,{   190,   180,   190,   180,   100}
    ,{   220,   210,   220,   210,   130}
    ,{   100,    90,   100,    90,    10}
    }
   }
  }
 ,{{{{   210,   210,   200,   200,   200}
    ,{   210,   210,   200,   190,   200}
    ,{   200,   190,   180,   200,   180}
    ,{   180,   180,   170,   160,   170}
    ,{   190,   190,   170,   190,   170}
    }
   ,{{   210,   210,   200,   190,   200}
    ,{   210,   210,   200,   190,   200}
    ,{   190,   190,   170,   160,   170}
    ,{    50,    10,    50,   -10,    50}
    ,{   190,   190,   170,   160,   170}
    }
   ,{{   190,   190,   170,   190,   170}
    ,{   180,   180,   170,   160,   170}
    ,{   190,   190,   170,   190,   170}
    ,{   180,   180,   170,   160,   170}
    ,{   190,   190,   170,   190,   170}
    }
   ,{{   190,   190,   170,   160,   170}
    ,{   110,    70,   110,    50,   110}
    ,{   190,   190,   170,   160,   170}
    ,{   130,    50,    30,   130,    70}
    ,{   190,   190,   170,   160,   170}
    }
   ,{{   200,   190,   180,   200,   180}
    ,{   180,   180,   170,   160,   170}
    ,{   200,   190,   180,   200,   180}
    ,{   180,   180,   170,   160,   170}
    ,{   170,   170,   100,    90,   100}
    }
   }
  ,{{{   210,   210,   200,   200,   200}
    ,{   210,   210,   200,   160,   200}
    ,{   200,   190,   180,   200,   180}
    ,{   180,   180,   170,   130,   170}
    ,{   190,   190,   170,   190,   170}
    }
   ,{{   210,   210,   200,   160,   200}
    ,{   210,   210,   200,   160,   200}
    ,{   190,   190,   170,   130,   170}
    ,{    10,    10,     0,   -40,     0}
    ,{   190,   190,   170,   130,   170}
    }
   ,{{   190,   190,   170,   190,   170}
    ,{   180,   180,   170,   130,   170}
    ,{   190,   190,   170,   190,   170}
    ,{   180,   180,   170,   130,   170}
    ,{   190,   190,   170,   190,   170}
    }
   ,{{   190,   190,   170,   130,   170}
    ,{    70,    70,    60,    20,    60}
    ,{   190,   190,   170,   130,   170}
    ,{   120,    50,    30,   120,    30}
    ,{   190,   190,   170,   130,   170}
    }
   ,{{   200,   190,   180,   200,   180}
    ,{   180,   180,   170,   130,   170}
    ,{   200,   190,   180,   200,   180}
    ,{   180,   180,   170,   130,   170}
    ,{   170,   170,   100,    60,   100}
    }
   }
  ,{{{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    ,{   170,   170,   170,   170,   170}
    ,{   160,   160,   160,   160,   160}
    ,{   170,   160,   170,   160,   170}
    }
   ,{{   190,   190,   190,   190,   190}
    ,{   190,   190,   190,   190,   190}
    ,{   170,   160,   170,   160,   170}
    ,{    50,   -10,    50,   -10,    50}
    ,{   170,   160,   170,   160,   170}
    }
   ,{{   170,   160,   170,   160,   170}
    ,{   160,   160,   160,   160,   160}
    ,{   170,   160,   170,   160,   170}
    ,{   160,   160,   160,   160,   160}
    ,{   170,   160,   170,   160,   170}
    }
   ,{{   170,   160,   170,   160,   170}
    ,{   110,    50,   110,    50,   110}
    ,{   170,   160,   170,   160,   170}
    ,{    30,    20,    30,    20,    30}
    ,{   170,   160,   170,   160,   170}
    }
   ,{{   170,   170,   170,   170,   170}
    ,{   160,   160,   160,   160,   160}
    ,{   170,   170,   170,   170,   170}
    ,{   160,   160,   160,   160,   160}
    ,{    90,    90,    90,    90,    90}
    }
   }
  ,{{{   200,   130,   200,   130,   200}
    ,{   200,    90,   200,    40,   200}
    ,{   180,   130,   180,    20,   180}
    ,{   170,    60,   170,   130,   170}
    ,{   170,   120,   170,    70,   170}
    }
   ,{{   200,    90,   200,    40,   200}
    ,{   200,    90,   200,    40,   200}
    ,{   170,    60,   170,    10,   170}
    ,{     0,  -110,     0,   -30,     0}
    ,{   170,    60,   170,    10,   170}
    }
   ,{{   170,   120,   170,    10,   170}
    ,{   170,    60,   170,    10,   170}
    ,{   170,   120,   170,    10,   170}
    ,{   170,    60,   170,    10,   170}
    ,{   170,   120,   170,    10,   170}
    }
   ,{{   170,    60,   170,   130,   170}
    ,{    60,   -50,    60,    30,    60}
    ,{   170,    60,   170,    10,   170}
    ,{   130,    50,    30,   130,    30}
    ,{   170,    60,   170,    10,   170}
    }
   ,{{   180,   130,   180,    70,   180}
    ,{   170,    60,   170,    10,   170}
    ,{   180,   130,   180,    20,   180}
    ,{   170,    60,   170,    10,   170}
    ,{   100,   -10,   100,    70,   100}
    }
   }
  ,{{{   190,   190,   190,   190,   160}
    ,{   190,   190,   190,   190,   160}
    ,{   170,   170,   170,   170,    80}
    ,{   160,   160,   160,   160,    70}
    ,{   170,   160,   170,   160,    80}
    }
   ,{{   190,   190,   190,   190,   160}
    ,{   190,   190,   190,   190,   160}
    ,{   170,   160,   170,   160,    80}
    ,{    50,   -10,    50,   -10,  -100}
    ,{   170,   160,   170,   160,    80}
    }
   ,{{   170,   160,   170,   160,    80}
    ,{   160,   160,   160,   160,    70}
    ,{   170,   160,   170,   160,    80}
    ,{   160,   160,   160,   160,    70}
    ,{   170,   160,   170,   160,    80}
    }
   ,{{   170,   160,   170,   160,    80}
    ,{   110,    50,   110,    50,   -30}
    ,{   170,   160,   170,   160,    80}
    ,{    70,    20,    30,    20,    70}
    ,{   170,   160,   170,   160,    80}
    }
   ,{{   170,   170,   170,   170,    80}
    ,{   160,   160,   160,   160,    70}
    ,{   170,   170,   170,   170,    80}
    ,{   160,   160,   160,   160,    70}
    ,{    90,    90,    90,    90,     0}
    }
   }
  }
 ,{{{{   370,   370,   330,   320,   330}
    ,{   340,   340,   330,   320,   330}
    ,{   310,   310,   290,   310,   290}
    ,{   310,   310,   290,   280,   290}
    ,{   370,   370,   290,   310,   290}
    }
   ,{{   340,   340,   330,   320,   330}
    ,{   340,   340,   330,   320,   330}
    ,{   310,   310,   290,   280,   290}
    ,{   270,   230,   270,   200,   270}
    ,{   310,   310,   290,   280,   290}
    }
   ,{{   310,   310,   290,   310,   290}
    ,{   310,   310,   290,   280,   290}
    ,{   310,   310,   290,   310,   290}
    ,{   310,   310,   290,   280,   290}
    ,{   310,   310,   290,   310,   290}
    }
   ,{{   310,   310,   310,   280,   310}
    ,{   310,   270,   310,   240,   310}
    ,{   310,   310,   290,   280,   290}
    ,{   260,   180,   160,   260,   200}
    ,{   310,   310,   290,   280,   290}
    }
   ,{{   370,   370,   290,   310,   290}
    ,{   310,   310,   290,   280,   290}
    ,{   310,   310,   290,   310,   290}
    ,{   310,   310,   290,   280,   290}
    ,{   370,   370,   290,   280,   290}
    }
   }
  ,{{{   370,   370,   330,   310,   330}
    ,{   340,   340,   330,   290,   330}
    ,{   310,   310,   290,   310,   290}
    ,{   310,   310,   290,   250,   290}
    ,{   370,   370,   290,   310,   290}
    }
   ,{{   340,   340,   330,   290,   330}
    ,{   340,   340,   330,   290,   330}
    ,{   310,   310,   290,   250,   290}
    ,{   230,   230,   210,   170,   210}
    ,{   310,   310,   290,   250,   290}
    }
   ,{{   310,   310,   290,   310,   290}
    ,{   310,   310,   290,   250,   290}
    ,{   310,   310,   290,   310,   290}
    ,{   310,   310,   290,   250,   290}
    ,{   310,   310,   290,   310,   290}
    }
   ,{{   310,   310,   290,   250,   290}
    ,{   270,   270,   250,   210,   250}
    ,{   310,   310,   290,   250,   290}
    ,{   250,   180,   160,   250,   160}
    ,{   310,   310,   290,   250,   290}
    }
   ,{{   370,   370,   290,   310,   290}
    ,{   310,   310,   290,   250,   290}
    ,{   310,   310,   290,   310,   290}
    ,{   310,   310,   290,   250,   290}
    ,{   370,   370,   290,   250,   290}
    }
   }
  ,{{{   320,   320,   320,   320,   320}
    ,{   320,   320,   320,   320,   320}
    ,{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    }
   ,{{   320,   320,   320,   320,   320}
    ,{   320,   320,   320,   320,   320}
    ,{   290,   280,   290,   280,   290}
    ,{   270,   200,   270,   200,   270}
    ,{   290,   280,   290,   280,   290}
    }
   ,{{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    }
   ,{{   310,   280,   310,   280,   310}
    ,{   310,   240,   310,   240,   310}
    ,{   290,   280,   290,   280,   290}
    ,{   160,   150,   160,   150,   160}
    ,{   290,   280,   290,   280,   290}
    }
   ,{{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    }
   }
  ,{{{   330,   240,   330,   260,   330}
    ,{   330,   220,   330,   220,   330}
    ,{   290,   240,   290,   130,   290}
    ,{   290,   180,   290,   260,   290}
    ,{   290,   240,   290,   260,   290}
    }
   ,{{   330,   220,   330,   180,   330}
    ,{   330,   220,   330,   170,   330}
    ,{   290,   180,   290,   130,   290}
    ,{   210,   100,   210,   180,   210}
    ,{   290,   180,   290,   130,   290}
    }
   ,{{   290,   240,   290,   130,   290}
    ,{   290,   180,   290,   130,   290}
    ,{   290,   240,   290,   130,   290}
    ,{   290,   180,   290,   130,   290}
    ,{   290,   240,   290,   130,   290}
    }
   ,{{   290,   180,   290,   260,   290}
    ,{   250,   140,   250,   220,   250}
    ,{   290,   180,   290,   130,   290}
    ,{   260,   180,   160,   260,   160}
    ,{   290,   180,   290,   130,   290}
    }
   ,{{   290,   240,   290,   260,   290}
    ,{   290,   180,   290,   130,   290}
    ,{   290,   240,   290,   130,   290}
    ,{   290,   180,   290,   130,   290}
    ,{   290,   180,   290,   260,   290}
    }
   }
  ,{{{   320,   320,   320,   320,   290}
    ,{   320,   320,   320,   320,   290}
    ,{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    }
   ,{{   320,   320,   320,   320,   290}
    ,{   320,   320,   320,   320,   290}
    ,{   290,   280,   290,   280,   200}
    ,{   270,   200,   270,   200,   120}
    ,{   290,   280,   290,   280,   200}
    }
   ,{{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    }
   ,{{   310,   280,   310,   280,   200}
    ,{   310,   240,   310,   240,   160}
    ,{   290,   280,   290,   280,   200}
    ,{   200,   150,   160,   150,   200}
    ,{   290,   280,   290,   280,   200}
    }
   ,{{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    }
   }
  }
 ,{{{{   350,   340,   350,   280,   350}
    ,{   350,   310,   350,   280,   350}
    ,{   280,   280,   260,   280,   260}
    ,{   280,   280,   260,   250,   260}
    ,{   340,   340,   260,   280,   260}
    }
   ,{{   280,   280,   260,   250,   260}
    ,{   240,   240,   230,   220,   230}
    ,{   280,   280,   260,   250,   260}
    ,{   180,   140,   180,   120,   180}
    ,{   280,   280,   260,   250,   260}
    }
   ,{{   280,   280,   260,   280,   260}
    ,{   280,   280,   260,   250,   260}
    ,{   280,   280,   260,   280,   260}
    ,{   280,   280,   260,   250,   260}
    ,{   280,   280,   260,   280,   260}
    }
   ,{{   350,   310,   350,   280,   350}
    ,{   350,   310,   350,   280,   350}
    ,{   280,   280,   260,   250,   260}
    ,{   230,   150,   130,   230,   170}
    ,{   280,   280,   260,   250,   260}
    }
   ,{{   340,   340,   260,   280,   260}
    ,{   280,   280,   260,   250,   260}
    ,{   280,   280,   260,   280,   260}
    ,{   280,   280,   260,   250,   260}
    ,{   340,   340,   260,   250,   260}
    }
   }
  ,{{{   340,   340,   290,   280,   290}
    ,{   310,   310,   290,   250,   290}
    ,{   280,   280,   260,   280,   260}
    ,{   280,   280,   260,   220,   260}
    ,{   340,   340,   260,   280,   260}
    }
   ,{{   280,   280,   260,   220,   260}
    ,{   240,   240,   230,   190,   230}
    ,{   280,   280,   260,   220,   260}
    ,{   140,   140,   130,    90,   130}
    ,{   280,   280,   260,   220,   260}
    }
   ,{{   280,   280,   260,   280,   260}
    ,{   280,   280,   260,   220,   260}
    ,{   280,   280,   260,   280,   260}
    ,{   280,   280,   260,   220,   260}
    ,{   280,   280,   260,   280,   260}
    }
   ,{{   310,   310,   290,   250,   290}
    ,{   310,   310,   290,   250,   290}
    ,{   280,   280,   260,   220,   260}
    ,{   220,   150,   130,   220,   130}
    ,{   280,   280,   260,   220,   260}
    }
   ,{{   340,   340,   260,   280,   260}
    ,{   280,   280,   260,   220,   260}
    ,{   280,   280,   260,   280,   260}
    ,{   280,   280,   260,   220,   260}
    ,{   340,   340,   260,   220,   260}
    }
   }
  ,{{{   350,   280,   350,   280,   350}
    ,{   350,   280,   350,   280,   350}
    ,{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    }
   ,{{   260,   250,   260,   250,   260}
    ,{   220,   220,   220,   220,   220}
    ,{   260,   250,   260,   250,   260}
    ,{   180,   120,   180,   120,   180}
    ,{   260,   250,   260,   250,   260}
    }
   ,{{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    }
   ,{{   350,   280,   350,   280,   350}
    ,{   350,   280,   350,   280,   350}
    ,{   260,   250,   260,   250,   260}
    ,{   130,   120,   130,   120,   130}
    ,{   260,   250,   260,   250,   260}
    }
   ,{{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    }
   }
  ,{{{   290,   210,   290,   260,   290}
    ,{   290,   180,   290,   260,   290}
    ,{   260,   210,   260,   100,   260}
    ,{   260,   150,   260,   230,   260}
    ,{   260,   210,   260,   230,   260}
    }
   ,{{   260,   150,   260,   100,   260}
    ,{   230,   120,   230,    70,   230}
    ,{   260,   150,   260,   100,   260}
    ,{   130,    20,   130,   100,   130}
    ,{   260,   150,   260,   100,   260}
    }
   ,{{   260,   210,   260,   100,   260}
    ,{   260,   150,   260,   100,   260}
    ,{   260,   210,   260,   100,   260}
    ,{   260,   150,   260,   100,   260}
    ,{   260,   210,   260,   100,   260}
    }
   ,{{   290,   180,   290,   260,   290}
    ,{   290,   180,   290,   260,   290}
    ,{   260,   150,   260,   100,   260}
    ,{   230,   150,   130,   230,   130}
    ,{   260,   150,   260,   100,   260}
    }
   ,{{   260,   210,   260,   230,   260}
    ,{   260,   150,   260,   100,   260}
    ,{   260,   210,   260,   100,   260}
    ,{   260,   150,   260,   100,   260}
    ,{   260,   150,   260,   230,   260}
    }
   }
  ,{{{   350,   280,   350,   280,   200}
    ,{   350,   280,   350,   280,   200}
    ,{   260,   250,   260,   250,   170}
    ,{   260,   250,   260,   250,   170}
    ,{   260,   250,   260,   250,   170}
    }
   ,{{   260,   250,   260,   250,   190}
    ,{   220,   220,   220,   220,   190}
    ,{   260,   250,   260,   250,   170}
    ,{   180,   120,   180,   120,    30}
    ,{   260,   250,   260,   250,   170}
    }
   ,{{   260,   250,   260,   250,   170}
    ,{   260,   250,   260,   250,   170}
    ,{   260,   250,   260,   250,   170}
    ,{   260,   250,   260,   250,   170}
    ,{   260,   250,   260,   250,   170}
    }
   ,{{   350,   280,   350,   280,   200}
    ,{   350,   280,   350,   280,   200}
    ,{   260,   250,   260,   250,   170}
    ,{   170,   120,   130,   120,   170}
    ,{   260,   250,   260,   250,   170}
    }
   ,{{   260,   250,   260,   250,   170}
    ,{   260,   250,   260,   250,   170}
    ,{   260,   250,   260,   250,   170}
    ,{   260,   250,   260,   250,   170}
    ,{   260,   250,   260,   250,   170}
    }
   }
  }
 ,{{{{   280,   280,   260,   260,   260}
    ,{   280,   280,   260,   250,   260}
    ,{   260,   260,   240,   260,   240}
    ,{   260,   260,   250,   240,   250}
    ,{   260,   260,   240,   260,   240}
    }
   ,{{   280,   280,   260,   250,   260}
    ,{   280,   280,   260,   250,   260}
    ,{   250,   250,   240,   230,   240}
    ,{   190,   150,   190,   130,   190}
    ,{   250,   250,   240,   230,   240}
    }
   ,{{   260,   260,   250,   260,   250}
    ,{   260,   260,   250,   240,   250}
    ,{   260,   260,   240,   260,   240}
    ,{   260,   260,   250,   240,   250}
    ,{   260,   260,   240,   260,   240}
    }
   ,{{   260,   250,   260,   230,   260}
    ,{   260,   220,   260,   200,   260}
    ,{   250,   250,   240,   230,   240}
    ,{   190,   110,    90,   190,   120}
    ,{   250,   250,   240,   230,   240}
    }
   ,{{   260,   260,   250,   260,   250}
    ,{   260,   260,   250,   240,   250}
    ,{   260,   260,   240,   260,   240}
    ,{   260,   260,   250,   240,   250}
    ,{   230,   230,   150,   140,   150}
    }
   }
  ,{{{   280,   280,   260,   260,   260}
    ,{   280,   280,   260,   220,   260}
    ,{   260,   260,   240,   260,   240}
    ,{   260,   260,   250,   210,   250}
    ,{   260,   260,   240,   260,   240}
    }
   ,{{   280,   280,   260,   220,   260}
    ,{   280,   280,   260,   220,   260}
    ,{   250,   250,   240,   200,   240}
    ,{   150,   150,   140,   100,   140}
    ,{   250,   250,   240,   200,   240}
    }
   ,{{   260,   260,   250,   260,   250}
    ,{   260,   260,   250,   210,   250}
    ,{   260,   260,   240,   260,   240}
    ,{   260,   260,   250,   210,   250}
    ,{   260,   260,   240,   260,   240}
    }
   ,{{   250,   250,   240,   200,   240}
    ,{   220,   220,   210,   170,   210}
    ,{   250,   250,   240,   200,   240}
    ,{   180,   100,    90,   180,    90}
    ,{   250,   250,   240,   200,   240}
    }
   ,{{   260,   260,   250,   260,   250}
    ,{   260,   260,   250,   210,   250}
    ,{   260,   260,   240,   260,   240}
    ,{   260,   260,   250,   210,   250}
    ,{   230,   230,   150,   110,   150}
    }
   }
  ,{{{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    ,{   240,   230,   240,   230,   240}
    ,{   240,   240,   240,   240,   240}
    ,{   240,   230,   240,   230,   240}
    }
   ,{{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    ,{   230,   230,   230,   230,   230}
    ,{   190,   130,   190,   130,   190}
    ,{   230,   230,   230,   230,   230}
    }
   ,{{   240,   240,   240,   240,   240}
    ,{   240,   240,   240,   240,   240}
    ,{   240,   230,   240,   230,   240}
    ,{   240,   240,   240,   240,   240}
    ,{   240,   230,   240,   230,   240}
    }
   ,{{   260,   230,   260,   230,   260}
    ,{   260,   200,   260,   200,   260}
    ,{   230,   230,   230,   230,   230}
    ,{    80,    80,    80,    80,    80}
    ,{   230,   230,   230,   230,   230}
    }
   ,{{   240,   240,   240,   240,   240}
    ,{   240,   240,   240,   240,   240}
    ,{   240,   230,   240,   230,   240}
    ,{   240,   240,   240,   240,   240}
    ,{   150,   140,   150,   140,   150}
    }
   }
  ,{{{   260,   190,   260,   190,   260}
    ,{   260,   150,   260,   180,   260}
    ,{   240,   190,   240,    80,   240}
    ,{   250,   140,   250,   190,   250}
    ,{   240,   190,   240,   120,   240}
    }
   ,{{   260,   150,   260,   110,   260}
    ,{   260,   150,   260,   100,   260}
    ,{   240,   130,   240,    80,   240}
    ,{   140,    30,   140,   110,   140}
    ,{   240,   130,   240,    80,   240}
    }
   ,{{   250,   190,   250,    90,   250}
    ,{   250,   140,   250,    90,   250}
    ,{   240,   190,   240,    80,   240}
    ,{   250,   140,   250,    90,   250}
    ,{   240,   190,   240,    80,   240}
    }
   ,{{   240,   130,   240,   190,   240}
    ,{   210,   100,   210,   180,   210}
    ,{   240,   130,   240,    80,   240}
    ,{   190,   110,    90,   190,    90}
    ,{   240,   130,   240,    80,   240}
    }
   ,{{   250,   190,   250,   120,   250}
    ,{   250,   140,   250,    90,   250}
    ,{   240,   190,   240,    80,   240}
    ,{   250,   140,   250,    90,   250}
    ,{   150,    40,   150,   120,   150}
    }
   }
  ,{{{   260,   250,   260,   250,   230}
    ,{   260,   250,   260,   250,   230}
    ,{   240,   230,   240,   230,   150}
    ,{   240,   240,   240,   240,   150}
    ,{   240,   230,   240,   230,   150}
    }
   ,{{   260,   250,   260,   250,   230}
    ,{   260,   250,   260,   250,   230}
    ,{   230,   230,   230,   230,   140}
    ,{   190,   130,   190,   130,    40}
    ,{   230,   230,   230,   230,   140}
    }
   ,{{   240,   240,   240,   240,   150}
    ,{   240,   240,   240,   240,   150}
    ,{   240,   230,   240,   230,   150}
    ,{   240,   240,   240,   240,   150}
    ,{   240,   230,   240,   230,   150}
    }
   ,{{   260,   230,   260,   230,   140}
    ,{   260,   200,   260,   200,   110}
    ,{   230,   230,   230,   230,   140}
    ,{   120,    80,    80,    80,   120}
    ,{   230,   230,   230,   230,   140}
    }
   ,{{   240,   240,   240,   240,   150}
    ,{   240,   240,   240,   240,   150}
    ,{   240,   230,   240,   230,   150}
    ,{   240,   240,   240,   240,   150}
    ,{   150,   140,   150,   140,    60}
    }
   }
  }
 ,{{{{   280,   280,   260,   280,   260}
    ,{   280,   280,   260,   250,   260}
    ,{   280,   280,   260,   280,   260}
    ,{   280,   280,   260,   250,   260}
    ,{   280,   280,   260,   280,   260}
    }
   ,{{   280,   280,   260,   250,   260}
    ,{   280,   280,   260,   250,   260}
    ,{   230,   230,   220,   210,   220}
    ,{   210,   170,   210,   150,   210}
    ,{   230,   230,   220,   210,   220}
    }
   ,{{   280,   280,   260,   280,   260}
    ,{   280,   280,   260,   250,   260}
    ,{   280,   280,   260,   280,   260}
    ,{   280,   280,   260,   250,   260}
    ,{   280,   280,   260,   280,   260}
    }
   ,{{   230,   230,   220,   210,   220}
    ,{   220,   180,   220,   160,   220}
    ,{   230,   230,   220,   210,   220}
    ,{   210,   130,   110,   210,   140}
    ,{   230,   230,   220,   210,   220}
    }
   ,{{   280,   280,   260,   250,   260}
    ,{   280,   280,   260,   250,   260}
    ,{   250,   250,   230,   250,   230}
    ,{   280,   280,   260,   250,   260}
    ,{   250,   250,   180,   170,   180}
    }
   }
  ,{{{   280,   280,   260,   280,   260}
    ,{   280,   280,   260,   220,   260}
    ,{   280,   280,   260,   280,   260}
    ,{   280,   280,   260,   220,   260}
    ,{   280,   280,   260,   280,   260}
    }
   ,{{   280,   280,   260,   220,   260}
    ,{   280,   280,   260,   220,   260}
    ,{   230,   230,   220,   180,   220}
    ,{   170,   170,   160,   120,   160}
    ,{   230,   230,   220,   180,   220}
    }
   ,{{   280,   280,   260,   280,   260}
    ,{   280,   280,   260,   220,   260}
    ,{   280,   280,   260,   280,   260}
    ,{   280,   280,   260,   220,   260}
    ,{   280,   280,   260,   280,   260}
    }
   ,{{   230,   230,   220,   200,   220}
    ,{   180,   180,   170,   130,   170}
    ,{   230,   230,   220,   180,   220}
    ,{   200,   120,   110,   200,   110}
    ,{   230,   230,   220,   180,   220}
    }
   ,{{   280,   280,   260,   250,   260}
    ,{   280,   280,   260,   220,   260}
    ,{   250,   250,   230,   250,   230}
    ,{   280,   280,   260,   220,   260}
    ,{   250,   250,   180,   140,   180}
    }
   }
  ,{{{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    }
   ,{{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    ,{   210,   210,   210,   210,   210}
    ,{   210,   150,   210,   150,   210}
    ,{   210,   210,   210,   210,   210}
    }
   ,{{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    }
   ,{{   220,   210,   220,   210,   220}
    ,{   220,   160,   220,   160,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   100,   100,   100,   100,   100}
    ,{   210,   210,   210,   210,   210}
    }
   ,{{   260,   250,   260,   250,   260}
    ,{   260,   250,   260,   250,   260}
    ,{   230,   220,   230,   220,   230}
    ,{   260,   250,   260,   250,   260}
    ,{   170,   170,   170,   170,   170}
    }
   }
  ,{{{   260,   210,   260,   210,   260}
    ,{   260,   150,   260,   140,   260}
    ,{   260,   210,   260,   100,   260}
    ,{   260,   150,   260,   210,   260}
    ,{   260,   210,   260,   150,   260}
    }
   ,{{   260,   150,   260,   130,   260}
    ,{   260,   150,   260,   100,   260}
    ,{   220,   110,   220,    60,   220}
    ,{   160,    50,   160,   130,   160}
    ,{   220,   110,   220,    60,   220}
    }
   ,{{   260,   210,   260,   100,   260}
    ,{   260,   150,   260,   100,   260}
    ,{   260,   210,   260,   100,   260}
    ,{   260,   150,   260,   100,   260}
    ,{   260,   210,   260,   100,   260}
    }
   ,{{   220,   130,   220,   210,   220}
    ,{   170,    60,   170,   140,   170}
    ,{   220,   110,   220,    60,   220}
    ,{   210,   130,   110,   210,   110}
    ,{   220,   110,   220,    60,   220}
    }
   ,{{   260,   180,   260,   150,   260}
    ,{   260,   150,   260,   100,   260}
    ,{   230,   180,   230,    70,   230}
    ,{   260,   150,   260,   100,   260}
    ,{   180,    70,   180,   150,   180}
    }
   }
  ,{{{   260,   250,   260,   250,   230}
    ,{   260,   250,   260,   250,   230}
    ,{   260,   250,   260,   250,   170}
    ,{   260,   250,   260,   250,   170}
    ,{   260,   250,   260,   250,   170}
    }
   ,{{   260,   250,   260,   250,   230}
    ,{   260,   250,   260,   250,   230}
    ,{   210,   210,   210,   210,   120}
    ,{   210,   150,   210,   150,    60}
    ,{   210,   210,   210,   210,   120}
    }
   ,{{   260,   250,   260,   250,   170}
    ,{   260,   250,   260,   250,   170}
    ,{   260,   250,   260,   250,   170}
    ,{   260,   250,   260,   250,   170}
    ,{   260,   250,   260,   250,   170}
    }
   ,{{   220,   210,   220,   210,   140}
    ,{   220,   160,   220,   160,    70}
    ,{   210,   210,   210,   210,   120}
    ,{   140,   100,   100,   100,   140}
    ,{   210,   210,   210,   210,   120}
    }
   ,{{   260,   250,   260,   250,   170}
    ,{   260,   250,   260,   250,   170}
    ,{   230,   220,   230,   220,   140}
    ,{   260,   250,   260,   250,   170}
    ,{   170,   170,   170,   170,    80}
    }
   }
  }
 ,{{{{   370,   370,   350,   320,   350}
    ,{   350,   340,   350,   320,   350}
    ,{   310,   310,   290,   310,   290}
    ,{   310,   310,   290,   280,   290}
    ,{   370,   370,   290,   310,   290}
    }
   ,{{   340,   340,   330,   320,   330}
    ,{   340,   340,   330,   320,   330}
    ,{   310,   310,   290,   280,   290}
    ,{   270,   230,   270,   200,   270}
    ,{   310,   310,   290,   280,   290}
    }
   ,{{   310,   310,   290,   310,   290}
    ,{   310,   310,   290,   280,   290}
    ,{   310,   310,   290,   310,   290}
    ,{   310,   310,   290,   280,   290}
    ,{   310,   310,   290,   310,   290}
    }
   ,{{   350,   310,   350,   280,   350}
    ,{   350,   310,   350,   280,   350}
    ,{   310,   310,   290,   280,   290}
    ,{   260,   180,   160,   260,   200}
    ,{   310,   310,   290,   280,   290}
    }
   ,{{   370,   370,   290,   310,   290}
    ,{   310,   310,   290,   280,   290}
    ,{   310,   310,   290,   310,   290}
    ,{   310,   310,   290,   280,   290}
    ,{   370,   370,   290,   280,   290}
    }
   }
  ,{{{   370,   370,   330,   310,   330}
    ,{   340,   340,   330,   290,   330}
    ,{   310,   310,   290,   310,   290}
    ,{   310,   310,   290,   250,   290}
    ,{   370,   370,   290,   310,   290}
    }
   ,{{   340,   340,   330,   290,   330}
    ,{   340,   340,   330,   290,   330}
    ,{   310,   310,   290,   250,   290}
    ,{   230,   230,   210,   170,   210}
    ,{   310,   310,   290,   250,   290}
    }
   ,{{   310,   310,   290,   310,   290}
    ,{   310,   310,   290,   250,   290}
    ,{   310,   310,   290,   310,   290}
    ,{   310,   310,   290,   250,   290}
    ,{   310,   310,   290,   310,   290}
    }
   ,{{   310,   310,   290,   250,   290}
    ,{   310,   310,   290,   250,   290}
    ,{   310,   310,   290,   250,   290}
    ,{   250,   180,   160,   250,   160}
    ,{   310,   310,   290,   250,   290}
    }
   ,{{   370,   370,   290,   310,   290}
    ,{   310,   310,   290,   250,   290}
    ,{   310,   310,   290,   310,   290}
    ,{   310,   310,   290,   250,   290}
    ,{   370,   370,   290,   250,   290}
    }
   }
  ,{{{   350,   320,   350,   320,   350}
    ,{   350,   320,   350,   320,   350}
    ,{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    }
   ,{{   320,   320,   320,   320,   320}
    ,{   320,   320,   320,   320,   320}
    ,{   290,   280,   290,   280,   290}
    ,{   270,   200,   270,   200,   270}
    ,{   290,   280,   290,   280,   290}
    }
   ,{{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    }
   ,{{   350,   280,   350,   280,   350}
    ,{   350,   280,   350,   280,   350}
    ,{   290,   280,   290,   280,   290}
    ,{   160,   150,   160,   150,   160}
    ,{   290,   280,   290,   280,   290}
    }
   ,{{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    ,{   290,   280,   290,   280,   290}
    }
   }
  ,{{{   330,   240,   330,   260,   330}
    ,{   330,   220,   330,   260,   330}
    ,{   290,   240,   290,   130,   290}
    ,{   290,   180,   290,   260,   290}
    ,{   290,   240,   290,   260,   290}
    }
   ,{{   330,   220,   330,   180,   330}
    ,{   330,   220,   330,   170,   330}
    ,{   290,   180,   290,   130,   290}
    ,{   210,   100,   210,   180,   210}
    ,{   290,   180,   290,   130,   290}
    }
   ,{{   290,   240,   290,   130,   290}
    ,{   290,   180,   290,   130,   290}
    ,{   290,   240,   290,   130,   290}
    ,{   290,   180,   290,   130,   290}
    ,{   290,   240,   290,   130,   290}
    }
   ,{{   290,   180,   290,   260,   290}
    ,{   290,   180,   290,   260,   290}
    ,{   290,   180,   290,   130,   290}
    ,{   260,   180,   160,   260,   160}
    ,{   290,   180,   290,   130,   290}
    }
   ,{{   290,   240,   290,   260,   290}
    ,{   290,   180,   290,   130,   290}
    ,{   290,   240,   290,   130,   290}
    ,{   290,   180,   290,   130,   290}
    ,{   290,   180,   290,   260,   290}
    }
   }
  ,{{{   350,   320,   350,   320,   290}
    ,{   350,   320,   350,   320,   290}
    ,{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    }
   ,{{   320,   320,   320,   320,   290}
    ,{   320,   320,   320,   320,   290}
    ,{   290,   280,   290,   280,   200}
    ,{   270,   200,   270,   200,   120}
    ,{   290,   280,   290,   280,   200}
    }
   ,{{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    }
   ,{{   350,   280,   350,   280,   200}
    ,{   350,   280,   350,   280,   200}
    ,{   290,   280,   290,   280,   200}
    ,{   200,   150,   160,   150,   200}
    ,{   290,   280,   290,   280,   200}
    }
   ,{{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    ,{   290,   280,   290,   280,   200}
    }
   }
  }
 }
,{{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   240,   240,   240,   190,   240}
    ,{   240,   240,   240,   190,   240}
    ,{   220,   220,   220,   190,   220}
    ,{   240,   240,   240,   190,   240}
    ,{   210,   210,   210,   170,   210}
    }
   ,{{   200,   200,   200,   150,   200}
    ,{   200,   200,   200,   150,   200}
    ,{   190,   190,   190,   150,   190}
    ,{   160,   100,   160,    80,   130}
    ,{   190,   190,   190,   150,   190}
    }
   ,{{   240,   240,   240,   190,   240}
    ,{   240,   240,   240,   190,   240}
    ,{   220,   220,   220,   190,   220}
    ,{   240,   240,   240,   190,   240}
    ,{   210,   210,   210,   170,   210}
    }
   ,{{   190,   190,   190,   150,   190}
    ,{   160,   100,   160,    80,   130}
    ,{   190,   190,   190,   150,   190}
    ,{   150,    70,    50,   150,    90}
    ,{   190,   190,   190,   150,   190}
    }
   ,{{   240,   240,   240,   190,   240}
    ,{   240,   240,   240,   190,   240}
    ,{   210,   210,   210,   170,   210}
    ,{   240,   240,   240,   190,   240}
    ,{   180,   180,   120,    90,   120}
    }
   }
  ,{{{   240,   240,   240,   190,   240}
    ,{   240,   240,   240,   140,   240}
    ,{   220,   220,   220,   190,   220}
    ,{   240,   240,   240,   140,   240}
    ,{   210,   210,   210,   170,   210}
    }
   ,{{   200,   200,   200,   100,   200}
    ,{   200,   200,   200,   100,   200}
    ,{   190,   190,   190,   100,   190}
    ,{   100,   100,   100,    10,   100}
    ,{   190,   190,   190,   100,   190}
    }
   ,{{   240,   240,   240,   190,   240}
    ,{   240,   240,   240,   140,   240}
    ,{   220,   220,   220,   190,   220}
    ,{   240,   240,   240,   140,   240}
    ,{   210,   210,   210,   170,   210}
    }
   ,{{   190,   190,   190,   100,   190}
    ,{   100,   100,   100,    10,   100}
    ,{   190,   190,   190,   100,   190}
    ,{    80,    50,    50,    80,    50}
    ,{   190,   190,   190,   100,   190}
    }
   ,{{   240,   240,   240,   170,   240}
    ,{   240,   240,   240,   140,   240}
    ,{   210,   210,   210,   170,   210}
    ,{   240,   240,   240,   140,   240}
    ,{   180,   180,   120,    20,   120}
    }
   }
  ,{{{   240,   190,   240,   190,   210}
    ,{   240,   190,   240,   190,   210}
    ,{   220,   180,   220,   180,   190}
    ,{   240,   190,   240,   190,   210}
    ,{   210,   160,   210,   160,   180}
    }
   ,{{   200,   150,   200,   150,   170}
    ,{   200,   150,   200,   150,   170}
    ,{   190,   150,   190,   150,   160}
    ,{   160,    60,   160,    60,   130}
    ,{   190,   150,   190,   150,   160}
    }
   ,{{   240,   190,   240,   190,   210}
    ,{   240,   190,   240,   190,   210}
    ,{   220,   180,   220,   180,   190}
    ,{   240,   190,   240,   190,   210}
    ,{   210,   160,   210,   160,   180}
    }
   ,{{   190,   150,   190,   150,   160}
    ,{   160,    60,   160,    60,   130}
    ,{   190,   150,   190,   150,   160}
    ,{    50,     0,    50,     0,    20}
    ,{   190,   150,   190,   150,   160}
    }
   ,{{   240,   190,   240,   190,   210}
    ,{   240,   190,   240,   190,   210}
    ,{   210,   160,   210,   160,   180}
    ,{   240,   190,   240,   190,   210}
    ,{   120,    70,   120,    70,    90}
    }
   }
  ,{{{   240,   180,   240,   150,   240}
    ,{   240,   130,   240,    80,   240}
    ,{   220,   180,   220,    70,   220}
    ,{   240,   130,   240,   150,   240}
    ,{   210,   160,   210,    90,   210}
    }
   ,{{   200,    90,   200,    80,   200}
    ,{   200,    90,   200,    40,   200}
    ,{   190,    90,   190,    40,   190}
    ,{   100,     0,   100,    80,   100}
    ,{   190,    90,   190,    40,   190}
    }
   ,{{   240,   180,   240,    80,   240}
    ,{   240,   130,   240,    80,   240}
    ,{   220,   180,   220,    70,   220}
    ,{   240,   130,   240,    80,   240}
    ,{   210,   160,   210,    50,   210}
    }
   ,{{   190,    90,   190,   150,   190}
    ,{   100,     0,   100,    80,   100}
    ,{   190,    90,   190,    40,   190}
    ,{   150,    70,    50,   150,    50}
    ,{   190,    90,   190,    40,   190}
    }
   ,{{   240,   160,   240,    90,   240}
    ,{   240,   130,   240,    80,   240}
    ,{   210,   160,   210,    50,   210}
    ,{   240,   130,   240,    80,   240}
    ,{   120,    10,   120,    90,   120}
    }
   }
  ,{{{   240,   190,   240,   190,   170}
    ,{   240,   190,   240,   190,   170}
    ,{   220,   180,   220,   180,   140}
    ,{   240,   190,   240,   190,   150}
    ,{   210,   160,   210,   160,   120}
    }
   ,{{   200,   150,   200,   150,   170}
    ,{   200,   150,   200,   150,   170}
    ,{   190,   150,   190,   150,   110}
    ,{   160,    60,   160,    60,    20}
    ,{   190,   150,   190,   150,   110}
    }
   ,{{   240,   190,   240,   190,   150}
    ,{   240,   190,   240,   190,   150}
    ,{   220,   180,   220,   180,   140}
    ,{   240,   190,   240,   190,   150}
    ,{   210,   160,   210,   160,   120}
    }
   ,{{   190,   150,   190,   150,   110}
    ,{   160,    60,   160,    60,    20}
    ,{   190,   150,   190,   150,   110}
    ,{    90,     0,    50,     0,    90}
    ,{   190,   150,   190,   150,   110}
    }
   ,{{   240,   190,   240,   190,   150}
    ,{   240,   190,   240,   190,   150}
    ,{   210,   160,   210,   160,   120}
    ,{   240,   190,   240,   190,   150}
    ,{   120,    70,   120,    70,    30}
    }
   }
  }
 ,{{{{   210,   210,   210,   170,   210}
    ,{   210,   210,   210,   170,   210}
    ,{   190,   190,   190,   160,   190}
    ,{   180,   180,   180,   150,   180}
    ,{   190,   190,   190,   150,   190}
    }
   ,{{   210,   210,   210,   170,   210}
    ,{   210,   210,   210,   170,   210}
    ,{   190,   190,   190,   140,   190}
    ,{    70,    10,    70,   -10,    40}
    ,{   190,   190,   190,   140,   190}
    }
   ,{{   190,   190,   190,   150,   190}
    ,{   180,   180,   180,   140,   180}
    ,{   190,   190,   190,   150,   190}
    ,{   180,   180,   180,   140,   180}
    ,{   190,   190,   190,   150,   190}
    }
   ,{{   190,   190,   190,   150,   190}
    ,{   130,    70,   130,    50,   100}
    ,{   190,   190,   190,   140,   190}
    ,{   150,    70,    50,   150,    90}
    ,{   190,   190,   190,   140,   190}
    }
   ,{{   190,   190,   190,   160,   190}
    ,{   180,   180,   180,   140,   180}
    ,{   190,   190,   190,   160,   190}
    ,{   180,   180,   180,   140,   180}
    ,{   170,   170,   110,    90,   110}
    }
   }
  ,{{{   210,   210,   210,   160,   210}
    ,{   210,   210,   210,   120,   210}
    ,{   190,   190,   190,   160,   190}
    ,{   180,   180,   180,    90,   180}
    ,{   190,   190,   190,   150,   190}
    }
   ,{{   210,   210,   210,   120,   210}
    ,{   210,   210,   210,   120,   210}
    ,{   190,   190,   190,    90,   190}
    ,{    10,    10,    10,   -80,    10}
    ,{   190,   190,   190,    90,   190}
    }
   ,{{   190,   190,   190,   150,   190}
    ,{   180,   180,   180,    90,   180}
    ,{   190,   190,   190,   150,   190}
    ,{   180,   180,   180,    90,   180}
    ,{   190,   190,   190,   150,   190}
    }
   ,{{   190,   190,   190,    90,   190}
    ,{    70,    70,    70,   -20,    70}
    ,{   190,   190,   190,    90,   190}
    ,{    80,    50,    50,    80,    50}
    ,{   190,   190,   190,    90,   190}
    }
   ,{{   190,   190,   190,   160,   190}
    ,{   180,   180,   180,    90,   180}
    ,{   190,   190,   190,   160,   190}
    ,{   180,   180,   180,    90,   180}
    ,{   170,   170,   110,    20,   110}
    }
   }
  ,{{{   210,   170,   210,   170,   180}
    ,{   210,   170,   210,   170,   180}
    ,{   190,   150,   190,   150,   160}
    ,{   180,   140,   180,   140,   150}
    ,{   190,   140,   190,   140,   160}
    }
   ,{{   210,   170,   210,   170,   180}
    ,{   210,   170,   210,   170,   180}
    ,{   190,   140,   190,   140,   160}
    ,{    70,   -30,    70,   -30,    40}
    ,{   190,   140,   190,   140,   160}
    }
   ,{{   190,   140,   190,   140,   160}
    ,{   180,   140,   180,   140,   150}
    ,{   190,   140,   190,   140,   160}
    ,{   180,   140,   180,   140,   150}
    ,{   190,   140,   190,   140,   160}
    }
   ,{{   190,   140,   190,   140,   160}
    ,{   130,    30,   130,    30,   100}
    ,{   190,   140,   190,   140,   160}
    ,{    50,     0,    50,     0,    20}
    ,{   190,   140,   190,   140,   160}
    }
   ,{{   190,   150,   190,   150,   160}
    ,{   180,   140,   180,   140,   150}
    ,{   190,   150,   190,   150,   160}
    ,{   180,   140,   180,   140,   150}
    ,{   110,    70,   110,    70,    80}
    }
   }
  ,{{{   210,   150,   210,   150,   210}
    ,{   210,   110,   210,    60,   210}
    ,{   190,   150,   190,    40,   190}
    ,{   180,    80,   180,   150,   180}
    ,{   190,   140,   190,    90,   190}
    }
   ,{{   210,   110,   210,    60,   210}
    ,{   210,   110,   210,    60,   210}
    ,{   190,    80,   190,    30,   190}
    ,{    10,   -90,    10,   -10,    10}
    ,{   190,    80,   190,    30,   190}
    }
   ,{{   190,   140,   190,    30,   190}
    ,{   180,    80,   180,    30,   180}
    ,{   190,   140,   190,    30,   190}
    ,{   180,    80,   180,    30,   180}
    ,{   190,   140,   190,    30,   190}
    }
   ,{{   190,    80,   190,   150,   190}
    ,{    70,   -30,    70,    50,    70}
    ,{   190,    80,   190,    30,   190}
    ,{   150,    70,    50,   150,    50}
    ,{   190,    80,   190,    30,   190}
    }
   ,{{   190,   150,   190,    90,   190}
    ,{   180,    80,   180,    30,   180}
    ,{   190,   150,   190,    40,   190}
    ,{   180,    80,   180,    30,   180}
    ,{   110,    10,   110,    90,   110}
    }
   }
  ,{{{   210,   170,   210,   170,   190}
    ,{   210,   170,   210,   170,   190}
    ,{   190,   150,   190,   150,   110}
    ,{   180,   140,   180,   140,   100}
    ,{   190,   140,   190,   140,   100}
    }
   ,{{   210,   170,   210,   170,   190}
    ,{   210,   170,   210,   170,   190}
    ,{   190,   140,   190,   140,   100}
    ,{    70,   -30,    70,   -30,   -70}
    ,{   190,   140,   190,   140,   100}
    }
   ,{{   190,   140,   190,   140,   100}
    ,{   180,   140,   180,   140,   100}
    ,{   190,   140,   190,   140,   100}
    ,{   180,   140,   180,   140,   100}
    ,{   190,   140,   190,   140,   100}
    }
   ,{{   190,   140,   190,   140,   100}
    ,{   130,    30,   130,    30,   -10}
    ,{   190,   140,   190,   140,   100}
    ,{    90,     0,    50,     0,    90}
    ,{   190,   140,   190,   140,   100}
    }
   ,{{   190,   150,   190,   150,   110}
    ,{   180,   140,   180,   140,   100}
    ,{   190,   150,   190,   150,   110}
    ,{   180,   140,   180,   140,   100}
    ,{   110,    70,   110,    70,    30}
    }
   }
  }
 ,{{{{   370,   370,   340,   300,   340}
    ,{   340,   340,   340,   300,   340}
    ,{   310,   310,   310,   270,   310}
    ,{   310,   310,   310,   280,   310}
    ,{   370,   370,   310,   280,   310}
    }
   ,{{   340,   340,   340,   300,   340}
    ,{   340,   340,   340,   300,   340}
    ,{   310,   310,   310,   260,   310}
    ,{   290,   230,   290,   200,   260}
    ,{   310,   310,   310,   260,   310}
    }
   ,{{   310,   310,   310,   270,   310}
    ,{   310,   310,   310,   260,   310}
    ,{   310,   310,   310,   270,   310}
    ,{   310,   310,   310,   260,   310}
    ,{   310,   310,   310,   270,   310}
    }
   ,{{   330,   310,   330,   280,   310}
    ,{   330,   270,   330,   240,   300}
    ,{   310,   310,   310,   260,   310}
    ,{   280,   200,   180,   280,   220}
    ,{   310,   310,   310,   260,   310}
    }
   ,{{   370,   370,   310,   280,   310}
    ,{   310,   310,   310,   260,   310}
    ,{   310,   310,   310,   270,   310}
    ,{   310,   310,   310,   260,   310}
    ,{   370,   370,   310,   280,   310}
    }
   }
  ,{{{   370,   370,   340,   270,   340}
    ,{   340,   340,   340,   250,   340}
    ,{   310,   310,   310,   270,   310}
    ,{   310,   310,   310,   210,   310}
    ,{   370,   370,   310,   270,   310}
    }
   ,{{   340,   340,   340,   250,   340}
    ,{   340,   340,   340,   250,   340}
    ,{   310,   310,   310,   210,   310}
    ,{   230,   230,   230,   130,   230}
    ,{   310,   310,   310,   210,   310}
    }
   ,{{   310,   310,   310,   270,   310}
    ,{   310,   310,   310,   210,   310}
    ,{   310,   310,   310,   270,   310}
    ,{   310,   310,   310,   210,   310}
    ,{   310,   310,   310,   270,   310}
    }
   ,{{   310,   310,   310,   210,   310}
    ,{   270,   270,   270,   170,   270}
    ,{   310,   310,   310,   210,   310}
    ,{   210,   180,   180,   210,   180}
    ,{   310,   310,   310,   210,   310}
    }
   ,{{   370,   370,   310,   270,   310}
    ,{   310,   310,   310,   210,   310}
    ,{   310,   310,   310,   270,   310}
    ,{   310,   310,   310,   210,   310}
    ,{   370,   370,   310,   210,   310}
    }
   }
  ,{{{   340,   300,   340,   300,   310}
    ,{   340,   300,   340,   300,   310}
    ,{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    }
   ,{{   340,   300,   340,   300,   310}
    ,{   340,   300,   340,   300,   310}
    ,{   310,   260,   310,   260,   280}
    ,{   290,   180,   290,   180,   260}
    ,{   310,   260,   310,   260,   280}
    }
   ,{{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    }
   ,{{   330,   260,   330,   260,   300}
    ,{   330,   220,   330,   220,   300}
    ,{   310,   260,   310,   260,   280}
    ,{   180,   130,   180,   130,   150}
    ,{   310,   260,   310,   260,   280}
    }
   ,{{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    }
   }
  ,{{{   340,   260,   340,   280,   340}
    ,{   340,   240,   340,   240,   340}
    ,{   310,   260,   310,   150,   310}
    ,{   310,   200,   310,   280,   310}
    ,{   310,   260,   310,   280,   310}
    }
   ,{{   340,   240,   340,   200,   340}
    ,{   340,   240,   340,   190,   340}
    ,{   310,   200,   310,   150,   310}
    ,{   230,   120,   230,   200,   230}
    ,{   310,   200,   310,   150,   310}
    }
   ,{{   310,   260,   310,   150,   310}
    ,{   310,   200,   310,   150,   310}
    ,{   310,   260,   310,   150,   310}
    ,{   310,   200,   310,   150,   310}
    ,{   310,   260,   310,   150,   310}
    }
   ,{{   310,   200,   310,   280,   310}
    ,{   270,   160,   270,   240,   270}
    ,{   310,   200,   310,   150,   310}
    ,{   280,   200,   180,   280,   180}
    ,{   310,   200,   310,   150,   310}
    }
   ,{{   310,   260,   310,   280,   310}
    ,{   310,   200,   310,   150,   310}
    ,{   310,   260,   310,   150,   310}
    ,{   310,   200,   310,   150,   310}
    ,{   310,   200,   310,   280,   310}
    }
   }
  ,{{{   340,   300,   340,   300,   320}
    ,{   340,   300,   340,   300,   320}
    ,{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    }
   ,{{   340,   300,   340,   300,   320}
    ,{   340,   300,   340,   300,   320}
    ,{   310,   260,   310,   260,   220}
    ,{   290,   180,   290,   180,   140}
    ,{   310,   260,   310,   260,   220}
    }
   ,{{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    }
   ,{{   330,   260,   330,   260,   220}
    ,{   330,   220,   330,   220,   180}
    ,{   310,   260,   310,   260,   220}
    ,{   220,   130,   180,   130,   220}
    ,{   310,   260,   310,   260,   220}
    }
   ,{{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    }
   }
  }
 ,{{{{   370,   340,   370,   280,   340}
    ,{   370,   310,   370,   280,   340}
    ,{   280,   280,   280,   240,   280}
    ,{   280,   280,   280,   250,   280}
    ,{   340,   340,   280,   250,   280}
    }
   ,{{   280,   280,   280,   230,   280}
    ,{   240,   240,   240,   200,   240}
    ,{   280,   280,   280,   230,   280}
    ,{   200,   140,   200,   120,   170}
    ,{   280,   280,   280,   230,   280}
    }
   ,{{   280,   280,   280,   240,   280}
    ,{   280,   280,   280,   230,   280}
    ,{   280,   280,   280,   240,   280}
    ,{   280,   280,   280,   230,   280}
    ,{   280,   280,   280,   240,   280}
    }
   ,{{   370,   310,   370,   280,   340}
    ,{   370,   310,   370,   280,   340}
    ,{   280,   280,   280,   230,   280}
    ,{   250,   170,   150,   250,   190}
    ,{   280,   280,   280,   230,   280}
    }
   ,{{   340,   340,   280,   250,   280}
    ,{   280,   280,   280,   230,   280}
    ,{   280,   280,   280,   240,   280}
    ,{   280,   280,   280,   230,   280}
    ,{   340,   340,   280,   250,   280}
    }
   }
  ,{{{   340,   340,   310,   240,   310}
    ,{   310,   310,   310,   210,   310}
    ,{   280,   280,   280,   240,   280}
    ,{   280,   280,   280,   180,   280}
    ,{   340,   340,   280,   240,   280}
    }
   ,{{   280,   280,   280,   180,   280}
    ,{   240,   240,   240,   150,   240}
    ,{   280,   280,   280,   180,   280}
    ,{   140,   140,   140,    50,   140}
    ,{   280,   280,   280,   180,   280}
    }
   ,{{   280,   280,   280,   240,   280}
    ,{   280,   280,   280,   180,   280}
    ,{   280,   280,   280,   240,   280}
    ,{   280,   280,   280,   180,   280}
    ,{   280,   280,   280,   240,   280}
    }
   ,{{   310,   310,   310,   210,   310}
    ,{   310,   310,   310,   210,   310}
    ,{   280,   280,   280,   180,   280}
    ,{   180,   150,   150,   180,   150}
    ,{   280,   280,   280,   180,   280}
    }
   ,{{   340,   340,   280,   240,   280}
    ,{   280,   280,   280,   180,   280}
    ,{   280,   280,   280,   240,   280}
    ,{   280,   280,   280,   180,   280}
    ,{   340,   340,   280,   180,   280}
    }
   }
  ,{{{   370,   260,   370,   260,   340}
    ,{   370,   260,   370,   260,   340}
    ,{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    }
   ,{{   280,   230,   280,   230,   250}
    ,{   240,   200,   240,   200,   210}
    ,{   280,   230,   280,   230,   250}
    ,{   200,   100,   200,   100,   170}
    ,{   280,   230,   280,   230,   250}
    }
   ,{{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    }
   ,{{   370,   260,   370,   260,   340}
    ,{   370,   260,   370,   260,   340}
    ,{   280,   230,   280,   230,   250}
    ,{   150,   100,   150,   100,   120}
    ,{   280,   230,   280,   230,   250}
    }
   ,{{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    }
   }
  ,{{{   310,   230,   310,   280,   310}
    ,{   310,   200,   310,   280,   310}
    ,{   280,   230,   280,   120,   280}
    ,{   280,   170,   280,   250,   280}
    ,{   280,   230,   280,   250,   280}
    }
   ,{{   280,   170,   280,   120,   280}
    ,{   240,   140,   240,    90,   240}
    ,{   280,   170,   280,   120,   280}
    ,{   140,    40,   140,   120,   140}
    ,{   280,   170,   280,   120,   280}
    }
   ,{{   280,   230,   280,   120,   280}
    ,{   280,   170,   280,   120,   280}
    ,{   280,   230,   280,   120,   280}
    ,{   280,   170,   280,   120,   280}
    ,{   280,   230,   280,   120,   280}
    }
   ,{{   310,   200,   310,   280,   310}
    ,{   310,   200,   310,   280,   310}
    ,{   280,   170,   280,   120,   280}
    ,{   250,   170,   150,   250,   150}
    ,{   280,   170,   280,   120,   280}
    }
   ,{{   280,   230,   280,   250,   280}
    ,{   280,   170,   280,   120,   280}
    ,{   280,   230,   280,   120,   280}
    ,{   280,   170,   280,   120,   280}
    ,{   280,   170,   280,   250,   280}
    }
   }
  ,{{{   370,   260,   370,   260,   220}
    ,{   370,   260,   370,   260,   220}
    ,{   280,   230,   280,   230,   190}
    ,{   280,   230,   280,   230,   190}
    ,{   280,   230,   280,   230,   190}
    }
   ,{{   280,   230,   280,   230,   220}
    ,{   240,   200,   240,   200,   220}
    ,{   280,   230,   280,   230,   190}
    ,{   200,   100,   200,   100,    60}
    ,{   280,   230,   280,   230,   190}
    }
   ,{{   280,   230,   280,   230,   190}
    ,{   280,   230,   280,   230,   190}
    ,{   280,   230,   280,   230,   190}
    ,{   280,   230,   280,   230,   190}
    ,{   280,   230,   280,   230,   190}
    }
   ,{{   370,   260,   370,   260,   220}
    ,{   370,   260,   370,   260,   220}
    ,{   280,   230,   280,   230,   190}
    ,{   190,   100,   150,   100,   190}
    ,{   280,   230,   280,   230,   190}
    }
   ,{{   280,   230,   280,   230,   190}
    ,{   280,   230,   280,   230,   190}
    ,{   280,   230,   280,   230,   190}
    ,{   280,   230,   280,   230,   190}
    ,{   280,   230,   280,   230,   190}
    }
   }
  }
 ,{{{{   280,   280,   280,   230,   280}
    ,{   280,   280,   280,   230,   280}
    ,{   260,   260,   260,   220,   260}
    ,{   260,   260,   260,   220,   260}
    ,{   260,   260,   260,   220,   260}
    }
   ,{{   280,   280,   280,   230,   280}
    ,{   280,   280,   280,   230,   280}
    ,{   250,   250,   250,   210,   250}
    ,{   210,   150,   210,   130,   180}
    ,{   250,   250,   250,   210,   250}
    }
   ,{{   260,   260,   260,   220,   260}
    ,{   260,   260,   260,   220,   260}
    ,{   260,   260,   260,   220,   260}
    ,{   260,   260,   260,   220,   260}
    ,{   260,   260,   260,   220,   260}
    }
   ,{{   280,   250,   280,   210,   250}
    ,{   280,   220,   280,   200,   250}
    ,{   250,   250,   250,   210,   250}
    ,{   210,   130,   100,   210,   150}
    ,{   250,   250,   250,   210,   250}
    }
   ,{{   260,   260,   260,   220,   260}
    ,{   260,   260,   260,   220,   260}
    ,{   260,   260,   260,   220,   260}
    ,{   260,   260,   260,   220,   260}
    ,{   230,   230,   170,   140,   170}
    }
   }
  ,{{{   280,   280,   280,   220,   280}
    ,{   280,   280,   280,   180,   280}
    ,{   260,   260,   260,   220,   260}
    ,{   260,   260,   260,   170,   260}
    ,{   260,   260,   260,   220,   260}
    }
   ,{{   280,   280,   280,   180,   280}
    ,{   280,   280,   280,   180,   280}
    ,{   250,   250,   250,   160,   250}
    ,{   150,   150,   150,    60,   150}
    ,{   250,   250,   250,   160,   250}
    }
   ,{{   260,   260,   260,   220,   260}
    ,{   260,   260,   260,   170,   260}
    ,{   260,   260,   260,   220,   260}
    ,{   260,   260,   260,   170,   260}
    ,{   260,   260,   260,   220,   260}
    }
   ,{{   250,   250,   250,   160,   250}
    ,{   220,   220,   220,   130,   220}
    ,{   250,   250,   250,   160,   250}
    ,{   140,   100,   100,   140,   100}
    ,{   250,   250,   250,   160,   250}
    }
   ,{{   260,   260,   260,   220,   260}
    ,{   260,   260,   260,   170,   260}
    ,{   260,   260,   260,   220,   260}
    ,{   260,   260,   260,   170,   260}
    ,{   230,   230,   170,    70,   170}
    }
   }
  ,{{{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   260,   210,   260,   210,   230}
    ,{   260,   220,   260,   220,   230}
    ,{   260,   210,   260,   210,   230}
    }
   ,{{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   250,   210,   250,   210,   220}
    ,{   210,   110,   210,   110,   180}
    ,{   250,   210,   250,   210,   220}
    }
   ,{{   260,   220,   260,   220,   230}
    ,{   260,   220,   260,   220,   230}
    ,{   260,   210,   260,   210,   230}
    ,{   260,   220,   260,   220,   230}
    ,{   260,   210,   260,   210,   230}
    }
   ,{{   280,   210,   280,   210,   250}
    ,{   280,   180,   280,   180,   250}
    ,{   250,   210,   250,   210,   220}
    ,{   100,    60,   100,    60,    70}
    ,{   250,   210,   250,   210,   220}
    }
   ,{{   260,   220,   260,   220,   230}
    ,{   260,   220,   260,   220,   230}
    ,{   260,   210,   260,   210,   230}
    ,{   260,   220,   260,   220,   230}
    ,{   170,   120,   170,   120,   140}
    }
   }
  ,{{{   280,   210,   280,   210,   280}
    ,{   280,   170,   280,   200,   280}
    ,{   260,   210,   260,   100,   260}
    ,{   260,   160,   260,   210,   260}
    ,{   260,   210,   260,   140,   260}
    }
   ,{{   280,   170,   280,   130,   280}
    ,{   280,   170,   280,   120,   280}
    ,{   250,   150,   250,   100,   250}
    ,{   150,    50,   150,   130,   150}
    ,{   250,   150,   250,   100,   250}
    }
   ,{{   260,   210,   260,   110,   260}
    ,{   260,   160,   260,   110,   260}
    ,{   260,   210,   260,   100,   260}
    ,{   260,   160,   260,   110,   260}
    ,{   260,   210,   260,   100,   260}
    }
   ,{{   250,   150,   250,   210,   250}
    ,{   220,   120,   220,   200,   220}
    ,{   250,   150,   250,   100,   250}
    ,{   210,   130,   100,   210,   100}
    ,{   250,   150,   250,   100,   250}
    }
   ,{{   260,   210,   260,   140,   260}
    ,{   260,   160,   260,   110,   260}
    ,{   260,   210,   260,   100,   260}
    ,{   260,   160,   260,   110,   260}
    ,{   170,    60,   170,   140,   170}
    }
   }
  ,{{{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   260,   210,   260,   210,   170}
    ,{   260,   220,   260,   220,   180}
    ,{   260,   210,   260,   210,   170}
    }
   ,{{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   250,   210,   250,   210,   170}
    ,{   210,   110,   210,   110,    70}
    ,{   250,   210,   250,   210,   170}
    }
   ,{{   260,   220,   260,   220,   180}
    ,{   260,   220,   260,   220,   180}
    ,{   260,   210,   260,   210,   170}
    ,{   260,   220,   260,   220,   180}
    ,{   260,   210,   260,   210,   170}
    }
   ,{{   280,   210,   280,   210,   170}
    ,{   280,   180,   280,   180,   140}
    ,{   250,   210,   250,   210,   170}
    ,{   150,    60,   100,    60,   150}
    ,{   250,   210,   250,   210,   170}
    }
   ,{{   260,   220,   260,   220,   180}
    ,{   260,   220,   260,   220,   180}
    ,{   260,   210,   260,   210,   170}
    ,{   260,   220,   260,   220,   180}
    ,{   170,   120,   170,   120,    80}
    }
   }
  }
 ,{{{{   280,   280,   280,   240,   280}
    ,{   280,   280,   280,   230,   280}
    ,{   280,   280,   280,   240,   280}
    ,{   280,   280,   280,   230,   280}
    ,{   280,   280,   280,   240,   280}
    }
   ,{{   280,   280,   280,   230,   280}
    ,{   280,   280,   280,   230,   280}
    ,{   230,   230,   230,   190,   230}
    ,{   230,   170,   230,   150,   200}
    ,{   230,   230,   230,   190,   230}
    }
   ,{{   280,   280,   280,   240,   280}
    ,{   280,   280,   280,   230,   280}
    ,{   280,   280,   280,   240,   280}
    ,{   280,   280,   280,   230,   280}
    ,{   280,   280,   280,   240,   280}
    }
   ,{{   240,   230,   240,   230,   230}
    ,{   240,   180,   240,   160,   210}
    ,{   230,   230,   230,   190,   230}
    ,{   230,   150,   120,   230,   170}
    ,{   230,   230,   230,   190,   230}
    }
   ,{{   280,   280,   280,   230,   280}
    ,{   280,   280,   280,   230,   280}
    ,{   250,   250,   250,   210,   250}
    ,{   280,   280,   280,   230,   280}
    ,{   250,   250,   190,   170,   190}
    }
   }
  ,{{{   280,   280,   280,   240,   280}
    ,{   280,   280,   280,   180,   280}
    ,{   280,   280,   280,   240,   280}
    ,{   280,   280,   280,   180,   280}
    ,{   280,   280,   280,   240,   280}
    }
   ,{{   280,   280,   280,   180,   280}
    ,{   280,   280,   280,   180,   280}
    ,{   230,   230,   230,   140,   230}
    ,{   170,   170,   170,    80,   170}
    ,{   230,   230,   230,   140,   230}
    }
   ,{{   280,   280,   280,   240,   280}
    ,{   280,   280,   280,   180,   280}
    ,{   280,   280,   280,   240,   280}
    ,{   280,   280,   280,   180,   280}
    ,{   280,   280,   280,   240,   280}
    }
   ,{{   230,   230,   230,   160,   230}
    ,{   180,   180,   180,    90,   180}
    ,{   230,   230,   230,   140,   230}
    ,{   160,   120,   120,   160,   120}
    ,{   230,   230,   230,   140,   230}
    }
   ,{{   280,   280,   280,   210,   280}
    ,{   280,   280,   280,   180,   280}
    ,{   250,   250,   250,   210,   250}
    ,{   280,   280,   280,   180,   280}
    ,{   250,   250,   190,   100,   190}
    }
   }
  ,{{{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    }
   ,{{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   230,   190,   230,   190,   200}
    ,{   230,   130,   230,   130,   200}
    ,{   230,   190,   230,   190,   200}
    }
   ,{{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    }
   ,{{   240,   190,   240,   190,   210}
    ,{   240,   140,   240,   140,   210}
    ,{   230,   190,   230,   190,   200}
    ,{   120,    80,   120,    80,    90}
    ,{   230,   190,   230,   190,   200}
    }
   ,{{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   250,   200,   250,   200,   220}
    ,{   280,   230,   280,   230,   250}
    ,{   190,   150,   190,   150,   160}
    }
   }
  ,{{{   280,   230,   280,   230,   280}
    ,{   280,   170,   280,   160,   280}
    ,{   280,   230,   280,   120,   280}
    ,{   280,   170,   280,   230,   280}
    ,{   280,   230,   280,   170,   280}
    }
   ,{{   280,   170,   280,   150,   280}
    ,{   280,   170,   280,   120,   280}
    ,{   230,   130,   230,    80,   230}
    ,{   170,    70,   170,   150,   170}
    ,{   230,   130,   230,    80,   230}
    }
   ,{{   280,   230,   280,   120,   280}
    ,{   280,   170,   280,   120,   280}
    ,{   280,   230,   280,   120,   280}
    ,{   280,   170,   280,   120,   280}
    ,{   280,   230,   280,   120,   280}
    }
   ,{{   230,   150,   230,   230,   230}
    ,{   180,    80,   180,   160,   180}
    ,{   230,   130,   230,    80,   230}
    ,{   230,   150,   120,   230,   120}
    ,{   230,   130,   230,    80,   230}
    }
   ,{{   280,   200,   280,   170,   280}
    ,{   280,   170,   280,   120,   280}
    ,{   250,   200,   250,    90,   250}
    ,{   280,   170,   280,   120,   280}
    ,{   190,    90,   190,   170,   190}
    }
   }
  ,{{{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   190}
    ,{   280,   230,   280,   230,   190}
    ,{   280,   230,   280,   230,   190}
    }
   ,{{   280,   230,   280,   230,   250}
    ,{   280,   230,   280,   230,   250}
    ,{   230,   190,   230,   190,   150}
    ,{   230,   130,   230,   130,    90}
    ,{   230,   190,   230,   190,   150}
    }
   ,{{   280,   230,   280,   230,   190}
    ,{   280,   230,   280,   230,   190}
    ,{   280,   230,   280,   230,   190}
    ,{   280,   230,   280,   230,   190}
    ,{   280,   230,   280,   230,   190}
    }
   ,{{   240,   190,   240,   190,   170}
    ,{   240,   140,   240,   140,   100}
    ,{   230,   190,   230,   190,   150}
    ,{   170,    80,   120,    80,   170}
    ,{   230,   190,   230,   190,   150}
    }
   ,{{   280,   230,   280,   230,   190}
    ,{   280,   230,   280,   230,   190}
    ,{   250,   200,   250,   200,   160}
    ,{   280,   230,   280,   230,   190}
    ,{   190,   150,   190,   150,   110}
    }
   }
  }
 ,{{{{   370,   370,   370,   300,   340}
    ,{   370,   340,   370,   300,   340}
    ,{   310,   310,   310,   270,   310}
    ,{   310,   310,   310,   280,   310}
    ,{   370,   370,   310,   280,   310}
    }
   ,{{   340,   340,   340,   300,   340}
    ,{   340,   340,   340,   300,   340}
    ,{   310,   310,   310,   260,   310}
    ,{   290,   230,   290,   200,   260}
    ,{   310,   310,   310,   260,   310}
    }
   ,{{   310,   310,   310,   270,   310}
    ,{   310,   310,   310,   260,   310}
    ,{   310,   310,   310,   270,   310}
    ,{   310,   310,   310,   260,   310}
    ,{   310,   310,   310,   270,   310}
    }
   ,{{   370,   310,   370,   280,   340}
    ,{   370,   310,   370,   280,   340}
    ,{   310,   310,   310,   260,   310}
    ,{   280,   200,   180,   280,   220}
    ,{   310,   310,   310,   260,   310}
    }
   ,{{   370,   370,   310,   280,   310}
    ,{   310,   310,   310,   260,   310}
    ,{   310,   310,   310,   270,   310}
    ,{   310,   310,   310,   260,   310}
    ,{   370,   370,   310,   280,   310}
    }
   }
  ,{{{   370,   370,   340,   270,   340}
    ,{   340,   340,   340,   250,   340}
    ,{   310,   310,   310,   270,   310}
    ,{   310,   310,   310,   210,   310}
    ,{   370,   370,   310,   270,   310}
    }
   ,{{   340,   340,   340,   250,   340}
    ,{   340,   340,   340,   250,   340}
    ,{   310,   310,   310,   210,   310}
    ,{   230,   230,   230,   130,   230}
    ,{   310,   310,   310,   210,   310}
    }
   ,{{   310,   310,   310,   270,   310}
    ,{   310,   310,   310,   210,   310}
    ,{   310,   310,   310,   270,   310}
    ,{   310,   310,   310,   210,   310}
    ,{   310,   310,   310,   270,   310}
    }
   ,{{   310,   310,   310,   210,   310}
    ,{   310,   310,   310,   210,   310}
    ,{   310,   310,   310,   210,   310}
    ,{   210,   180,   180,   210,   180}
    ,{   310,   310,   310,   210,   310}
    }
   ,{{   370,   370,   310,   270,   310}
    ,{   310,   310,   310,   210,   310}
    ,{   310,   310,   310,   270,   310}
    ,{   310,   310,   310,   210,   310}
    ,{   370,   370,   310,   210,   310}
    }
   }
  ,{{{   370,   300,   370,   300,   340}
    ,{   370,   300,   370,   300,   340}
    ,{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    }
   ,{{   340,   300,   340,   300,   310}
    ,{   340,   300,   340,   300,   310}
    ,{   310,   260,   310,   260,   280}
    ,{   290,   180,   290,   180,   260}
    ,{   310,   260,   310,   260,   280}
    }
   ,{{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    }
   ,{{   370,   260,   370,   260,   340}
    ,{   370,   260,   370,   260,   340}
    ,{   310,   260,   310,   260,   280}
    ,{   180,   130,   180,   130,   150}
    ,{   310,   260,   310,   260,   280}
    }
   ,{{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    ,{   310,   260,   310,   260,   280}
    }
   }
  ,{{{   340,   260,   340,   280,   340}
    ,{   340,   240,   340,   280,   340}
    ,{   310,   260,   310,   150,   310}
    ,{   310,   200,   310,   280,   310}
    ,{   310,   260,   310,   280,   310}
    }
   ,{{   340,   240,   340,   200,   340}
    ,{   340,   240,   340,   190,   340}
    ,{   310,   200,   310,   150,   310}
    ,{   230,   120,   230,   200,   230}
    ,{   310,   200,   310,   150,   310}
    }
   ,{{   310,   260,   310,   150,   310}
    ,{   310,   200,   310,   150,   310}
    ,{   310,   260,   310,   150,   310}
    ,{   310,   200,   310,   150,   310}
    ,{   310,   260,   310,   150,   310}
    }
   ,{{   310,   200,   310,   280,   310}
    ,{   310,   200,   310,   280,   310}
    ,{   310,   200,   310,   150,   310}
    ,{   280,   200,   180,   280,   180}
    ,{   310,   200,   310,   150,   310}
    }
   ,{{   310,   260,   310,   280,   310}
    ,{   310,   200,   310,   150,   310}
    ,{   310,   260,   310,   150,   310}
    ,{   310,   200,   310,   150,   310}
    ,{   310,   200,   310,   280,   310}
    }
   }
  ,{{{   370,   300,   370,   300,   320}
    ,{   370,   300,   370,   300,   320}
    ,{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    }
   ,{{   340,   300,   340,   300,   320}
    ,{   340,   300,   340,   300,   320}
    ,{   310,   260,   310,   260,   220}
    ,{   290,   180,   290,   180,   140}
    ,{   310,   260,   310,   260,   220}
    }
   ,{{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    }
   ,{{   370,   260,   370,   260,   220}
    ,{   370,   260,   370,   260,   220}
    ,{   310,   260,   310,   260,   220}
    ,{   220,   130,   180,   130,   220}
    ,{   310,   260,   310,   260,   220}
    }
   ,{{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    ,{   310,   260,   310,   260,   220}
    }
   }
  }
 }
,{{{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  ,{{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   ,{{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    ,{   INF,   INF,   INF,   INF,   INF}
    }
   }
  }
 ,{{{{   310,   300,   270,   310,   290}
    ,{   300,   300,   270,   270,   290}
    ,{   310,   290,   250,   310,   250}
    ,{   300,   300,   270,   270,   270}
    ,{   300,   270,   240,   300,   240}
    }
   ,{{   290,   270,   230,   230,   290}
    ,{   290,   270,   230,   230,   290}
    ,{   260,   260,   220,   220,   220}
    ,{   190,   170,   190,   130,   190}
    ,{   260,   260,   220,   220,   220}
    }
   ,{{   310,   300,   270,   310,   270}
    ,{   300,   300,   270,   270,   270}
    ,{   310,   290,   250,   310,   250}
    ,{   300,   300,   270,   270,   270}
    ,{   300,   270,   240,   300,   240}
    }
   ,{{   260,   260,   220,   220,   220}
    ,{   190,   170,   190,   130,   190}
    ,{   260,   260,   220,   220,   220}
    ,{   210,   130,    80,   210,   210}
    ,{   260,   260,   220,   220,   220}
    }
   ,{{   300,   300,   270,   300,   270}
    ,{   300,   300,   270,   270,   270}
    ,{   300,   270,   240,   300,   240}
    ,{   300,   300,   270,   270,   270}
    ,{   240,   240,   150,   150,   150}
    }
   }
  ,{{{   310,   300,   270,   310,   270}
    ,{   300,   300,   270,   270,   270}
    ,{   310,   290,   250,   310,   250}
    ,{   300,   300,   270,   270,   270}
    ,{   300,   270,   240,   300,   240}
    }
   ,{{   270,   270,   230,   230,   230}
    ,{   270,   270,   230,   230,   230}
    ,{   260,   260,   220,   220,   220}
    ,{   170,   170,   130,   130,   130}
    ,{   260,   260,   220,   220,   220}
    }
   ,{{   310,   300,   270,   310,   270}
    ,{   300,   300,   270,   270,   270}
    ,{   310,   290,   250,   310,   250}
    ,{   300,   300,   270,   270,   270}
    ,{   300,   270,   240,   300,   240}
    }
   ,{{   260,   260,   220,   220,   220}
    ,{   170,   170,   130,   130,   130}
    ,{   260,   260,   220,   220,   220}
    ,{   210,   110,    80,   210,    80}
    ,{   260,   260,   220,   220,   220}
    }
   ,{{   300,   300,   270,   300,   270}
    ,{   300,   300,   270,   270,   270}
    ,{   300,   270,   240,   300,   240}
    ,{   300,   300,   270,   270,   270}
    ,{   240,   240,   150,   150,   150}
    }
   }
  ,{{{   270,   270,   270,   270,   270}
    ,{   270,   270,   270,   270,   270}
    ,{   250,   250,   250,   250,   250}
    ,{   270,   270,   270,   270,   270}
    ,{   240,   240,   240,   240,   240}
    }
   ,{{   230,   230,   230,   230,   230}
    ,{   230,   230,   230,   230,   230}
    ,{   220,   220,   220,   220,   220}
    ,{   190,   130,   190,   130,   190}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   270,   270,   270,   270,   270}
    ,{   270,   270,   270,   270,   270}
    ,{   250,   250,   250,   250,   250}
    ,{   270,   270,   270,   270,   270}
    ,{   240,   240,   240,   240,   240}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   190,   130,   190,   130,   190}
    ,{   220,   220,   220,   220,   220}
    ,{    80,    80,    80,    80,    80}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   270,   270,   270,   270,   270}
    ,{   270,   270,   270,   270,   270}
    ,{   240,   240,   240,   240,   240}
    ,{   270,   270,   270,   270,   270}
    ,{   150,   150,   150,   150,   150}
    }
   }
  ,{{{   270,   230,   270,   210,   270}
    ,{   270,   190,   270,   140,   270}
    ,{   250,   230,   250,   120,   250}
    ,{   270,   190,   270,   210,   270}
    ,{   240,   220,   240,   150,   240}
    }
   ,{{   230,   150,   230,   130,   230}
    ,{   230,   150,   230,   100,   230}
    ,{   220,   140,   220,    90,   220}
    ,{   130,    50,   130,   130,   130}
    ,{   220,   140,   220,    90,   220}
    }
   ,{{   270,   230,   270,   140,   270}
    ,{   270,   190,   270,   140,   270}
    ,{   250,   230,   250,   120,   250}
    ,{   270,   190,   270,   140,   270}
    ,{   240,   220,   240,   110,   240}
    }
   ,{{   220,   140,   220,   210,   220}
    ,{   130,    50,   130,   130,   130}
    ,{   220,   140,   220,    90,   220}
    ,{   210,   130,    80,   210,    80}
    ,{   220,   140,   220,    90,   220}
    }
   ,{{   270,   220,   270,   150,   270}
    ,{   270,   190,   270,   140,   270}
    ,{   240,   220,   240,   110,   240}
    ,{   270,   190,   270,   140,   270}
    ,{   150,    70,   150,   150,   150}
    }
   }
  ,{{{   290,   270,   270,   270,   290}
    ,{   290,   270,   270,   270,   290}
    ,{   250,   250,   250,   250,   250}
    ,{   270,   270,   270,   270,   270}
    ,{   240,   240,   240,   240,   240}
    }
   ,{{   290,   230,   230,   230,   290}
    ,{   290,   230,   230,   230,   290}
    ,{   220,   220,   220,   220,   220}
    ,{   190,   130,   190,   130,   130}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   270,   270,   270,   270,   270}
    ,{   270,   270,   270,   270,   270}
    ,{   250,   250,   250,   250,   250}
    ,{   270,   270,   270,   270,   270}
    ,{   240,   240,   240,   240,   240}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   190,   130,   190,   130,   130}
    ,{   220,   220,   220,   220,   220}
    ,{   210,    80,    80,    80,   210}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   270,   270,   270,   270,   270}
    ,{   270,   270,   270,   270,   270}
    ,{   240,   240,   240,   240,   240}
    ,{   270,   270,   270,   270,   270}
    ,{   150,   150,   150,   150,   150}
    }
   }
  }
 ,{{{{   300,   280,   240,   280,   300}
    ,{   300,   280,   240,   240,   300}
    ,{   280,   260,   220,   280,   220}
    ,{   250,   250,   210,   210,   210}
    ,{   280,   250,   220,   280,   220}
    }
   ,{{   300,   280,   240,   240,   300}
    ,{   300,   280,   240,   240,   300}
    ,{   250,   250,   220,   220,   220}
    ,{   100,    70,   100,    40,   100}
    ,{   250,   250,   220,   220,   220}
    }
   ,{{   280,   250,   220,   280,   220}
    ,{   250,   250,   210,   210,   210}
    ,{   280,   250,   220,   280,   220}
    ,{   250,   250,   210,   210,   210}
    ,{   280,   250,   220,   280,   220}
    }
   ,{{   250,   250,   220,   220,   220}
    ,{   160,   140,   160,   100,   160}
    ,{   250,   250,   220,   220,   220}
    ,{   210,   130,    80,   210,   210}
    ,{   250,   250,   220,   220,   220}
    }
   ,{{   280,   260,   220,   280,   220}
    ,{   250,   250,   210,   210,   210}
    ,{   280,   260,   220,   280,   220}
    ,{   250,   250,   210,   210,   210}
    ,{   240,   240,   140,   140,   140}
    }
   }
  ,{{{   280,   280,   240,   280,   240}
    ,{   280,   280,   240,   240,   240}
    ,{   280,   260,   220,   280,   220}
    ,{   250,   250,   210,   210,   210}
    ,{   280,   250,   220,   280,   220}
    }
   ,{{   280,   280,   240,   240,   240}
    ,{   280,   280,   240,   240,   240}
    ,{   250,   250,   220,   220,   220}
    ,{    70,    70,    40,    40,    40}
    ,{   250,   250,   220,   220,   220}
    }
   ,{{   280,   250,   220,   280,   220}
    ,{   250,   250,   210,   210,   210}
    ,{   280,   250,   220,   280,   220}
    ,{   250,   250,   210,   210,   210}
    ,{   280,   250,   220,   280,   220}
    }
   ,{{   250,   250,   220,   220,   220}
    ,{   140,   140,   100,   100,   100}
    ,{   250,   250,   220,   220,   220}
    ,{   210,   110,    80,   210,    80}
    ,{   250,   250,   220,   220,   220}
    }
   ,{{   280,   260,   220,   280,   220}
    ,{   250,   250,   210,   210,   210}
    ,{   280,   260,   220,   280,   220}
    ,{   250,   250,   210,   210,   210}
    ,{   240,   240,   140,   140,   140}
    }
   }
  ,{{{   240,   240,   240,   240,   240}
    ,{   240,   240,   240,   240,   240}
    ,{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   240,   240,   240,   240,   240}
    ,{   240,   240,   240,   240,   240}
    ,{   220,   220,   220,   220,   220}
    ,{   100,    40,   100,    40,   100}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   160,   100,   160,   100,   160}
    ,{   220,   220,   220,   220,   220}
    ,{    80,    80,    80,    80,    80}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   140,   140,   140,   140,   140}
    }
   }
  ,{{{   240,   200,   240,   210,   240}
    ,{   240,   160,   240,   110,   240}
    ,{   220,   200,   220,    90,   220}
    ,{   210,   130,   210,   210,   210}
    ,{   220,   200,   220,   140,   220}
    }
   ,{{   240,   160,   240,   110,   240}
    ,{   240,   160,   240,   110,   240}
    ,{   220,   140,   220,    90,   220}
    ,{    40,   -40,    40,    40,    40}
    ,{   220,   140,   220,    90,   220}
    }
   ,{{   220,   200,   220,    90,   220}
    ,{   210,   130,   210,    80,   210}
    ,{   220,   200,   220,    90,   220}
    ,{   210,   130,   210,    80,   210}
    ,{   220,   200,   220,    90,   220}
    }
   ,{{   220,   140,   220,   210,   220}
    ,{   100,    20,   100,   100,   100}
    ,{   220,   140,   220,    90,   220}
    ,{   210,   130,    80,   210,    80}
    ,{   220,   140,   220,    90,   220}
    }
   ,{{   220,   200,   220,   140,   220}
    ,{   210,   130,   210,    80,   210}
    ,{   220,   200,   220,    90,   220}
    ,{   210,   130,   210,    80,   210}
    ,{   140,    90,   140,   140,   140}
    }
   }
  ,{{{   300,   240,   240,   240,   300}
    ,{   300,   240,   240,   240,   300}
    ,{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   300,   240,   240,   240,   300}
    ,{   300,   240,   240,   240,   300}
    ,{   220,   220,   220,   220,   220}
    ,{   100,    40,   100,    40,    50}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   160,   100,   160,   100,   140}
    ,{   220,   220,   220,   220,   220}
    ,{   210,    80,    80,    80,   210}
    ,{   220,   220,   220,   220,   220}
    }
   ,{{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   220,   220,   220,   220,   220}
    ,{   210,   210,   210,   210,   210}
    ,{   140,   140,   140,   140,   140}
    }
   }
  }
 ,{{{{   430,   430,   370,   400,   430}
    ,{   430,   410,   370,   370,   430}
    ,{   400,   370,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   430,   430,   340,   400,   340}
    }
   ,{{   430,   410,   370,   370,   430}
    ,{   430,   410,   370,   370,   430}
    ,{   370,   370,   340,   340,   340}
    ,{   320,   290,   320,   260,   320}
    ,{   370,   370,   340,   340,   340}
    }
   ,{{   400,   370,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   400,   370,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   400,   370,   340,   400,   340}
    }
   ,{{   370,   370,   360,   340,   360}
    ,{   360,   360,   360,   300,   360}
    ,{   370,   370,   340,   340,   340}
    ,{   340,   260,   210,   340,   340}
    ,{   370,   370,   340,   340,   340}
    }
   ,{{   430,   430,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   400,   370,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   430,   430,   340,   340,   340}
    }
   }
  ,{{{   430,   430,   370,   400,   370}
    ,{   410,   410,   370,   370,   370}
    ,{   400,   370,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   430,   430,   340,   400,   340}
    }
   ,{{   410,   410,   370,   370,   370}
    ,{   410,   410,   370,   370,   370}
    ,{   370,   370,   340,   340,   340}
    ,{   290,   290,   260,   260,   260}
    ,{   370,   370,   340,   340,   340}
    }
   ,{{   400,   370,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   400,   370,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   400,   370,   340,   400,   340}
    }
   ,{{   370,   370,   340,   340,   340}
    ,{   360,   360,   300,   300,   300}
    ,{   370,   370,   340,   340,   340}
    ,{   340,   240,   210,   340,   210}
    ,{   370,   370,   340,   340,   340}
    }
   ,{{   430,   430,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   400,   370,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   430,   430,   340,   340,   340}
    }
   }
  ,{{{   370,   370,   370,   370,   370}
    ,{   370,   370,   370,   370,   370}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   370,   370,   370,   370,   370}
    ,{   370,   370,   370,   370,   370}
    ,{   340,   340,   340,   340,   340}
    ,{   320,   260,   320,   260,   320}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   360,   340,   360,   340,   360}
    ,{   360,   300,   360,   300,   360}
    ,{   340,   340,   340,   340,   340}
    ,{   210,   210,   210,   210,   210}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   }
  ,{{{   370,   320,   370,   340,   370}
    ,{   370,   290,   370,   300,   370}
    ,{   340,   320,   340,   210,   340}
    ,{   340,   260,   340,   340,   340}
    ,{   340,   320,   340,   340,   340}
    }
   ,{{   370,   290,   370,   260,   370}
    ,{   370,   290,   370,   240,   370}
    ,{   340,   260,   340,   210,   340}
    ,{   260,   180,   260,   260,   260}
    ,{   340,   260,   340,   210,   340}
    }
   ,{{   340,   320,   340,   210,   340}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   320,   340,   210,   340}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   320,   340,   210,   340}
    }
   ,{{   340,   260,   340,   340,   340}
    ,{   300,   220,   300,   300,   300}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   260,   210,   340,   210}
    ,{   340,   260,   340,   210,   340}
    }
   ,{{   340,   320,   340,   340,   340}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   320,   340,   210,   340}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   260,   340,   340,   340}
    }
   }
  ,{{{   430,   370,   370,   370,   430}
    ,{   430,   370,   370,   370,   430}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   430,   370,   370,   370,   430}
    ,{   430,   370,   370,   370,   430}
    ,{   340,   340,   340,   340,   340}
    ,{   320,   260,   320,   260,   260}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   360,   340,   360,   340,   340}
    ,{   360,   300,   360,   300,   300}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   210,   210,   210,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   }
  }
 ,{{{{   400,   400,   400,   370,   400}
    ,{   400,   370,   400,   360,   400}
    ,{   370,   340,   310,   370,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   400,   400,   310,   370,   310}
    }
   ,{{   360,   360,   310,   360,   330}
    ,{   360,   360,   270,   360,   330}
    ,{   340,   340,   310,   310,   310}
    ,{   230,   220,   230,   170,   230}
    ,{   340,   340,   310,   310,   310}
    }
   ,{{   370,   340,   310,   370,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   370,   340,   310,   370,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   370,   340,   310,   370,   310}
    }
   ,{{   400,   370,   400,   340,   400}
    ,{   400,   370,   400,   340,   400}
    ,{   340,   340,   310,   310,   310}
    ,{   310,   230,   180,   310,   310}
    ,{   340,   340,   310,   310,   310}
    }
   ,{{   400,   400,   310,   370,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   370,   340,   310,   370,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   400,   400,   310,   310,   310}
    }
   }
  ,{{{   400,   400,   340,   370,   340}
    ,{   370,   370,   340,   360,   340}
    ,{   370,   340,   310,   370,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   400,   400,   310,   370,   310}
    }
   ,{{   360,   360,   310,   360,   310}
    ,{   360,   360,   270,   360,   270}
    ,{   340,   340,   310,   310,   310}
    ,{   220,   220,   170,   170,   170}
    ,{   340,   340,   310,   310,   310}
    }
   ,{{   370,   340,   310,   370,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   370,   340,   310,   370,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   370,   340,   310,   370,   310}
    }
   ,{{   370,   370,   340,   340,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   340,   340,   310,   310,   310}
    ,{   310,   210,   180,   310,   180}
    ,{   340,   340,   310,   310,   310}
    }
   ,{{   400,   400,   310,   370,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   370,   340,   310,   370,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   400,   400,   310,   310,   310}
    }
   }
  ,{{{   400,   340,   400,   340,   400}
    ,{   400,   340,   400,   340,   400}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   270,   270,   270,   270,   270}
    ,{   310,   310,   310,   310,   310}
    ,{   230,   170,   230,   170,   230}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   400,   340,   400,   340,   400}
    ,{   400,   340,   400,   340,   400}
    ,{   310,   310,   310,   310,   310}
    ,{   180,   180,   180,   180,   180}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   }
  ,{{{   340,   290,   340,   340,   340}
    ,{   340,   260,   340,   340,   340}
    ,{   310,   290,   310,   180,   310}
    ,{   310,   230,   310,   310,   310}
    ,{   310,   290,   310,   310,   310}
    }
   ,{{   310,   230,   310,   180,   310}
    ,{   270,   190,   270,   140,   270}
    ,{   310,   230,   310,   180,   310}
    ,{   170,    40,   170,   170,   170}
    ,{   310,   230,   310,   180,   310}
    }
   ,{{   310,   290,   310,   180,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   290,   310,   180,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   290,   310,   180,   310}
    }
   ,{{   340,   260,   340,   340,   340}
    ,{   340,   260,   340,   340,   340}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   230,   180,   310,   180}
    ,{   310,   230,   310,   180,   310}
    }
   ,{{   310,   290,   310,   310,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   290,   310,   180,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   230,   310,   310,   310}
    }
   }
  ,{{{   400,   340,   400,   340,   340}
    ,{   400,   340,   400,   340,   340}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   330,   310,   310,   310,   330}
    ,{   330,   270,   270,   270,   330}
    ,{   310,   310,   310,   310,   310}
    ,{   230,   170,   230,   170,   170}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   400,   340,   400,   340,   340}
    ,{   400,   340,   400,   340,   340}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   180,   180,   180,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   }
  }
 ,{{{{   370,   340,   310,   350,   370}
    ,{   370,   340,   310,   310,   370}
    ,{   350,   320,   290,   350,   290}
    ,{   330,   330,   290,   290,   290}
    ,{   350,   320,   290,   350,   290}
    }
   ,{{   370,   340,   310,   310,   370}
    ,{   370,   340,   310,   310,   370}
    ,{   320,   320,   280,   280,   280}
    ,{   240,   220,   240,   180,   240}
    ,{   320,   320,   280,   280,   280}
    }
   ,{{   350,   330,   290,   350,   290}
    ,{   330,   330,   290,   290,   290}
    ,{   350,   320,   290,   350,   290}
    ,{   330,   330,   290,   290,   290}
    ,{   350,   320,   290,   350,   290}
    }
   ,{{   320,   320,   310,   280,   310}
    ,{   310,   290,   310,   250,   310}
    ,{   320,   320,   280,   280,   280}
    ,{   260,   180,   130,   260,   260}
    ,{   320,   320,   280,   280,   280}
    }
   ,{{   350,   330,   290,   350,   290}
    ,{   330,   330,   290,   290,   290}
    ,{   350,   320,   290,   350,   290}
    ,{   330,   330,   290,   290,   290}
    ,{   290,   290,   200,   200,   200}
    }
   }
  ,{{{   350,   340,   310,   350,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   350,   320,   290,   350,   290}
    ,{   330,   330,   290,   290,   290}
    ,{   350,   320,   290,   350,   290}
    }
   ,{{   340,   340,   310,   310,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   320,   320,   280,   280,   280}
    ,{   220,   220,   180,   180,   180}
    ,{   320,   320,   280,   280,   280}
    }
   ,{{   350,   330,   290,   350,   290}
    ,{   330,   330,   290,   290,   290}
    ,{   350,   320,   290,   350,   290}
    ,{   330,   330,   290,   290,   290}
    ,{   350,   320,   290,   350,   290}
    }
   ,{{   320,   320,   280,   280,   280}
    ,{   290,   290,   250,   250,   250}
    ,{   320,   320,   280,   280,   280}
    ,{   260,   170,   130,   260,   130}
    ,{   320,   320,   280,   280,   280}
    }
   ,{{   350,   330,   290,   350,   290}
    ,{   330,   330,   290,   290,   290}
    ,{   350,   320,   290,   350,   290}
    ,{   330,   330,   290,   290,   290}
    ,{   290,   290,   200,   200,   200}
    }
   }
  ,{{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   280,   280,   280,   280,   280}
    ,{   240,   180,   240,   180,   240}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    }
   ,{{   310,   280,   310,   280,   310}
    ,{   310,   250,   310,   250,   310}
    ,{   280,   280,   280,   280,   280}
    ,{   130,   130,   130,   130,   130}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   200,   200,   200,   200,   200}
    }
   }
  ,{{{   310,   270,   310,   260,   310}
    ,{   310,   230,   310,   250,   310}
    ,{   290,   270,   290,   160,   290}
    ,{   290,   210,   290,   260,   290}
    ,{   290,   270,   290,   200,   290}
    }
   ,{{   310,   230,   310,   180,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   280,   200,   280,   150,   280}
    ,{   180,   100,   180,   180,   180}
    ,{   280,   200,   280,   150,   280}
    }
   ,{{   290,   270,   290,   160,   290}
    ,{   290,   210,   290,   160,   290}
    ,{   290,   270,   290,   160,   290}
    ,{   290,   210,   290,   160,   290}
    ,{   290,   270,   290,   160,   290}
    }
   ,{{   280,   200,   280,   260,   280}
    ,{   250,   170,   250,   250,   250}
    ,{   280,   200,   280,   150,   280}
    ,{   260,   180,   130,   260,   130}
    ,{   280,   200,   280,   150,   280}
    }
   ,{{   290,   270,   290,   200,   290}
    ,{   290,   210,   290,   160,   290}
    ,{   290,   270,   290,   160,   290}
    ,{   290,   210,   290,   160,   290}
    ,{   200,   120,   200,   200,   200}
    }
   }
  ,{{{   370,   310,   310,   310,   370}
    ,{   370,   310,   310,   310,   370}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    }
   ,{{   370,   310,   310,   310,   370}
    ,{   370,   310,   310,   310,   370}
    ,{   280,   280,   280,   280,   280}
    ,{   240,   180,   240,   180,   180}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    }
   ,{{   310,   280,   310,   280,   280}
    ,{   310,   250,   310,   250,   250}
    ,{   280,   280,   280,   280,   280}
    ,{   260,   130,   130,   130,   260}
    ,{   280,   280,   280,   280,   280}
    }
   ,{{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   290,   290,   290,   290,   290}
    ,{   200,   200,   200,   200,   200}
    }
   }
  }
 ,{{{{   370,   340,   310,   370,   370}
    ,{   370,   340,   310,   310,   370}
    ,{   370,   340,   310,   370,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   370,   340,   310,   370,   310}
    }
   ,{{   370,   340,   310,   310,   370}
    ,{   370,   340,   310,   310,   370}
    ,{   300,   300,   260,   260,   260}
    ,{   260,   240,   260,   200,   260}
    ,{   300,   300,   260,   260,   260}
    }
   ,{{   370,   340,   310,   370,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   370,   340,   310,   370,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   370,   340,   310,   370,   310}
    }
   ,{{   300,   300,   270,   280,   280}
    ,{   270,   250,   270,   210,   270}
    ,{   300,   300,   260,   260,   260}
    ,{   280,   200,   150,   280,   280}
    ,{   300,   300,   260,   260,   260}
    }
   ,{{   340,   340,   310,   340,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   340,   310,   280,   340,   280}
    ,{   340,   340,   310,   310,   310}
    ,{   320,   320,   220,   220,   220}
    }
   }
  ,{{{   370,   340,   310,   370,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   370,   340,   310,   370,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   370,   340,   310,   370,   310}
    }
   ,{{   340,   340,   310,   310,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   300,   300,   260,   260,   260}
    ,{   240,   240,   200,   200,   200}
    ,{   300,   300,   260,   260,   260}
    }
   ,{{   370,   340,   310,   370,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   370,   340,   310,   370,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   370,   340,   310,   370,   310}
    }
   ,{{   300,   300,   260,   280,   260}
    ,{   250,   250,   210,   210,   210}
    ,{   300,   300,   260,   260,   260}
    ,{   280,   190,   150,   280,   150}
    ,{   300,   300,   260,   260,   260}
    }
   ,{{   340,   340,   310,   340,   310}
    ,{   340,   340,   310,   310,   310}
    ,{   340,   310,   280,   340,   280}
    ,{   340,   340,   310,   310,   310}
    ,{   320,   320,   220,   220,   220}
    }
   }
  ,{{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   260,   260,   260,   260,   260}
    ,{   260,   200,   260,   200,   260}
    ,{   260,   260,   260,   260,   260}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   270,   260,   270,   260,   270}
    ,{   270,   210,   270,   210,   270}
    ,{   260,   260,   260,   260,   260}
    ,{   150,   150,   150,   150,   150}
    ,{   260,   260,   260,   260,   260}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   280,   280,   280,   280,   280}
    ,{   310,   310,   310,   310,   310}
    ,{   220,   220,   220,   220,   220}
    }
   }
  ,{{{   310,   290,   310,   280,   310}
    ,{   310,   230,   310,   210,   310}
    ,{   310,   290,   310,   180,   310}
    ,{   310,   230,   310,   280,   310}
    ,{   310,   290,   310,   220,   310}
    }
   ,{{   310,   230,   310,   200,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   260,   180,   260,   130,   260}
    ,{   200,   120,   200,   200,   200}
    ,{   260,   180,   260,   130,   260}
    }
   ,{{   310,   290,   310,   180,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   290,   310,   180,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   310,   290,   310,   180,   310}
    }
   ,{{   280,   200,   260,   280,   260}
    ,{   210,   130,   210,   210,   210}
    ,{   260,   180,   260,   130,   260}
    ,{   280,   200,   150,   280,   150}
    ,{   260,   180,   260,   130,   260}
    }
   ,{{   310,   260,   310,   220,   310}
    ,{   310,   230,   310,   180,   310}
    ,{   280,   260,   280,   150,   280}
    ,{   310,   230,   310,   180,   310}
    ,{   220,   140,   220,   220,   220}
    }
   }
  ,{{{   370,   310,   310,   310,   370}
    ,{   370,   310,   310,   310,   370}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   370,   310,   310,   310,   370}
    ,{   370,   310,   310,   310,   370}
    ,{   260,   260,   260,   260,   260}
    ,{   260,   200,   260,   200,   200}
    ,{   260,   260,   260,   260,   260}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    }
   ,{{   280,   260,   270,   260,   280}
    ,{   270,   210,   270,   210,   210}
    ,{   260,   260,   260,   260,   260}
    ,{   280,   150,   150,   150,   280}
    ,{   260,   260,   260,   260,   260}
    }
   ,{{   310,   310,   310,   310,   310}
    ,{   310,   310,   310,   310,   310}
    ,{   280,   280,   280,   280,   280}
    ,{   310,   310,   310,   310,   310}
    ,{   220,   220,   220,   220,   220}
    }
   }
  }
 ,{{{{   430,   430,   400,   400,   430}
    ,{   430,   410,   400,   370,   430}
    ,{   400,   370,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   430,   430,   340,   400,   340}
    }
   ,{{   430,   410,   370,   370,   430}
    ,{   430,   410,   370,   370,   430}
    ,{   370,   370,   340,   340,   340}
    ,{   320,   290,   320,   260,   320}
    ,{   370,   370,   340,   340,   340}
    }
   ,{{   400,   370,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   400,   370,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   400,   370,   340,   400,   340}
    }
   ,{{   400,   370,   400,   340,   400}
    ,{   400,   370,   400,   340,   400}
    ,{   370,   370,   340,   340,   340}
    ,{   340,   260,   210,   340,   340}
    ,{   370,   370,   340,   340,   340}
    }
   ,{{   430,   430,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   400,   370,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   430,   430,   340,   340,   340}
    }
   }
  ,{{{   430,   430,   370,   400,   370}
    ,{   410,   410,   370,   370,   370}
    ,{   400,   370,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   430,   430,   340,   400,   340}
    }
   ,{{   410,   410,   370,   370,   370}
    ,{   410,   410,   370,   370,   370}
    ,{   370,   370,   340,   340,   340}
    ,{   290,   290,   260,   260,   260}
    ,{   370,   370,   340,   340,   340}
    }
   ,{{   400,   370,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   400,   370,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   400,   370,   340,   400,   340}
    }
   ,{{   370,   370,   340,   340,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   340,   240,   210,   340,   210}
    ,{   370,   370,   340,   340,   340}
    }
   ,{{   430,   430,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   400,   370,   340,   400,   340}
    ,{   370,   370,   340,   340,   340}
    ,{   430,   430,   340,   340,   340}
    }
   }
  ,{{{   400,   370,   400,   370,   400}
    ,{   400,   370,   400,   370,   400}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   370,   370,   370,   370,   370}
    ,{   370,   370,   370,   370,   370}
    ,{   340,   340,   340,   340,   340}
    ,{   320,   260,   320,   260,   320}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   400,   340,   400,   340,   400}
    ,{   400,   340,   400,   340,   400}
    ,{   340,   340,   340,   340,   340}
    ,{   210,   210,   210,   210,   210}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   }
  ,{{{   370,   320,   370,   340,   370}
    ,{   370,   290,   370,   340,   370}
    ,{   340,   320,   340,   210,   340}
    ,{   340,   260,   340,   340,   340}
    ,{   340,   320,   340,   340,   340}
    }
   ,{{   370,   290,   370,   260,   370}
    ,{   370,   290,   370,   240,   370}
    ,{   340,   260,   340,   210,   340}
    ,{   260,   180,   260,   260,   260}
    ,{   340,   260,   340,   210,   340}
    }
   ,{{   340,   320,   340,   210,   340}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   320,   340,   210,   340}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   320,   340,   210,   340}
    }
   ,{{   340,   260,   340,   340,   340}
    ,{   340,   260,   340,   340,   340}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   260,   210,   340,   210}
    ,{   340,   260,   340,   210,   340}
    }
   ,{{   340,   320,   340,   340,   340}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   320,   340,   210,   340}
    ,{   340,   260,   340,   210,   340}
    ,{   340,   260,   340,   340,   340}
    }
   }
  ,{{{   430,   370,   400,   370,   430}
    ,{   430,   370,   400,   370,   430}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   430,   370,   370,   370,   430}
    ,{   430,   370,   370,   370,   430}
    ,{   340,   340,   340,   340,   340}
    ,{   320,   260,   320,   260,   260}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   400,   340,   400,   340,   340}
    ,{   400,   340,   400,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   210,   210,   210,   340}
    ,{   340,   340,   340,   340,   340}
    }
   ,{{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    ,{   340,   340,   340,   340,   340}
    }
   }
  }
 }};
