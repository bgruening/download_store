

#define HAVE_STRDUP 1
#define HAVE_ERAND48 1
#define HAVE_CONFIG_H 1
