/* 
 * File:   operator_fwd.hh
 * Author: gatter
 *
 * Created on June 23, 2015, 10:53 AM
 */

#ifndef OPERATOR_FWD_HH
#define	OPERATOR_FWD_HH

class Operator;

#endif	/* OPERATOR_FWD_HH */

