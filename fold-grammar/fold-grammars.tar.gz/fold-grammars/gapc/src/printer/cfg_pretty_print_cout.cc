

#include "cfg_pretty_print_cout.hh"

#include <iostream>


Printer::PrettyPrintCOut::PrettyPrintCOut()
	: CFGPrettyPrint (std::cout) {
}

