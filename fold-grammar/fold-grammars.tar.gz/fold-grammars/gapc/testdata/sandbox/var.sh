

set -u

set +u
x=$x
echo $x
set -u

echo $y
