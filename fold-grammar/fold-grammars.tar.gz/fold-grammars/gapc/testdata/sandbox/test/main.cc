//main.cc
#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MAIN
#define BOOST_TEST_MODULE My little Testsuite
#include <boost/test/unit_test.hpp>
