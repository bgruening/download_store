log2()
{
  echo ${*:3} . $1 .. $2
}

log2 a b c d e
