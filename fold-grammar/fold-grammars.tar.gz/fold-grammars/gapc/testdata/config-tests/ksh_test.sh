set -e

echo ${2%%.*}
l=1

echo $(($l+1))


