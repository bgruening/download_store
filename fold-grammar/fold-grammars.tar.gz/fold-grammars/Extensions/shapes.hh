#ifndef SHAPES_HH
#define SHAPES_HH

static const shape_t openParen = '[';
static const shape_t closeParen = ']';

#endif
