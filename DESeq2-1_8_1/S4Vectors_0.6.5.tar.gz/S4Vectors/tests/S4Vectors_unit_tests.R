require("S4Vectors") || stop("unable to load S4Vectors package")
S4Vectors:::.test()
