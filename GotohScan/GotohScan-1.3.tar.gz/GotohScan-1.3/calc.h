#ifndef CALC_H
#define CALC_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "read.h"
#include "structs.h"

#define SCALE 10
#define MAX_ALNS 10000   /* max. number of alignments per query sequence */

/* #include "gammatable.h" */

/* alignement functions */

void gotoh_initMatchTable(gotoh_settings gs);

void gotoh_scanDbase(char * db_seq, int n, char * q_seq, int m,
		     char *db_name, char *q_name, int * score_distr,
		     int n_s, gotoh_settings gs, gotoh_aln List[],
		     int n2add, int Len, int *ntf);

int * gotoh_getMaxS(int scores[], int s, int e);

int * gotoh_fwRecursion(char * s, int n, char * q, int m, char *db_name, char *q_name,
			int * score_distr, int n_s, gotoh_settings cfg, int *ntf);

/* s and q are the input sequences, s_pos start position of alignment, cfg settings
   ss and qq are the backtracked aligned result sequences */
/* returns length of alignment */
float * gotoh_bwRecursion(char * s,char * q, int m, int s_pos, gotoh_settings cfg,
			  char *ss, char *qq, int sollscore, int n2add);

void gotoh_findLocalMaxima(int *scores, gotoh_aln List[], int n2add,
			   int s, int e,
			   char *db_seq, char *db_name,
			   char *q_seq, char *q_name, int m,
			   char strand, gotoh_settings gs, int Len);

void gotoh_getMaxLinear(int *scores, int s, int e, int *ms, int *mi);

void gotoh_backtraceAln2(int ii, int imax, int smax, char strand, char *s_name, char* q_name,
			 gotoh_aln List[], int m, char *db_seq, char *q_seq,
			 gotoh_settings gs, int n2add, int Len);
void gotoh_backtraceAln(int ii, int imax, int smax, char strand, char *s_name, char* q_name,
			gotoh_aln List[], int m, char *db_seq, char *q_seq,
			gotoh_settings gs);

struct gotoh_fitVals gotoh_getRange (int *s, int n_s, int shift);

float gotoh_getSum(int *scores, gotoh_fitVals fv, float k, float theta, int shift);

void gotoh_getPercRange(int *s, int n_s, int * start, int *end, int minAS, char * qname, int *maxC, int *maxI);

struct gotoh_aln gotoh_initL(void);


/* statistic functions */
/* returns 2-dimensional int array a with a[0] => theta, a[1] => k */
double * gotoh_getParams(int * score_distr, int n_s, int n_q, gotoh_settings gs,
			 char * qname, int *ntf);

struct gotoh_fitData gotoh_initFit(int *sd, int min, int max, int v);

double gotoh_getPhi(double k);

double gotoh_getPhiPrime(double k);

float gotoh_getGammaVal(int x, double k, float theta, float gamma, int v);

float gotoh_getLogGammaVal(int x, double k, float theta, float gamma, int v);

float gotoh_gammaX(float x);

float gotoh_logGammaX(float x);

double gotoh_uFunction(double a, double z);

/* utility functions */
char * goto_revCompl(char *sequence, int v, int len);

void gotoh_printGotohAln(gotoh_aln aln, int f);

void gotoh_getRNA(char *seq, int l);

#endif
