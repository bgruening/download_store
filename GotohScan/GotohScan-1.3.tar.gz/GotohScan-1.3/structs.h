#ifndef STRUCTS_H
#define STRUCTS_H

typedef struct gotoh_arguments {

  char *cfg_file;
  char *db_file;
  char *q_file;
  double e;
  int p;
  int out;
  int s;
  int help;
  int version;
  int verbose;
  int split;
  
} gotoh_arguments;

/* -------------------------------------------------------------------------- */

typedef struct gotoh_settings {

  /* input */
  char *dbase;
  char *query;
  /* alignment parameters / scores */
  int gap_open;
  int gap_extend;
  int match;
  int mismatch;
  int matchN;
  int inf;
  /* filter */
  double usrE;
  float percID;
  /* output */
  int output_format;
  int output_data;
  char *data_file;
  int verbose;
  
} gotoh_settings;

/* -------------------------------------------------------------------------- */

/* stores all information for one alignment */
typedef struct gotoh_aln {

  int db_len;            /* length of complete database sequence -> for maf output */
  char *hitseq;          /* hitseq. with gaps    */
  char *queryseq;        /* queryseq. with gaps  */
  char *hitname;         /* name of query        */
  char *queryname;       /* name of scaffold     */
  int sStart;            /* start position in scaffold */
  int sEnd;
  int length;            /* length of alignment  */
  char strand;           /* strand               */
  int alnscore;          /* alignment score      */
  int ntfalnscore;       /* untransformed aln score */
  double evalue;         /* evalue for alignment */
  double Levalue;        /* log(Evalue) das wird berechnet! */
  float percID;
  int mismatches;
  int gapopening;
  int qStart;
  int qEnd;

  
} gotoh_aln;

/* -------------------------------------------------------------------------- */

typedef struct gotoh_candidate {

  char *hitseq;
  char *queryseq;
  int maxscore;        /* perfect match (best case) */
  int minscore;        /* perfect mismatch (worst case) */
  int score;           /* alignment score */
  float scaledscore;   /* score scaled to [0,1] */
  float evalue;

} gotoh_candidate;

/* -------------------------------------------------------------------------- */

typedef struct gotoh_fitData {

  float N;        /* number of datapoints used for fitting */
  float mean;   /* mean value of datapoints */
  float s1;     /* log of mean */
  float s2;     /* mean of sum over logs */
  float s;

} gotoh_fitData;

/* -------------------------------------------------------------------------- */

typedef struct gotoh_fitVals {

  int N;
  int startscore;
  int endscore;
  float mu;
  float sval;
  float theta;
  float k;
  
} gotoh_fitVals;

#endif
