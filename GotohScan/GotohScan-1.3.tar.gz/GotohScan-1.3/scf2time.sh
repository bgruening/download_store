#!/bin/sh

# usage: ./scf2time.sh listOfScaffolds database outputDirectory outputDistribution query.fa

for F in $(cat $1)
do
G=$3"."$F".fa"
grep -A1 -P '$F$' $2 > tmp.fa
grep -v '>' tmp.fa | awk '{printf "%s \t %d\n",$F,length($1);}' >> $4
/homes/biertank/jana/projects/gotoh/GotohScan-1.2/GotohScan -d tmp.fa -q $5 -e 1e-3 -o 1 -s 

done