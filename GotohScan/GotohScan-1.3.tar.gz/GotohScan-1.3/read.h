#ifndef READ_H
#define READ_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "structs.h"

#define INITLEN 100000

char *get_line(FILE *fp);

struct gotoh_arguments gotoh_readArguments(int argc, char *argv[]);

struct gotoh_settings gotoh_readSettings(gotoh_arguments ga);

/* init functions */
gotoh_arguments gotoh_initArguments();

gotoh_settings gotoh_initSettings();


/* print functions */
void gotoh_printArguments(gotoh_arguments ga);

void gotoh_printSettings(gotoh_settings gs);

void usage();

void version();

/* free functions */
void gotoh_freeArguments(gotoh_arguments ga);

void gotoh_freeSettings(gotoh_settings gs);


/* other functions */
void gotoh_Error(char *msg, int v);

void gotoh_Warning(char *msg, int v);

void gotoh_Note(char *msg, int v);

#endif
