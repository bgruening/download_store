#include "read.h"

char cur_q_seq[1000];
char next_q_seq[1000];
char cur_db_seq[1000];
char next_db_seq[1000];

/* -------------------------------------------------------------------------- */

char *get_line(FILE *fp) { /* reads lines of arbitrary length from fp */

   char s[512], *line, *cp;

   line = NULL;
   do {
      if (fgets(s, 512, fp)==NULL) break;
      cp = strchr(s, '\n');
      if (cp != NULL) *cp = '\0';
      if (line==NULL)
	line = (char *) calloc(strlen(s)+1, sizeof(char));
      else
         line = (char *) realloc(line, strlen(s)+strlen(line)+1);
      strcat(line,s);
   } while(cp==NULL);

   return line;
   
}

/* -------------------------------------------------------------------------- */

struct gotoh_arguments gotoh_readArguments(int argc, char *argv[]) {

  int i;
  gotoh_arguments args;

  if(argc < 2) usage();
  /* printf("argc: %d, argv[0]: %s\n",argc,argv[0]); */
  args = gotoh_initArguments();

  for(i=0; i<argc; i++) {
    if(argv[i][0]=='-') {
      switch(argv[i][1]) {
      case 'h':
        usage();
        break;
      case 'v':
        version();
        break;
      case 'd':
	/* get database file */
	if(argc < i+2) usage();
	args.db_file = (char *) calloc(strlen(argv[i+1]) + 1, sizeof(char));
	strcpy(args.db_file,argv[i+1]);
        break;
      case 'q':
	/* get query file */
	if(argc < i+2) usage();
	args.q_file = (char *) calloc(strlen(argv[i+1]) + 1, sizeof(char));
	strcpy(args.q_file, argv[i+1]);
	break;
      case 'c':
	/* get config file */
	if(argc < i+2) usage();
	args.cfg_file = (char *) calloc(strlen(argv[i+1]) + 1, sizeof(char));
	strcpy(args.cfg_file, argv[i+1]);
	break;
      case 'e':
	/* set match score */
	if(argc < i+2) usage();
	args.e = log10(strtod(argv[i+1], NULL));
	/* args.e = strtod(argv[i+1], NULL); */
	break;
      case 'p':
	/* set match score */
	if(argc < i+2) usage();
	args.p = atof(argv[i+1]);
	break;
      case 'o':
	/* set match score */
	if(argc < i+2) usage();
	args.out = atoi(argv[i+1]);
	break;
      case 's':
	/* set 'give score data' to 'true' */
	/* args.s = atoi(argv[i+1]); */
	args.s = 1;
	break;
      case '-':
	if(strcmp(argv[i],      "--help"     ) ==0) usage();
        else if(strcmp(argv[i], "--version"  ) ==0) version();
	else if(strcmp(argv[i], "--verbose"  ) ==0) args.verbose = 1;
	else if(strcmp(argv[i], "--split"    ) ==0) args.split = atoi(argv[i+1]);
	else if(strcmp(argv[i], "--config"   ) ==0) {
	  if(argc < i+2) usage();
	  args.cfg_file = (char *) calloc(strlen(argv[i+1]) + 1, sizeof(char));
	  strcpy(args.cfg_file, argv[i+1]);
	}
	else usage();
	break;
      default:
	usage();
      }
    }
  }

  if(args.cfg_file == NULL) {
    if(args.db_file == NULL && args.q_file != NULL) {
      gotoh_freeArguments(args);
      gotoh_Error("Specify query file OR give configuration file using -c|--config option",args.verbose);
    } else if(args.db_file != NULL && args.q_file == NULL) {
      gotoh_freeArguments(args);
      gotoh_Error("Specify databse file OR give configuration file using -c|--config option",args.verbose);
    } 
  } else {
    if(args.db_file == NULL && args.q_file != NULL) {
      gotoh_Warning("Database files given to GotohScan via config file and command prompt differ. Settings given in config-file taken",args.verbose);
    }
  }

  if(args.p != -1 && (args.p < 0 || args.p > 100)) {
    gotoh_Warning("Percent Identity you set makes no sense. Set to default: 70",args.verbose);
    args.p = 70;
  }
  if(args.e != 999999 && args.e > 10) {
    gotoh_Warning("Your Evalue makes no sense. Set to default: 1e-3",args.verbose);
    args.e = log10(1e-3);
  }
  
  return args;
  
}

/* -------------------------------------------------------------------------- */

struct gotoh_settings gotoh_readSettings(gotoh_arguments ga) {

  FILE *fp=NULL;
  char parameter[1024], value[1024], *line=NULL;
  gotoh_settings cfg;

  cfg = gotoh_initSettings();

  if(ga.cfg_file == NULL) {
    cfg.dbase = ga.db_file;
    cfg.query = ga.q_file;
    cfg.output_format = ga.out;
    cfg.usrE = ga.e;
    cfg.percID = ga.p;
    cfg.output_data = ga.s;
    cfg.verbose = ga.verbose;
    return cfg;
  }
  
  fp = fopen(ga.cfg_file, "r");
  
  if(fp==NULL) {
    gotoh_freeArguments(ga);
    gotoh_Error("Error: can't access config file", ga.verbose);
  } else {
    while(!feof(fp)) {
      line = get_line(fp);
      /* line = fgets(s, 1024, fp); */
      if(line == NULL) break;
      
      if(line[0] == '#' || strlen(line) < 1) {
	free(line);
	continue;
      }
      sscanf(line, "%s %s", parameter, value);
      /* fscanf(fp, "%s %s", parameter, value); */
      /* fprintf(stderr, "%s %s\n",parameter, value); */
      if(line[0] == '#' || line[0] == '\0' || strlen(line) < 1) {
	continue;
      }
      if(strcmp(parameter,"DBASE")==0) {
	if(ga.db_file !=NULL) {
	  if(strcmp(ga.db_file,value)==0) { 
	    cfg.dbase = (char *) calloc(strlen(value)+1, sizeof(char));
	    strcpy(cfg.dbase, value);
	  } else { /* overwrite config file entry with -d file */
	    cfg.dbase = (char *) calloc(strlen(ga.db_file)+1, sizeof(char));
	    strcpy(cfg.dbase, ga.db_file);
	  }
	} else {
	  cfg.dbase = (char *) calloc(strlen(value)+1, sizeof(char));
	  strcpy(cfg.dbase, value);
	}
      } else if(strcmp(parameter, "QUERY") == 0) {
	if(ga.q_file != NULL) {
	  if(strcmp(ga.q_file,value)==0) {
	    cfg.query = (char *) calloc(strlen(value)+1, sizeof(char));
	    strcpy(cfg.query, value);
	  } else { /* overwrite config file entry with -q file */
	    cfg.query = (char *) calloc(strlen(ga.q_file)+1, sizeof(char));
	    strcpy(cfg.query, ga.q_file);
	  }
	} else {
	  cfg.query = (char *) calloc(strlen(value)+1, sizeof(char));
	    strcpy(cfg.query, value);
	}
      } else if(strcmp(parameter, "GAPOPEN") == 0) {
	cfg.gap_open = atof(value);
      } else if(strcmp(parameter, "GAPEXTEND") == 0) {
	cfg.gap_extend = atof(value);
      } else if(strcmp(parameter, "MATCH") == 0) {
	cfg.match = atof(value);
      } else if(strcmp(parameter, "MISMATCH") == 0) {
	cfg.mismatch = atof(value);
      } else if(strcmp(parameter, "E-VALUE") == 0) { 
	if(ga.e != 999999) cfg.usrE = ga.e;
	else cfg.usrE = log10(strtod(value, NULL));
      } else if(strcmp(parameter, "PERCID") == 0) {
	if(ga.p != -1) cfg.percID = ga.p;
	else cfg.percID = atof(value);
      } else if(strcmp(parameter, "OUTPUT_FORMAT") == 0) {
	if(ga.out != -1) cfg.output_format = ga.out;
	else cfg.output_format = atof(value);
      } else if(strcmp(parameter, "PRINT_HISTO") == 0) {
	if(ga.s != -1) cfg.output_data = ga.s;
	else cfg.output_data = atoi(value);
	if(cfg.output_data != 1) cfg.output_data = 0;
      } else if(strcmp(parameter, "DATA_FILE") == 0) {
	cfg.data_file = (char *) calloc(strlen(value)+1, sizeof(char));
	strcpy(cfg.data_file, value);
      } else {
	fprintf(stderr, "There is a problem with the format of the config file\n\n");
	/* fprintf(stderr, "P:%s", parameter); */
	gotoh_freeSettings(cfg);
	exit(EXIT_FAILURE);
      }
      free(line);
    }
  }

  cfg.inf = 999999999;

  fclose(fp);

  return cfg;
  
}

/* init functions ----------------------------------------------------------- */

gotoh_arguments gotoh_initArguments() {

  gotoh_arguments a;

  a.cfg_file = NULL;
  a.db_file = NULL;
  a.q_file = NULL;
  a.e = -3;
  a.p = -1;
  a.out = 0;
  a.s = -1;
  a.help = 0;
  a.version = 0;
  a.verbose = 0;
  a.split = 10000;
  
  return a;
  
}

/* -------------------------------------------------------------------------- */

gotoh_settings gotoh_initSettings() {

  gotoh_settings s;

  /* input */
  s.dbase=NULL;
  s.query=NULL;
  /* alignment parameters / scores */
  s.gap_open = -8;
  s.gap_extend = -2;
  s.match = 3;
  s.mismatch = -1;
  s.matchN = 0;
  s.inf = 999999999;
  /* filter */
  s.usrE = -3;
  s.percID = -1;
  s.output_data = 1;
  /* output */
  s.output_format = 0;
  s.data_file=NULL;
  s.verbose = 0;
  
  return s;
  
}

/* print functions ---------------------------------------------------------- */

void gotoh_printArguments(gotoh_arguments ga) {

  fprintf(stdout, "\nArguments:\n----------\n");
  fprintf(stdout, "Config file: %s\n",ga.cfg_file);
  fprintf(stdout, "Dbase file:  %s\n",ga.db_file);
  fprintf(stdout, "Query file:  %s\n",ga.q_file);
  fprintf(stdout, "Help:        %d\n",ga.help);
  fprintf(stdout, "Version:     %d\n",ga.version);

}

/* -------------------------------------------------------------------------- */

void gotoh_printSettings(gotoh_settings gs) {

  fprintf(stdout, "\nSettings:\n---------\n");
  fprintf(stdout, "Dbase file: %s\n",gs.dbase);
  fprintf(stdout, "Query file: %s\n",gs.query);
  fprintf(stdout, "Gap open:   %3d\n", gs.gap_open);
  fprintf(stdout, "Gap extend: %3d\n", gs.gap_extend);
  fprintf(stdout, "Match:      %3d\n", gs.match);
  fprintf(stdout, "Mismatch:   %3d\n", gs.mismatch);
  fprintf(stdout, "Inf:        %d\n", gs.inf);
  fprintf(stdout, "E-value:    %.2e\n", pow(10,gs.usrE));
  fprintf(stdout, "Perc Ident.:%5.2f\n", gs.percID);
  fprintf(stdout, "Output:     %3d\n", gs.output_format);

}
/* -------------------------------------------------------------------------- */

void usage() {

  fprintf(stdout, "\n         GotohScan 1.3\n         =============\n");
  fprintf(stdout, "\nUsage: GotohScan [ arguments ] \n\n");
  fprintf(stdout, "arguments: [-d,--dbase FILE] [-q,--query FILE]\n");
  fprintf(stdout, "           [-e NUMBER] [-p NUMBER] [-o NUMBER]\n");
  fprintf(stdout, "           [-s] [--verbose 0|1] [-c,--config FILE]\n");
  fprintf(stdout, "           [--split NUMBER] [-h,--help] [-v,--version]\n\n");
  fprintf(stdout, "\nIf no configuration file given, required arguments are:\n");
  fprintf(stdout, "%-20s Input database FILE in FASTA format.\n", "-d,--dbase FILE");
  fprintf(stdout, "%-20s Input query FILE in FASTA format.\n", "-q,--query FILE");
  fprintf(stdout, "\n");
  fprintf(stdout, "%-20s Input configuration FILE.\n\n", "-c,--config FILE");
  fprintf(stdout, "%-20s Database is splitted into NUMBER nt large subsequences. Default: 10000\n", "--split NUMBER");
  fprintf(stdout, "\nOptions that overwrite settings in configuration file (if given)\n");
  fprintf(stdout, "%-20s Set Evalue (double!). NUMBER should be < 10. Default: 1e-3\n","-e NUMBER");
  fprintf(stdout, "%-20s Set percent identity of aligned sequences. NUMBER should be in [0.0,100.0]\n","-p NUMBER");
  fprintf(stdout, "%-20s Print score distribution data for each query to a file. Default: unset\n","-s");
  fprintf(stdout, "%-20s Produces an xmgrace (.agr) file!\n","");
  fprintf(stdout, "%-20s Give output format. Default: 0\n", "-o NUMBER");
  fprintf(stdout, "%-20s \t0 - Blast tabular output\n","");
  fprintf(stdout, "%-20s \t1 - Blast tabular output + aligned sequences\n","");
  fprintf(stdout, "%-20s \t2 - FASTA format. NOTE: Hit sequence only, without gaps !\n","");
  fprintf(stdout, "%-20s \t3 - MAF format. NOTE: Header truncated to 30 characters!\n","");
  fprintf(stdout, "%-20s \t4 - BED + aligned sequences\n","");
  fprintf(stdout, "%-20s \t5 - GFF + aligned sequences\n\n","");
  fprintf(stdout, "%-20s Print Warnings and Notes. Default: 0\n\n","--verbose 0|1");
  fprintf(stdout, "%-20s Show this help message.\n", "-h,--help");
  fprintf(stdout, "%-20s Show version information.\n\n", "-v,--version");
  fprintf(stdout, "\nAlignment parameters and all other options can\n");
  fprintf(stdout, "also be set in a configuration file\n");
  fprintf(stdout, "see 'settings.cfg' as an example.\n\n");
  fprintf(stdout, "\nPlease feel free to contact me for comments, bug-reports, etc.\n\n");

  version();

}

/* -------------------------------------------------------------------------- */

void version() {
  
  fprintf(stdout, "\n         GotohScan 1.3\n         =============\n\n");
  fprintf(stdout, "Auhthor: Jana Hertel:\n");
  fprintf(stdout, "         jana@bioinf.uni-leipzig.de\n\n");
  fprintf(stdout, "Date:    March 5, 2009\n\n");
  
  exit(EXIT_SUCCESS);
  
}

/* free functions ----------------------------------------------------------- */

void gotoh_freeArguments(gotoh_arguments ga) {

  if(ga.cfg_file != NULL) free(ga.cfg_file);
  if(ga.db_file != NULL) free(ga.db_file);
  if(ga.q_file != NULL) free(ga.q_file);
  
}

/* -------------------------------------------------------------------------- */

void gotoh_freeSettings(gotoh_settings gs) {

  if(gs.dbase != NULL) free(gs.dbase);
  if(gs.query != NULL) free(gs.query);
  if(gs.data_file != NULL) free(gs.data_file);
  
}

/* other functions ---------------------------------------------------------- */

void gotoh_Error(char *msg, int v) {

  if(v == 1) {
    fprintf(stderr, "ERROR: %s\n",msg);
    exit(EXIT_FAILURE);
  }
}

/* -------------------------------------------------------------------------- */

void gotoh_Warning(char *msg, int v) {

  if(v == 1)
    fprintf(stderr, "WARNING: %s\n",msg);
  
}

/* -------------------------------------------------------------------------- */

void gotoh_Note(char *msg, int v) {

  if(v == 1)
    fprintf(stderr, "NOTE: %s\n",msg);
   
}

/* -------------------------------------------------------------------------- */
