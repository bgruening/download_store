#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include "read.h"
#include "calc.h"
#include "fasta.h"

char bases[33] = "ACGUTRYMKWSBDHVNacgutrymkwsbdhvnt";
int gotoh_Table[128][128];

int main(int argc, char *argv[]) {

  gotoh_arguments arg;
  gotoh_settings cfg;
  gotoh_aln L[MAX_ALNS];   /* list of best MAX_ALNS alignments per query */
  
  int i, s, e, m, mod, cmod, ssl;   /* number of db/query sequences */
  char *q_seq=NULL, *q_name=NULL, *db_seq=NULL, *db_name=NULL, *sseq=NULL;
  FASTAFILE *fp_db=NULL, *fp_q=NULL;
  int q_len=0, db_len=0;
  int *score_distr=NULL, lo=0, up=0, lo_transf=0, up_transf=0, size=0;
  int *ntf=NULL, N=0;
  double * p=NULL;

  /* scoring parameters */
  double x, z, eval,km1,logt,logN,logG,ua;
  int p_mean, upnew;

  arg = gotoh_readArguments(argc, argv);  /* gotoh_printArguments(arg); */
   
  cfg = gotoh_readSettings(arg);  /* gotoh_printSettings(cfg); */

  if(cfg.output_format < 0 || cfg.output_format > 6) {
    gotoh_Warning("Invalid output format. Set to default: 0 (BLAST, tabular)", arg.verbose);
    cfg.output_format = 0;
  }
  if(cfg.output_format == 3) 
    gotoh_Note("Header information is cut to 30 characters. Check for Identity!",arg.verbose);
  else if(cfg.output_format == 2)
    gotoh_Note("Only hitsequence is returned. Gaps are removed!", arg.verbose);
    
  fp_q = OpenFASTA(cfg.query);

  if(fp_q==NULL) {
    fprintf(stderr, "Cannot access query file: '%s'.\n",cfg.query);
    gotoh_freeArguments(arg);
    gotoh_freeSettings(cfg);    
    exit(0);
  }

  /* cfg.match *= SCALE; */
/*   cfg.mismatch *= SCALE; */
/*   cfg.gap_open *= SCALE; */
/*   cfg.gap_extend *= SCALE; */
    
  gotoh_initMatchTable(cfg);

  while(ReadFASTA(fp_q, &q_seq, &q_name, &q_len)) { /* for each query sequence ... */

    /* init a candidates array */
    for(i=0; i<MAX_ALNS; i++){
      L[i] = gotoh_initL();
      /* gotoh_printGotohAln(L[i]); */
    }

    /* init a score array */
    lo = 2 * (cfg.gap_open + ((q_len - 1) * cfg.gap_extend));
    up = cfg.match * q_len;
    lo_transf = 0;           /* transformation: score += lo */
    up_transf = abs(up) + abs(lo); 
    /* size = up_transf + 1;  */   /* 1 => add 0 */
    size = abs(lo) + abs(up) + 1;

    /* storage for not-transformed scores */
    ntf = (int *) calloc(size + 1, sizeof(int));
    /* distribution of all possible scores per query */
    score_distr = (int *) calloc(size + 1, sizeof(int));
    for(i=0; i<size; i++) {
      score_distr[i] = 0;
      ntf[i] = 0;
    }

    m = 2*q_len;

    fp_db = OpenFASTA(cfg.dbase); /* abfangen on error!!! */
    if(fp_db == NULL) {
      fprintf(stderr, "Cannot access database file: '%s'.\n",cfg.dbase);
      free(q_seq); free(q_name); free(score_distr);
      exit(0);
     
    }

    while(ReadFASTA(fp_db, &db_seq, &db_name, &db_len)) {

      if(db_len < q_len) {
	if(cfg.verbose == 1) {
	  fprintf(stderr, "WARNING: Database sequence shorter than query.\n");
	  fprintf(stderr, "     DB: %s length: %d\n",db_name,db_len);
	  fprintf(stderr, "  QUERY: %s length: %d\n",q_name,q_len);
	  fprintf(stderr, "skipping %s.\n",db_name);
	}
	free(db_seq);
	free(db_name);
	continue;
      } else if(arg.split > 0 && db_len > arg.split) {
	/* db_seq too long, split in arg.split+-2*q_len overlapping parts */

	mod = floor((float) db_len / (float) arg.split);
	if(mod * arg.split < db_len) mod += 1;
	
	/* s and e are real computer positions of db_seq => [0,db_len-1] !!! */
	s = 0; e = arg.split + m - 1;
	cmod = 1;
	fprintf(stderr, "# Q: %s ==> DB: %s (%d)\n",q_name,db_name,db_len);
	
	while(cmod <= mod) {
	  /* do stuff with sequence, uebergib s fuer coord parsing! */
	  ssl = e - s + 1;
	  sseq = (char *) calloc(ssl + 1, sizeof(char));
	  /* printf("%d %d\n",ssl, arg.split); */
	  strncpy(sseq, db_seq+s, ssl);
	 /*  printf("%10d %10d-%10d: %d\t%s\n",cmod,s,e,strlen(sseq),sseq); */

	  gotoh_scanDbase(sseq, ssl, q_seq, q_len, db_name, q_name, score_distr, size,
			  cfg, L, s, db_len, ntf);

	  fprintf(stderr, "\r#    %-5.2f %% (%d)", ((float) e + 1)/ (float) db_len * 100, db_len);
	  
	  if(e == db_len-1) { free(sseq); break; }
	  
	  
	  s = arg.split * cmod;
	  e = s + arg.split + m - 1 < db_len ? s + arg.split + m - 1 : db_len - 1; 
	  
	  cmod++;
	  free(sseq);
	}
	N++;
	fprintf(stderr,"\n");
      } else { /* db_seq shorter than SSl or split < 0 (unset) -> work with complete db_seq */
	/* do stuff with sequence */

	N++; /* count database entries */
	fprintf(stderr, "# Q: %s ==> DB: %s\n",q_name,db_name);
	
	fprintf(stderr, "#    100.00 %% (%d)\n", db_len);
	
	gotoh_scanDbase(db_seq, db_len, q_seq, q_len, db_name, q_name, score_distr,
			size, cfg, L, 0, db_len, ntf);
      }

      free(db_name);
      free(db_seq);
    }
  
    CloseFASTA(fp_db);

    if(N > 0) {
      /* use data for fitting */
      /* for(i=0; i<MAX_ALNS; i++) { */
/* 	if(L[i].alnscore == -1) break; */
/* 	fprintf(stderr,"L[%d] = %d %s %s %c\n",i,L[i].alnscore,L[i].hitseq,L[i].queryseq,L[i].strand); */
/*       } */
      /* for(i=0;i<size;i++) */
/* 	fprintf(stderr, "score_distr[%d]=%d\n",i,score_distr[i]); */
/*       exit(0); */

      p = gotoh_getParams(score_distr, size, q_len, cfg, q_name, ntf);
      /* p[0] => k  p[1] => theta p[2] => gamma(k)  p[3] => N (vom schaetzen) */
      km1 = p[0] - 1;
      logt = log(p[1]);
      logG = p[2];
      logN = log(p[3]);
      p_mean = (int) floor(p[0] * p[1]) + 1;

      upnew = abs(lo) + up;
      /* for score > k*theta to max score */
      /*  for(i=p_mean; i<=upnew; i++) { */
      for(i=0; i<MAX_ALNS; i++) {
	if(L[i].ntfalnscore == -1) break;
	if(L[i].ntfalnscore == 0) continue;
	/* x = (double) L[i].alnscore; */
	x =  L[i].ntfalnscore;
	/* fprintf(stderr,"ss: %d\n",L[i].alnscore); */
	z = x / p[1];
	ua = gotoh_uFunction(p[0], z);
	eval = (logN + km1 * log(z) - z + log(ua) - logG)/log(10);
	if(eval <= cfg.usrE + 1) {
	  /* fprintf(stderr,"%d: %d\n",i,L[i].alnscore); */
	  /* fprintf(stderr, "Evalue: %e e: %e\n",cfg.usrE,eval); */
	  L[i].Levalue = eval;
	  L[i].evalue = pow(10,eval);
	  if(cfg.percID != -1){
	    if(L[i].percID >= cfg.percID) {
	      gotoh_printGotohAln(L[i], cfg.output_format);
	    }
	  } else {
	    gotoh_printGotohAln(L[i], cfg.output_format);
	  }
	}
	if(L[i].ntfalnscore > -1) {
	  free(L[i].hitname); free(L[i].hitseq);
	  free(L[i].queryname); free(L[i].queryseq);
	  /* L[i] = gotoh_initL(); */
 	}
      }
    } else {
      fprintf(stderr, "\nWARNING: No database entries read for query '%s'\n",q_name);
      fprintf(stderr, "         db might be shorter than query?!\n\n");
    }
    N = 0;
    
    /* fflush(stderr); */
/*     fflush(stdout); */

    fflush(NULL);
    
    free(p);
    free(score_distr);
    free(q_seq);
    free(q_name);
    
  }
  
  CloseFASTA(fp_q);
  
  /* free all remaining stuff */
  gotoh_freeArguments(arg);
  if(arg.cfg_file != NULL) gotoh_freeSettings(cfg);
  
  return 0;
  
}
