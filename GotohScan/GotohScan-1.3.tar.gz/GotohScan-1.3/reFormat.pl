#!/usr/bin/perl -w

use Getopt::Long;
use Pod::Usage;

my $man = 0;
my $help = 0;
my ($file, $inF, $outF) = ('', -1, -1);
## Parse options and print usage if there is a syntax error,
## or if usage was explicitly requested.
GetOptions(
	   'help|?' => \$help,
	   'man' => \$man,
	   'i=s' => \$file,
	   'inF=i' => \$inF,
	   'outF=i' => \$outF
	  ) or pod2usage(-verbose => 99, -section => "NAME|SYNOPSIS");
pod2usage(-verbose => 99, -section => "NAME|SYNOPSIS") if $help;
pod2usage(-verbose => 2) if $man;

if($file eq '') {
  printf STDERR "\nGive input file name\n";
  pod2usage(-verbose => 99, -section => "NAME|SYNOPSIS");
}
if($inF == -1 || $outF == -1) {
  printf STDERR "\nGive both, in- and output format\n";
  pod2usage(-verbose => 99, -section => "NAME|SYNOPSIS");
}
if($inF == $outF) {
  printf STDOUT "\nIn and output format equal.\nNothing to do for %s\n",$0;
  exit(0);
}

if($inF < 0 || $inF > 5) {
  printf STDERR "\nInvalid input format\n";
  pod2usage(-verbose => 99, -section => "NAME|SYNOPSIS");
}
if($outF < 0 || $outF > 5) {
  printf STDERR "\nInvalid output format\n";
  pod2usage(-verbose => 99, -section => "NAME|SYNOPSIS");
}

if($inF == 0) {
  printf STDERR "\nSorry, this format cannot be changed into a different one, since there are no sequences given\n";
  pod2usage(-verbose => 99, -section => "NAME|SYNOPSIS");
}

# Read file in input format -------------------------------------------------- #

my ($c,%alns);
$c = 0; # count alns, use as id

if($inF == 1) { # BLAST + sequences
  printf STDERR "InFormat: BLAST + sequences\n";
  open(I, $file) or die $!;
  while(<I>) {
    chomp();
    my @x = split /\s+/,$_;
    $alns{$c}{qname} = $x[0];
    $alns{$c}{hname} = $x[1];
    $alns{$c}{percID} = $x[2];
    if($x[8] > $x[9]) {
      $alns{$c}{strand} = '-';
      $alns{$c}{start} = $x[9];
      $alns{$c}{end} = $x[8];
    } else {
      $alns{$c}{start} = $x[8];
      $alns{$c}{end} = $x[9];
      $alns{$c}{strand} = '+';
    }
    $alns{$c}{evalue} = $x[10];
    $alns{$c}{hseq} = substr($x[11],0,index($x[11],"&"));
    $alns{$c}{qseq} = substr($x[11],index($x[11],"&")+1);
    $c++;
  }
  close(I);

} elsif($inF == 2) { # FASTA (hitseq only)

  printf STDERR "InFormat: FASTA (hitseq only)\n";
  printf STDERR "\nWARNING: This format does not have the sequence alignment and cannot be transformed to CLUSTAL format (3).\nAdditionally, the queryseq entry in the formats 1,4 and 5 will be missing\n";
  exit(0) if($outF == 3);

  open(I, $file) or die $!;
  while(<I>) {
    chomp;
    if($_ =~ /^>(\S+)$/) {
      @x = split /\:/,$1;
      $alns{$c}{qname} = $x[0];
      $alns{$c}{hname} = $x[1];
      $alns{$c}{percID} = $x[4];
      $alns{$c}{strand} = $x[3];
      $alns{$c}{start} = substr($x[2],0,index($x[2],"-"));
      $alns{$c}{end} = substr($x[2],index($x[2],"-")+1);
      $alns{$c}{evalue} = $x[5];
      $alns{$c}{qseq} = '';
    } else {
      $alns{$c}{hseq} = $_;
      $c++;
    }
  }
  close(I);

} elsif($inF == 3) { # MAF

  printf STDERR "InFormat: MAF\n";
  my $ddone=0;
  open(I, $file) or die $!;
  while(<I>) {
    chomp;
    if($_ =~ /^a score=(\S+)/) {
      $alns{$c}{evalue} = $1;
      $ddone = 0;
    } else {
      my @x =split /\s+/,$_;
      if(scalar @x == 0) { $c++; next; }
      else {
	if($ddone == 0) {
	  $alns{$c}{hname} = $x[0];
	  $alns{$c}{strand} = $x[3];
	  $alns{$c}{start} = $x[1];
	  my $tmp = $x[5];
	  $tmp =~ s/\-//g;
	  $alns{$c}{end} = $x[1] + length($tmp);
	  $alns{$c}{hseq} = $x[5];
	  $ddone = 1;
	} else {
	  $alns{$c}{qname} = $x[0];
	  $alns{$c}{qseq} = $x[5];
	  my $p = 0;
	  my @q = split //,$alns{$c}{qseq};
	  my @d = split //,$alns{$c}{hseq};
	  for(my $i=0; $i<scalar @q;$i++) { if($q[$i] eq $d[$i]) { $p++; } }
	  $p /= scalar @q;
	  $p *= 100;
	  $alns{$c}{percID} = $p;
	}
      }
    }

  }
  close(I);

} elsif($inF == 4) { # BED + sequences

  printf STDERR "InFormat: BED\n";
  open(I, $file) or die $!;
  while(<I>) {
    chomp;
    my @x = split /\s+/,$_;
    $alns{$c}{hname} = $x[0];
    $alns{$c}{qname} = $x[3];
    $alns{$c}{start} = $x[1];
    $alns{$c}{end} = $x[2];
    $alns{$c}{evalue} = $x[4];
    $alns{$c}{strand} = $x[5];
    $x[6] =~ s/"//g;
    $x[6] =~ s/note=//;
    $alns{$c}{hseq} = substr($x[6],0,index($x[6],"&"));
    $alns{$c}{qseq} = substr($x[6],index($x[6],"&")+1);
    my $p = 0;
    my @q = split //,$alns{$c}{qseq};
    my @d = split //,$alns{$c}{hseq};
    for(my $i=0; $i<scalar @q;$i++) { if($q[$i] eq $d[$i]) { $p++; } }
    $p /= scalar @q;
    $p *= 100;
    $alns{$c}{percID} = $p;
    $c++;
  }
  close(I);

} elsif($inF == 5) { # GFF + sequences

  printf STDERR "InFormat: GFF\n";
  open(I, $file) or die $!;
  while(<I>) {
    chomp;
    my @x = split /\s+/,$_;
    $alns{$c}{hname} = $x[0];
    $alns{$c}{qname} = $x[2];
    $alns{$c}{start} = $x[3];
    $alns{$c}{end} = $x[4];
    $alns{$c}{evalue} = $x[5];
    $alns{$c}{strand} = $x[6];
    $x[7] =~ s/"//g;
    $x[7] =~ s/note=//;
    $alns{$c}{hseq} = substr($x[7],0,index($x[7],"&"));
    $alns{$c}{qseq} = substr($x[7],index($x[7],"&")+1);
    my $p = 0;
    my @q = split //,$alns{$c}{qseq};
    my @d = split //,$alns{$c}{hseq};
    for(my $i=0; $i<scalar @q;$i++) { if($q[$i] eq $d[$i]) { $p++; } }
    $p /= scalar @q;
    $p *= 100;
    $alns{$c}{percID} = $p;
    $c++;
  }
  close(I);

}

# Print data in output format ------------------------------------------------ #

for(my $i=0; $i<$c; $i++) {
  printf "c: %d\n",$i;
  if($outF == 0) { # BLAST without sequences

    printf "%s\t%s\t%5.2f\t",$alns{$i}{qname},$alns{$i}{hname},$alns{$i}{percID};
    my ($mm,$gos) = (0,0);
    my @x = split //,$alns{$i}{hseq};
    my @y = split //,$alns{$i}{qseq};
    for(my $j=0;$j<length($alns{$i}{hseq});$j++) {
      if($x[$j] != $y[$j] && $x[$j] != '-' && $y[$j] != '-') { $mm++; }
      if($x[$j] == '-' && $x[$j-1] != '-') { $gos++; }
      if($y[$j] == '-' && $y[$j-1] != '-') { $gos++; }
    }
    my $seq = $alns{$i}{qseq};
    $seq =~ s/\-//g;
    printf "%d\t%d\t%d\t",length($alns{$i}{hseq}),$mm,$gos;
    printf "%d\t%d\%d\%d\t",1,length($seq),$alns{$i}{start},$alns{$i}{end};
    printf "%e\n",$alns{$i}{evalue};

  } elsif($outF == 1) { # BLAST + sequences

    printf "%s\t%s\t%5.2f\t",$alns{$i}{qname},$alns{$i}{hname},$alns{$i}{percID};
    my ($mm,$gos) = (0,0);
    my @x = split //,$alns{$i}{hseq};
    my @y = split //,$alns{$i}{qseq};
    for(my $j=0;$j<length($alns{$i}{hseq});$j++) {
      if($x[$j] != $y[$j] && $x[$j] != '-' && $y[$j] != '-') { $mm++; }
      if($x[$j] == '-' && $x[$j-1] != '-') { $gos++; }
      if($y[$j] == '-' && $y[$j-1] != '-') { $gos++; }
    }
    my $seq = $alns{$i}{qseq};
    $seq =~ s/\-//g;
    printf "%d\t%d\t%d\t",length($alns{$i}{hseq}),$mm,$gos;
    printf "%d\t%d\%d\%d\t",1,length($seq),$alns{$i}{start},$alns{$i}{end};
    printf "%e\t",$alns{$i}{evalue};
    printf "%s&%s\n",$alns{$i}{hseq},$alns{$i}{qseq};

  } elsif($outF == 2) { # FASTA

    printf ">%s:%s:%d",$alns{$i}{qname},$alns{$i}{hname},$alns{$i}{start};
    printf "-%d:%s:%.2f:%e\n",$alns{$i}{end},$alns{$i}{strand},$alns{$i}{percID},$alns{$i}{evalue};
    my $seq = $alns{$i}{hseq};
    $seq =~ s/\-//g;
    printf "%s\n",$seq;

  } elsif($outF == 3) { # MAF

    my $seq = $alns{$i}{hseq};
    $seq =~ s/\-//g;
    my $l = length($seq);
    my $dbl = int($l/10)*10;
    $dbl =~ s/./9/g;
    printf "a score=%e\n",$alns{$i}{evalue};
    printf "%-30s %13d %5d %c %13d %s\n",$alns{$i}{hname},$alns{$i}{start},$l,$alns{$i}{strand},$dbl,$alns{$i}{hseq};
    $seq = $alns{$i}{qseq};
    $seq =~ s/\-//g;
    $l = length($seq);
    printf "%-30s %13d %5d %c %13d %s\n\n",$alns{$i}{qname},'1',$l,'+',$l,$alns{$i}{qseq};
  } elsif($outF == 4) { # BED + sequences

    printf "%s\t%d\t%d\t%s\t",$alns{$i}{hname},$alns{$i}{start},$alns{$i}{end},$alns{$i}{qname};
    printf "%e\t%c\tnote=\"%s&%s\"\n",$alns{$i}{evalue},$alns{$i}{strand},$alns{$i}{hseq},$alns{$i}{qseq};

  } elsif($outF == 5) { # GFF + sequences

    printf "%s\tGotohScan\t%s\t%d\t",$alns{$i}{hname},$alns{$i}{qname},$alns{$i}{start};
    printf "%d\t%e\t%c\t",$alns{$i}{end},$alns{$i}{evalue},$alns{$i}{strand};
    printf "note=\"%s&%s\"\n",$alns{$i}{hseq},$alns{$i}{qseq};

  }
}


# ---------------------------------------------------------------------------- #

__END__

=head1 NAME

reFormat.pl - Changing the output formats of GotohScan.

=head1 SYNOPSIS

reFormat.pl -i FILE -inF NUMBER -outF NUMBER [-h|help|man]

=head1 OPTIONS

=over 8

=item B<-help>

Print a brief help message and exits.

=item B<-man>

Prints the manual page and exits.

=item B<-i FILE>

Give the name of your GotohScan output file.

=item B<-inF NUMBER>

Give the format number of your GotohScan output file. NUMBER is in
[1,5]. Default of GotohScan is 0 (BLAST), however, it is not possible
to change this format into one of the others, since the sequences are
not returned wit -o 0 in GotohScan.

=item B<-outF NUMBER>

Give the number of the format you want to create:

0 - Blast tabular output

1 - Blast tabular output + aligned sequences

2 - FASTA format. NOTE: Hit sequence only, without gaps !

3 - CLUSTAL W format. NOTE: Header truncated to 30 characters!

4 - BED + aligned sequences

5 - GFF + aligned sequences


=back

=head1 DESCRIPTION

B<reFormat.pl> will change the format of a GotohScan output file into a different
kind of format which is also possible with GotohScan.

=cut
