#include "calc.h"
#include "gammatable.h"

/* extern float gammatable[10001][2]; */

extern char bases[]; /* ACGUTRYMKWSBDHVNacgutrymkwsbdhvnt */
extern int gotoh_Table[128][128];

/*
  A  C  G  U  T  R  Y  M  K  W  S  B  D  H  V  N  
 65 67 71 85 84 82 89 77 75 87 83 66 68 72 86 78
  a  c  g   u   t   r   y   m   k   w   s   b   d   h   v   n   t
 97 99 103 117 116 114 121 109 107 119 115 98  100 104 118 110 116
*/

/* conservative statistical estimation of score distribution */

int nalns = 0;

/* -------------------------------------------------------------------------- */

void gotoh_initMatchTable(gotoh_settings gs) {

  int i, j, l, ni, nj, score;
  char *m=NULL;

  for(i=0; i<128; i++) {
    for(j=0; j<128; j++) {
      if(i>j) continue;
      gotoh_Table[j][i] = gs.mismatch;
      gotoh_Table[i][j] = gs.mismatch;
    }
  }

  for(i=0; i<16; i++) {
    ni = bases[i]; /* i pos in table */
    for(j=0; j<16; j++) {
      if(i>j) continue;
      nj = bases[j]; /* j pos in table */
      if(i < 5 && i == j) {
	gotoh_Table[ni][nj] = gs.match;
	gotoh_Table[ni+32][nj] = gs.match;
	gotoh_Table[ni][nj+32] = gs.match;
	gotoh_Table[nj][ni] = gs.match;
	gotoh_Table[nj+32][ni] = gs.match;
	gotoh_Table[nj][ni+32] = gs.match;
	gotoh_Table[ni+32][nj+32] = gs.match;
	gotoh_Table[nj+32][ni+32] = gs.match;
      } else if(i < 11 && i == j) {
	score = floor(0.5 * gs.match + 0.5 * gs.mismatch);
	gotoh_Table[ni][nj] = score;
	gotoh_Table[ni+32][nj] = score;
	gotoh_Table[ni][nj+32] = score;
	gotoh_Table[nj][ni] = score;
	gotoh_Table[nj+32][ni] = score;
	gotoh_Table[nj][ni+32] = score;
	gotoh_Table[ni+32][nj+32] = score;
	gotoh_Table[nj+32][ni+32] = score;
      } else if(i < 15 && i == j) {
	score = floor((float) gs.match / 3 + (float)gs.mismatch / 3);
	gotoh_Table[ni][nj] = score;
	gotoh_Table[ni+32][nj] = score;
	gotoh_Table[ni][nj+32] = score;
	gotoh_Table[nj][ni] = score;
	gotoh_Table[nj+32][ni] = score;
	gotoh_Table[nj][ni+32] = score;
	gotoh_Table[ni+32][nj+32] = score;
	gotoh_Table[nj+32][ni+32] = score;
      } else if(i == 16 && j == 16) {
	score = floor((float) gs.match / 4 + (float)gs.mismatch / 4);
	gotoh_Table[ni][nj] = score;
	gotoh_Table[ni+32][nj] = score;
	gotoh_Table[ni][nj+32] = score;
	gotoh_Table[nj][ni] = score;
	gotoh_Table[nj+32][ni] = score;
	gotoh_Table[nj][ni+32] = score;
	gotoh_Table[ni+32][nj+32] = score;
	gotoh_Table[nj+32][ni+32] = score;
      }
    }
  }
  
  /* [U,T] -> [u,t] = match ! */
  gotoh_Table[84][85] = gs.match;
  gotoh_Table[84][117] = gs.match;
  gotoh_Table[85][84] = gs.match;
  gotoh_Table[85][116] = gs.match;
  gotoh_Table[116][85] = gs.match;
  gotoh_Table[117][84] = gs.match;
  gotoh_Table[116][117] = gs.match;
  gotoh_Table[117][116] = gs.match;
  /* [u,t] -> [U,T]  = match ! */
  
  
  /* for(i=0; i<16; i++) { */
/*     for(j=0; j<16; j++) { /\* go through complete array *\/ */
/*       if(i>j) continue; */
/*       if(i<5 && i == j) { */
/* 	/\* bases[i]; *\/ */
/* 	ni = toascii(bases[i]); */
/* 	nj = toascii(bases[j]); */
/* 	gotoh_Table[i][j] = gs.match; */
/* 	gotoh_Table[i+16][j] = gs.match; */
/* 	gotoh_Table[i][j+16] = gs.match; */
/* 	gotoh_Table[j][i] = gs.match; */
/* 	gotoh_Table[j+16][i] = gs.match; */
/* 	gotoh_Table[j][i+16] = gs.match; */
/* 	gotoh_Table[i+16][j+16] = gs.match; */
/* 	gotoh_Table[j+16][i+16] = gs.match; */
/*       } else { */
/* 	gotoh_Table[i][j] = gs.mismatch; */
/* 	gotoh_Table[i+16][j] = gs.mismatch; */
/* 	gotoh_Table[i][j+16] = gs.mismatch; */
/* 	gotoh_Table[j][i] = gs.mismatch; */
/* 	gotoh_Table[j+16][i] = gs.mismatch; */
/* 	gotoh_Table[j][i+16] = gs.mismatch; */
/* 	gotoh_Table[i+16][j+16] = gs.mismatch; */
/* 	gotoh_Table[j+16][i+16] = gs.mismatch; */
/*       } */
/*     } */
/*   } */

  /* [U,T] -> [u,t] = match ! */
  /* gotoh_Table[3][4] = gs.match; */
/*   gotoh_Table[4][3] = gs.match; */
/*   gotoh_Table[19][4] = gs.match; */
/*   gotoh_Table[20][3] = gs.match; */
/*   /\* [u,t] -> [U,T]  = match ! *\/ */
/*   gotoh_Table[3][20] = gs.match; */
/*   gotoh_Table[4][19] = gs.match; */
/*   gotoh_Table[19][20] = gs.match; */
/*   gotoh_Table[20][19] = gs.match; */

/*   printf("       "); */
/*   for(i=64; i<128; i++) */
/*     printf("%2d:%c\t",i,i); */
/*   printf("\n"); */
/*   for(i=64; i<128; i++) { */
/*     printf("%2d:%c   ",i,i); */
/*     for(j=64; j<128; j++) { */
/*       printf("%3d\t",gotoh_Table[i][j]); */
/*     } */
/*     printf("\n"); */
/*   } */
  
/*   exit(0); */
  return;

}

/* -------------------------------------------------------------------------- */

void gotoh_scanDbase(char * db_seq, int n, char * q_seq, int m,
		     char *db_name, char *q_name, int * score_distr,
		     int n_s, gotoh_settings gs, gotoh_aln List[],
		     int n2add, int Len, int *ntf) {

  int *fw_scores_db=NULL, *bw_scores_db=NULL,mH,i;
  char * rev_q_seq=NULL;
  
  mH = (int) floor((float)m/2) + 1;

  fw_scores_db = gotoh_fwRecursion(db_seq, n, q_seq, m, db_name, q_name,
				   score_distr, n_s, gs, ntf);
  
  /* for(i=1;i<=n;i++) */
/*     printf("FW: %d %d\n",i,fw_scores_db[i]); */
/*   printf("&\n"); */

  /* for(i=0; i<MAX_ALNS; i++) { */
/*     if(List[i].alnscore == -1) break; */
/*     gotoh_printGotohAln(List[i], 1); */
/*   } */
  
  gotoh_findLocalMaxima(fw_scores_db, List, n2add, 0, n, db_seq, db_name, q_seq, q_name, m, '+', gs, Len);

  /* check other strand, seq often shorter than db -> reverse query, not db! */
  rev_q_seq = goto_revCompl(q_seq, gs.verbose, m);

  bw_scores_db = gotoh_fwRecursion(db_seq, n, rev_q_seq, m, db_name, q_name,
				   score_distr, n_s, gs, ntf);


  gotoh_findLocalMaxima(bw_scores_db, List, n2add, 0, n, db_seq, db_name, rev_q_seq, q_name, m, '-', gs, Len);

  /* for(i=1;i<=n;i++) */
/*     printf("BW: %d %d\n",i,bw_scores_db[i]); */

 /*  for(i=0; i<MAX_ALNS; i++) { */
/*     if(List[i].alnscore == -1) break; */
/*     gotoh_printGotohAln(List[i], 1); */
/*   } */
/*   return; */
  /* fprintf(stderr, "NUMBEROFALNS: %d\n",nalns); */
  /* free temporary arrays */
  free(bw_scores_db);
  free(fw_scores_db);
  free(rev_q_seq);

}

/* -------------------------------------------------------------------------- */

int * gotoh_getMaxS(int scores[], int s, int e) {

  int i, *ret=NULL;

  ret = (int *) calloc(2,sizeof(int));
  ret[0] = 0;  /* position in database */
  ret[1] = -1; /* score at position ret[0] */
  
  for(i=s; i<=e; i++)
    if(scores[i] >= ret[1]) { /* get last max (if equal) */
      ret[0] = i; ret[1] = scores[i];
    }

  return ret;  
  
}

/* -------------------------------------------------------------------------- */

int * gotoh_fwRecursion(char * s, int n, char * q, int m, char *db_name, char *q_name,
			int * score_distr, int n_s, gotoh_settings cfg, int *ntf) {

  int  i,j,p,pp,bi,bj;
  int *S, *S_, *D, *D_, *F, *F_, *tmp;
  int *score, transf_score, minAS;

  S   = (int *) calloc(m+1, sizeof(int));
  S_  = (int *) calloc(m+1, sizeof(int));
  D   = (int *) calloc(m+1, sizeof(int));
  D_  = (int *) calloc(m+1, sizeof(int));
  F   = (int *) calloc(m+1, sizeof(int));
  F_  = (int *) calloc(m+1, sizeof(int));

  score = (int *) calloc(n+1, sizeof(int));
  for(i=0; i<=n; i++) {
    score[i] = -1;
   /*  ntf[i] = -1; */
  }

  minAS = abs( 2 * (cfg.gap_open + ((m - 1) * cfg.gap_extend)));
  
  /* initialize semi-local alignment */
  D_[0] = -(cfg.inf);
  F_[0] = -(cfg.inf);
  S_[0] = 0;

  for(j=1;j<=m;j++) { 
    D_[j] = -(cfg.inf);
    F_[j] = (j-1)*cfg.gap_extend + cfg.gap_open;
    S_[j] = F[j];
  }

  for(i=1;i<=n;i++) {
    /* init */
    D[0] = 0;  /* local alignment!*/
    F[0] = -cfg.inf;
    S[0] = 0;

    /* align query  against each database position i */
    for(j=1;j<=m;j++) {
      /* int p,pp; */
      p  = S[j-1] + cfg.gap_open;
      pp = D[j-1] + cfg.gap_extend;
      if(p>pp) D[j] = p;   /* start new insertion */
      else D[j] = pp;      /* extend insertion    */
      
      p = S_[j]  + cfg.gap_open;
      pp = F_[j]  + cfg.gap_extend;
      if(p>pp) F[j] = p;   /* start new deletion */
      else F[j] = pp;      /* extend deletion    */
      
      p = S_[j-1];
      /* if(s[i-1]==q[j-1] && s[i-1] != 'N') p += cfg.match;  /\* match     *\/ */
/*       else p += gotoh_Table[s[i-1]][q[j-1]]; */
      /* /\* else p += cfg.mismatch;  *\/  */           /* mismatch  */
      /* get match/mismatch score from lookuptable */
      p += gotoh_Table[s[i-1]][q[j-1]];
      
      if(D[j]>p) p=D[j];                   /* insertion */
      if(F[j]>p) p=F[j];                   /* deletion  */
      
      S[j] = p;
    }
    
    /* transform score */
    transf_score = S[m] + minAS;
    /* ntf[i] = S[m]; */
    score[i] = transf_score;
    /* nalns++; */
    /* score[i] = S[m]; */
    
    score_distr[transf_score]++; /* sum up to transformed score distribution */

    /* rotate memory */
    tmp = S_; S_ = S; S = tmp;
    tmp = D_; D_ = D; D = tmp;
    tmp = F_; F_ = F; F = tmp;
    
  }

 /*  for(i=1;i<=n;i++) printf("%d: %d\n",i,score[i]); */

  free(S);free(S_);free(D);free(D_);free(F);free(F_);
  
  return score;
  
}

/* -------------------------------------------------------------------------- */

float * gotoh_bwRecursion(char * s, char * q, int m, int s_pos, gotoh_settings cfg,
			  char *ss, char *qq, int sollscore, int n2add) {

  int i,j,k,len, p, pp, wc;
  int **S, **D, **F;
  char *sa, *qa, /* *sx, */ btstate;
  int si,qj,found, start,gos,mms,perc;
  float *res;
  int db_end;

  len = 2 * m + 1;
  if(len > s_pos) len = s_pos;

  /* retransform score */
  wc = abs(2*(cfg.gap_open + (m-1)*cfg.gap_extend));
  sollscore -= wc;

  S = (int **) calloc(len+2, sizeof(int *));
  D = (int **) calloc(len+2, sizeof(int *));
  F = (int **) calloc(len+2, sizeof(int *));
  for(i=0;i<=len;i++) {
    S[i] = (int *) calloc(m+2, sizeof(int *));
    D[i] = (int *) calloc(m+2, sizeof(int *));
    F[i] = (int *) calloc(m+2, sizeof(int *));
  }
  sa = (char *) calloc(2*m+len+2, sizeof(int *));
  qa = (char *) calloc(2*m+len+2, sizeof(int *));
  
  D[0][0] = (-cfg.inf);
  F[0][0] = (-cfg.inf);
  S[0][0] = 0;

  for(j=1;j<=m;j++) { 
    D[0][j] = (-cfg.inf);
    F[0][j] = (j-1)*cfg.gap_extend + cfg.gap_open;
    S[0][j] = F[0][j];
  }

  for(i=1;i<=len;i++) {
    si = s_pos-(i-1);
    
    D[i][0] = 0;
    F[i][0] = (-cfg.inf);
    S[i][0] = 0;
    
    for(j=1;j<=m;j++) {
      qj = m-j;	 

      p  = S[i][j-1] + cfg.gap_open;
      pp = D[i][j-1] + cfg.gap_extend;
      D[i][j] = p > pp ? p : pp;
      
      p  = S[i-1][j] + cfg.gap_open;
      pp = F[i-1][j] + cfg.gap_extend;
      F[i][j] = p > pp ? p : pp;

     /*  if(s[si] == q[qj] && s[si] != 'N') p = cfg.match; */
/*       else p = gotoh_Table[s[si]][q[qj]]; */
      p = gotoh_Table[s[si]][q[qj]];
      /* p = s[si] == q[qj] ? cfg.match : cfg.mismatch; */
      /* if(s[si] == q[qj] && s[si] != 'N') p = cfg.match; */
/*       else p = cfg.mismatch; */
      p += S[i-1][j-1];

      
      if(D[i][j]>p) p=D[i][j];
      
      if(F[i][j]>p) p=F[i][j];
      S[i][j] = p;
    }
			 
  }
  
  i=0; found = 0;
  while(i<len) {
    if(S[i][m] == sollscore) {
      found = 1;
      break;
    }
    i++;
  }
  /* i is now the position with our requested score !!! */
  if(found == 0 && cfg.verbose == 1) {
    fprintf(stderr, "WARNING: At position i=%d, there is a better alignment possible\n",s_pos);
    fprintf(stderr, "         than in forward recursion calculated\n");
  }

  start = s_pos-i+1;
  db_end = start;
  
  res = (float *) calloc(7, sizeof(float));
  /* percId, mm, go, length */
  gos = 0;
  mms = 0;
  perc = 0;
  
  j = m;
  k = 0;
  btstate = 'S';


  while( (j>0) ) {

    if(i<1) break;
    
    si = s_pos -(i-1);
    qj = m -j;

    if(si < 0) {
      while(j>0) {
	sa[k] = '-';
	qa[k] = q[qj];
	start++;
	j--;
	k++;
	qj = m -j;
	si = 1;
      }
      break;
    }

    switch(btstate) {
    case 'S':
      /* if( S[i][j] == S[i-1][j-1] + cfg.match && s[si] == q[qj] && s[si] != 'N') { */
/* 	sa[k] = s[si]; */
/* 	qa[k] = q[qj]; */
/* 	db_end++; */
/* 	i--; */
/* 	j--; */
/* 	k++; */
/* 	btstate = 'S'; */
/* 	perc++; */
/*       } else */ if(S[i][j] == S[i-1][j-1] + gotoh_Table[s[si]][q[qj]]) {
	sa[k] = s[si];
	qa[k] = q[qj];
	db_end++;
	i--;
	j--;
	k++;
	btstate = 'S';
	if(gotoh_Table[s[si]][q[qj]] <= gotoh_Table[78][78])
	  mms++;
	else
	  perc++;
      }
/*       else if( S[i][j] == S[i-1][j-1] + cfg.mismatch && s[si] != q[qj]) { */
/* 	sa[k] = s[si]; */
/* 	qa[k] = q[qj]; */
/* 	db_end++; */
/* 	i--; */
/* 	j--; */
/* 	k++; */
/* 	btstate = 'S'; */
/* 	mms++; */
/*       } */
      /* if(S[i][j] == S[i-1][j-1] + gotoh_Table[s[si]][q[qj]]) { */
/* 	sa[k] = s[si]; */
/* 	qa[k] = q[qj]; */
/* 	db_end++; */
/* 	i--; */
/* 	j--; */
/* 	k++; */
/* 	btstate = 'S'; */
/* 	if(gotoh_Table[s[si]][q[qj]] <= gotoh_Table[78][78]) */
/* 	  mms++; */
/* 	else */
/* 	  perc++; */
/*       } */
      else if( S[i][j] == F[i][j] ) {
	btstate = 'F';
      }
      else if( S[i][j] == D[i][j] ) {
	btstate = 'D';
      }
      else {
	fprintf(stderr,"This should not happen in S[%d][%d]=%d\n",i,j,S[i][j]);
	exit(0);
      } 
      break;
    case 'D':
      if(D[i][j] ==  S[i][j-1] + cfg.gap_open ) {
	sa[k] = '-';
	qa[k] = q[qj];
	start++;
        j--;	
	k++;
	btstate = 'S';
	gos++;
      }
      else if(D[i][j] == D[i][j-1] + cfg.gap_extend ) {
	sa[k] = '-';
	qa[k] = q[qj];
	start++;
	j--;
	k++;
	btstate = 'D';
      }
      else {
	fprintf(stderr,"This should not happen in D[%d][%d]=%d\n",i,j,D[i][j]);
	exit(0);
      } 
      break;
    case 'F':
      if(F[i][j] ==  S[i-1][j]   + cfg.gap_open ) {
	sa[k] = s[si];
	qa[k] = '-';
	db_end++;
	i--;
	k++;
	btstate = 'S';
	gos++;
      }
      else if ( F[i][j] == F[i-1][j]  + cfg.gap_extend ) {
	sa[k] = s[si];
	qa[k] = '-';
	db_end++;
	i--;
	k++;
	btstate = 'F';
      }
      else {
	fprintf(stderr,"This should not happen in F[%d][%d]=%d\n",i,j,F[i][j]);
	exit(0);
      }    
      break;
    default:
      fprintf(stderr,"This should not happen at all. btstate: %c\n",btstate);
      exit(0);
    }
    
  }

  k = strlen(sa);

  res[0] = (float) perc / (float) m * 100;
  res[1] = (float) mms;
  res[2] = (float) gos;
  res[3] = (float) k;
  res[4] = (float) start + 1;
  res[5] = (float) db_end;

  strcpy(ss, sa);
  strcpy(qq, qa);

  for(i=0;i<=len+1;i++) {
    free(S[i]);
    free(D[i]);
    free(F[i]);
  }
  free(S);free(D);free(F);
  free(sa);free(qa);

  return res;
  
}

/* -------------------------------------------------------------------------- */

void gotoh_findLocalMaxima(int *scores, gotoh_aln List[], int n2add,
			   int s, int e,
			   char *db_seq, char *db_name,
			   char *q_seq, char *q_name, int m,
			   char strand, gotoh_settings gs, int Len) {

  int ms, mi, nsl, nel, nsr, ner, ii;
  int shift;

  shift = abs(2 * (gs.gap_open + m * gs.gap_extend));
  
  gotoh_getMaxLinear(scores, s, e, &ms, &mi); /* insert/backtrace ms an mi */

  ii=0; /* find place in L to put local maxima */
  while(List[ii].alnscore >= ms && ii < MAX_ALNS) ii++;
  /* try to prevent including duplicated entries !!*/
  if(ii < MAX_ALNS) { /* insert */
      
    /*FF gotoh_backtraceAln2(ii, mi, ms, strand, db_name, q_name, List, m, db_seq, q_seq, gs, n2add, Len); */
    gotoh_backtraceAln2(ii, mi, ms, strand, db_name, q_name, List, m, db_seq, q_seq, gs, n2add, Len);
    
  } else { /* stop inserting if list full with higher scores! */
    
    return;
      
  }
  
  /* d&c recursion on left side */
  nsl = s; nel = mi - 2*m;
  if(nel - nsl >= m) 
    gotoh_findLocalMaxima(scores, List, n2add, nsl, nel, db_seq, db_name, q_seq, q_name, m, strand, gs, Len);
  
  /* d&c recursion on right side */
  nsr = mi + 2*m + 1; ner = e;
  if(ner - nsr >= m) 
    gotoh_findLocalMaxima(scores, List, n2add, nsr, ner, db_seq, db_name, q_seq, q_name, m, strand, gs, Len);
  
  return;

}

/* -------------------------------------------------------------------------- */

void gotoh_getMaxLinear(int *scores, int s, int e, int *ms, int *mi) {

  int i, sm=0, im=-1;

  for(i=s; i<=e; i++) {
    if(scores[i] >= sm) {
      sm = scores[i];
      im = i;
    }
  }

  *ms = sm; *mi = im;
  
  return;
  
}

/* -------------------------------------------------------------------------- */
/**
   q_seq is sense if strand eq '+', otherwise it is already in antisense 
 */
void gotoh_backtraceAln2(int ii, int imax, int smax, char strand, char *s_name, char* q_name,
			 gotoh_aln List[], int m, char *db_seq, char *q_seq,
			 gotoh_settings gs, int n2add, int Len) {

  float *bt;
  gotoh_aln tmpaln, curaln;
  char *revseq1=NULL,*revseq2=NULL;
  int ll, shift;

  shift = abs(2 * (gs.gap_open + m * gs.gap_extend));
  
  curaln = gotoh_initL();

  curaln.alnscore = smax;
  curaln.ntfalnscore = smax-shift;
  curaln.db_len = Len;
  /* curaln.sEnd = n2add+imax; */
  curaln.qStart = 1;
  curaln.qEnd = m;
  curaln.strand = strand;
  curaln.hitname = (char *) calloc(strlen(s_name)+1, sizeof(char));
  strcpy(curaln.hitname, s_name);
  curaln.queryname = (char *) calloc(strlen(q_name)+1, sizeof(char));
  strcpy(curaln.queryname, q_name);
  curaln.hitseq = (char *) calloc(4*m+1, sizeof(char));
  curaln.queryseq = (char *) calloc(2*m+1, sizeof(char));
  bt = gotoh_bwRecursion(db_seq, q_seq, m, imax-1, gs, curaln.hitseq, curaln.queryseq, smax, n2add);
  if(strand == '-') {
    ll = strlen(curaln.hitseq);
    revseq1 = goto_revCompl(curaln.hitseq, gs.verbose, ll);
    revseq2 = goto_revCompl(curaln.queryseq, gs.verbose, ll);
    strcpy(curaln.hitseq,revseq1);
    strcpy(curaln.queryseq,revseq2);
    
    free(revseq1); free(revseq2);
  }
  curaln.percID = bt[0]; curaln.mismatches = (int) bt[1];
  curaln.gapopening = (int) bt[2]; curaln.length = (int) bt[3];
  curaln.sStart = n2add + (int) bt[4] - 1; 
  curaln.sEnd = n2add + (int) bt[5];
  curaln.evalue = 999999;
  free(bt);

  /* don't insert duplicated entry (due to splits system!) */
  if(ii>=1 && List[ii-1].alnscore == curaln.alnscore && List[ii-1].sEnd == curaln.sEnd)
    return;

  if(ii == 0 || List[ii].alnscore == -1) { /* just insert and goto next db position for next aln */
    List[ii] = curaln;
    return;
  }

  tmpaln = gotoh_initL();

  tmpaln = List[ii];
  List[ii] = curaln;
  ii++;
  while(ii < MAX_ALNS) {
    if(List[ii].alnscore == -1) {
      List[ii] = tmpaln;
      return;
    }
    curaln = gotoh_initL();
    curaln = List[ii];
    
    List[ii] = tmpaln;

    tmpaln = gotoh_initL();
    tmpaln = curaln;

    ii++;
  }

  free(tmpaln.hitname); free(tmpaln.queryname); free(tmpaln.hitseq); free(tmpaln.queryseq);

  return;
  
}

/* -------------------------------------------------------------------------- */

char * goto_revCompl(char *sequence, int v, int len) {

  int i,j;
  char nt;
  char *result;

  result = (char*) calloc(len+1, sizeof(char));
  
  for(i=len-1,j=0;i>=0;i--,j++) {
    switch(sequence[i]) {
    case 'a' : nt = 'u' ; break;
    case 'A' : nt = 'U' ; break;
    case 'u' : nt = 'a' ; break;
    case 'U' : nt = 'A' ; break;
    case 'c' : nt = 'g' ; break;
    case 'C' : nt = 'G' ; break;
    case 'g' : nt = 'c' ; break;
    case 'G' : nt = 'C' ; break;
    case '-' : nt = '-' ; break;
    default :
      gotoh_Warning("There are strange letters in your sequence. Parsed to 'N'.", v);
      nt='N' ;
    }
    result[j]=nt;
  }

  return result;
  
}

/* -------------------------------------------------------------------------- */
/* score_distr => data, distribution of all possible scores */
double * gotoh_getParams(int * score_distr, int n_s, int n_q,
			 gotoh_settings gs, char * qname, int *ntf) {

  int minscore,maxscore, i, minX, maxX, minAS, maxAS, maxN=0,maxY;
  int *H; /* Histogram, shrinked score distr to local maxima */
  double eps = 0.000001;
  double subs=0;
  double t;
  double *params, k, phi, phiprime,  z;
  double sqrtval, nst;
  char *datafile=NULL;
  FILE *fp_data=NULL;
  gotoh_fitData fd;
  int N, minPS, maxPS, x, ticks;
  float mu, s, s1, s2, y, kl, kr,gamma,logx;
  float qxt, sum, sumL, sumR, Hx, Hxkt, theta, thetal, thetar, cc=0, d, fval;
  gotoh_fitVals fv;
  
  /* minAS := | 2 * (gapOpen + ((lenght(query)-1) * gapextend)) |
           ... worst case alignment score
	   -> needed to shift the score distribution which is stored in an array
	      from 0 to minAS + bestCaseScore
  */
  minAS = abs(2 * (gs.gap_open + (n_q - 1) * gs.gap_extend));
  
  /* maxAS := match * length(query)
           ... best case alignment score
	   -> needed only as information in the xmgrace file
  */
  maxAS = n_q * gs.match;
  
  /* printf("minAS:%d maxAS: %d -> %d possible scores (n_s = %d)\n", minAS, maxAS, maxAS+minAS+1, n_s); */

  /* shrink score distribution such that only local maxima are listed */
/*   H = (int *) calloc(n_s + 1, sizeof(int)); */
/*   { */
/*     int o, j, lasty, nexty, maxy; */

/*     o = 0; /\* index on H *\/ */
/*     maxy = 0; */
/*     lasty = -gs.inf; */
/*     nexty = -gs.inf; */
/*     for(j=0; j<n_s; j++) { /\* index on score_distr *\/ */
/*       if(j<n_s) nexty = score_distr[j+1]; */
/*       else nexty = -gs.inf; */

/*       if(((score_distr[j] >  lasty) && (score_distr[j] >= nexty))|| */
/* 	 ((score_distr[j] >= lasty) && (score_distr[j] >  nexty))) { */
/* 	/\* local maximum *\/ */
/* 	H[o] = score_distr[j]; o++; */
/* 	fprintf(stderr, "H %d %d\n",o,H[o]); */
/*       } */
	
/*     } */
/*   } */
/*   free(H); */

  /* to fit score distribution 'score_distr' to a gamma distribution
     we extract the range around the maximum that contains 90% of the
     data starting the range at 55% of the possible score
  */
  fv = gotoh_getRange (score_distr, n_s, minAS);
  
  fprintf(stderr, "MIN: %d MAX: %d N: %d mu: %f s: %f\n",fv.startscore, fv.endscore,fv.N, fv.mu,fv.sval);
 
  /* fd = gotoh_initFit(score_distr, minscore, maxscore, gs.verbose); */
 
  /* exit(0); */
  /* start value for k - estimation */
  /* sqrtval = fv.sval*fv.sval + 18.*fv.sval + 9. */;
  /* sqrtval = (fv.sval - 3)*(fv.sval - 3) + 24*s; */
  sqrtval = 9 - 24*fv.sval*fv.sval + 24*fv.sval;
  if(sqrtval < 0) sqrtval = 9999999;
  fv.k = (3. - sqrt(sqrtval)) / (12. *fv.sval);
  if(fv.k < 0)
    fv.k = (3. + sqrt(sqrtval)) / (12. *fv.sval);

  if(fv.k <= 0) {
    fprintf(stderr,"ERROR: k = %f < 0. \n",fv.k);
    exit(EXIT_FAILURE);
  }
  
  d = 2;
  
  sum = 0;
  fv.theta = fv.mu / fv.k;
  fprintf(stderr,"k: %f theta: %f mins: %d maxs: %d N: %d mu: %f\n",
	 fv.k,fv.theta,fv.startscore,fv.endscore, fv.N,fv.mu);
  sum = 0;
  sum = gotoh_getSum(score_distr, fv, fv.k, fv.theta, minAS);
  /* fprintf(stderr,"sum1: %f\n",sum); */

  /* theta *= 100; */
  
  thetal = fv.theta - fv.theta / d;
  thetar = fv.theta + fv.theta / d;

  eps = 0.01;
  
  while(fabs(sum) > eps) {

    kl = fv.mu / thetal;
    sumL = gotoh_getSum(score_distr, fv, kl, thetal, minAS);
    
    kr = fv.mu / thetar;
    sumR = gotoh_getSum(score_distr, fv, kr, thetar, minAS);

    /* fprintf(stderr, "tl: %f sumL: %f   sum:%f   tr: %f sumR: %f\n",thetal,sumL,sum,thetar,sumR); */
    s = fabs(sum);
    s1 = fabs(sumL); s2 = fabs(sumR);
    if(s1 < s2) {
      if(s1 > s) {
	d *= 2;
	thetal = fv.theta - fv.theta / d;
	thetar = fv.theta + fv.theta / d;
      } else {
	sum = sumL;
	fv.theta = thetal;
	fv.k = kl;
	if(s - s1 < eps) break;
	thetal = fv.theta - fv.theta / d;
	thetar = fv.theta + fv.theta / d;
      }
    } else if(s1 > s2) {
      if(s2 > s) {
	d *= 2;
	thetal = fv.theta - fv.theta / d;
	thetar = fv.theta + fv.theta / d;
      } else {
	sum = sumR;
	fv.theta = thetar;
	fv.k = kr;
	if(s - s2 < eps) break;
	thetal = fv.theta - fv.theta / d;
	thetar = fv.theta + fv.theta / d;
      }
    } else {
      sum = sumR;
      fv.theta = thetar;
      fv.k = kr;
      break;
    }
  }
  
  fv.k = fv.mu / fv.theta;
  gamma = (float) gotoh_logGammaX((double)fv.k);
  /* exit(0); */
  /* fprintf(stderr,"sumEND: %f theta: %f k: %f gamma: %f\n",sum, fv.theta,fv.k,gamma); */
  fprintf(stderr,"theta: %f k: %f gamma: %f\n", fv.theta,fv.k,gamma);
/*   for(i=1;i<=n_s;i++) { */
/*     if(score_distr[i] <= 0) y = -1; */
/*     else y = log(score_distr[i]);  */
/*     x=i; */
/*     /\* fval = log(N) + (k-1) * log(x) - (float)x/theta - k * log(theta) - gamma; *\/\ */
/*     fval = log(fv.N) + fv.k*log(x) - log(x) - x/fv.theta - fv.k*log(fv.theta) - gamma; */
/*     fprintf(stdout, "S %d %d %lf %lf\n", i, score_distr[i], y, fval);     */
/*   } */
  /* in R
     
scores <- read.table('scores.dat')
plot(scores$V2)
lines(scores$V3,col="red")
     
   */

  /* exit(0); */
  
  if(gs.output_data == 1) {
    maxN = 0;
    for(i=fv.startscore; i<=fv.endscore; i++) { if(maxN < score_distr[i]) maxN = score_distr[i]; }
    maxY = floor(log(maxN)) + 2;
    /* minX = floor((float)(fv.startscore - fv.startscore*0.5 - minAS) / 10) * 10; */
    /*FF maxX = n_s + 20 - minAS; */
    maxX = n_s - minAS + 20;
    ticks = floor((maxX)/10/10) * 10;

    datafile = (char *) calloc(strlen(qname)+16, sizeof(char));
    strcpy(datafile,qname);
    strcat(datafile, ".GotohScan.agr");
    fp_data = fopen(datafile, "w");
    fprintf(fp_data, "# Grace project file\n");
    fprintf(fp_data, "#\n");
    fprintf(fp_data, "@version 50120\n");
    fprintf(fp_data, "@page size 792, 612\n");
    fprintf(fp_data, "@map font 4 to \"Helvetica\", \"Helvetica\"\n");
    fprintf(fp_data, "@map font 5 to \"Helvetica-Oblique\", \"Helvetica-Oblique\"\n");
    fprintf(fp_data, "@with g0\n");
    /*FF fprintf(fp_data, "@ world 0, -2, %d, %d\n",maxX,maxY); */
    fprintf(fp_data, "@ world 0, -2, %d, %d\n",maxX,maxY);
    fprintf(fp_data, "@ stack world 0, 0, 0, 0\n");
    fprintf(fp_data, "@ znorm 1\n");
    fprintf(fp_data, "@ view 0.150000, 0.150000, 1.150000, 0.850000\n");
    fprintf(fp_data, "@ title \"GotohScan - Evalue calculation\"\n");
    fprintf(fp_data, "@ title font 4\n");
    fprintf(fp_data, "@ subtitle \"%s, theta=%f, k=%f\"\n",qname,fv.theta,fv.k);
    fprintf(fp_data, "@ subtitle font 5\n");
    fprintf(fp_data, "@ yaxes scale Normal\n");
    fprintf(fp_data, "@ xaxes scale Normal\n");
    fprintf(fp_data, "@ xaxis label \"alignment score\"\n");
    fprintf(fp_data, "@ xaxis label font 4\n");
    fprintf(fp_data, "@ xaxis ticklabel font 4\n");
    fprintf(fp_data, "@ xaxis tick place both\n");
    fprintf(fp_data, "@ xaxis tick major %d\n",ticks);
    fprintf(fp_data, "@target G0.S1\n");
    fprintf(fp_data, "@type xy\n");
/*     fprintf(fp_data, "@ xaxis tick minor ticks 1\n"); */
    fprintf(fp_data, "@ yaxis label \"log( # alns )\"\n");
    fprintf(fp_data, "@ yaxis label font 4\n");
    fprintf(fp_data, "@ yaxis ticklabel font 4\n");
    fprintf(fp_data, "@ yaxis tick place both\n");
    fprintf(fp_data, "@ yaxis tick major 5\n");
/*     fprintf(fp_data, "@ yaxis tick minor ticks 1\n"); */
    fprintf(fp_data, "@ legend on\n");
    fprintf(fp_data, "@ legend font 4\n");
    fprintf(fp_data, "@ legend char size 0.9\n");
    fprintf(fp_data, "@ s0 symbol 10\n");
    fprintf(fp_data, "@ s0 symbol size 0.160000\n");
    fprintf(fp_data, "@ s0 line type 0\n");
    fprintf(fp_data, "@ s0 legend \"Score distribution [%d,%d]\"\n",-minAS,n_s-minAS-1);
    fprintf(fp_data, "@ s1 line linewidth 1.5\n");
    fprintf(fp_data, "@ s1 line color 2\n");
    fprintf(fp_data, "@ s1 line style 2\n");
    fprintf(fp_data, "@ s1 legend \"Fitted gamma distribution\"\n");

    fprintf(fp_data, "@ s2 line type 1\n");
    fprintf(fp_data, "@ s2 line style 3\n");
    fprintf(fp_data, "@ s2 line linewidth 1.0\n");
    fprintf(fp_data, "@ s2 line color 7\n");
    fprintf(fp_data, "@ s2 line pattern 1\n");
    fprintf(fp_data, "@ s2 legend \"Portion used for fitting\"\n");

    fprintf(fp_data, "@ s3 line type 1\n");
    fprintf(fp_data, "@ s3 line style 3\n");
    fprintf(fp_data, "@ s3 line linewidth 1.0\n");
    fprintf(fp_data, "@ s3 line color 7\n");
    fprintf(fp_data, "@ s3 line pattern 1\n");

    fprintf(fp_data, "@target G0.S0\n");
    fprintf(fp_data, "@type xy\n");

    /* print data points */
    for(i=0;i<=n_s;i++) {
      if(score_distr[i] <= 0) y = -1;
      else y = log(score_distr[i]);
      x = i - minAS;
      logx=log(i)/log(minAS);
      fprintf(fp_data, "%d %lf\n", x, y);
      fprintf(stdout, "S %10d %10d %lf   ",x,score_distr[i],y);
      y = log(fv.N) + fv.k*logx - logx - x/fv.theta - fv.k*log(fv.theta) - gamma;
      fprintf(stdout, "%lf\n",y);
    }

    fprintf(fp_data, "&\n"); /* seperate data from fitted curve */

    /* print fitted gamma curve */
    for(i=fv.startscore;i<=n_s;i++) {
      x=i-minAS;
      logx=log(i)/log(minAS);
      y = log(fv.N) + fv.k*logx - logx - x/fv.theta - fv.k*log(fv.theta) - gamma;
      /*FF fprintf(fp_data, "%d %lf\n", x-minAS, y);     */
      fprintf(fp_data, "%d %lf\n", x, y);    
    }

    fprintf(fp_data, "&\n");

    fprintf(fp_data, "%d\t%d\n",fv.startscore-minAS,maxX);
    fprintf(fp_data, "%d\t-3\n",fv.startscore-minAS);
    fprintf(fp_data, "&\n");

    fprintf(fp_data, "%d\t%d\n",fv.endscore-minAS,maxX);
    fprintf(fp_data, "%d\t-3\n",fv.endscore-minAS);
    fprintf(fp_data, "&\n");


    fflush(fp_data);
    fclose(fp_data);
    free(datafile);
  }
  
 /*  exit(0); */
  params = (double *) calloc(4, sizeof(double));
  params[0] = (double)fv.k;
  params[1] = (double)fv.theta;
  params[2] = (double)gamma;
  params[3] = (double)fv.N;
  
  return params;
  
}

/* -------------------------------------------------------------------------- */
/**
   int *s - array, containing the number of alignments with score (= index) [IN]
   int n_s - number of elements in *s [IN]
   returns struct of fit values
*/
struct gotoh_fitVals gotoh_getRange (int *s, int n_s, int shift) {

  int range, i, nn, n=0, l, r, is, mi, pi,n_range ,sum;
  int a, maxS, maxI;
  float mean, logmean, s1, s2;
  gotoh_fitVals gfv;

  /* a = n_s; */
/*   while(s[a] < 5) a--; */
/*   maxS = a; maxI = s[a]; */

  maxS = s[n_s-1]; maxI = n_s;
  mean = 0;
  logmean = 0;
  n = 0;
  for(i=n_s; i>floor(0.55*n_s); i--) {
    if(s[i] >= maxS) { maxS = s[i]; maxI = i; }
  }
  fprintf(stderr,"maxI: %d maxS: %d\n",maxI,maxS);
  /* i = maxI-1; */
/*   while(1) { */
/*     if(s[i] == 0) { i--; continue; } */
/*     if(s[i+1] > s[i] > s[i-1]) { i--; } */
/*     else break; */
/*   } */
/*   i++; */
  i = floor(0.55*n_s);
  while(i < maxI) {
    if(s[i] <= 0) { i++; continue; }
    if(log(s[i]) < log(maxS)*0.8) { i++; }
    else break;
  }
  /* while(s[i] < maxS*0.0007) { i++;} */
  gfv.startscore = i;

  /* i = maxI; */
  /* while(s[i] > maxS*0.4) { i++; } */
  r = (maxI-gfv.startscore)*1.5;
  gfv.endscore = maxI + r;/*  + floor(0.5 * r); */

  /* printf("start: %d end: %d\n",gfv.startscore,gfv.endscore); */ /* exit(0); */
  
  for(i=gfv.startscore; i<=gfv.endscore; i++) {
    /*FF mean += i * s[i]; */
    mean += (i-shift) * s[i];
    /* logmean += log(i) * s[i]; */
    logmean += log(i)/log(shift) * s[i];
    n += s[i];
  }

  /* gfv.startscore = i; */
/*   gfv.endscore = a; */
  gfv.N = n;
  gfv.mu = mean / n;
  fprintf(stderr,"log(mean): %f mean(logs): %f n: %d\n",log(gfv.mu),logmean / n,n);
  gfv.sval = log(gfv.mu) - logmean/n;

  fprintf(stderr,"start:%d end:%d N:%d mu:%f s:%f\n",gfv.startscore,gfv.endscore,n,mean/n,log(mean/n) -logmean/n);
  return gfv;
  
  /* start range at 55% of possible score distribution */
  is = floor(0.65*n_s);
  
  /* for(i=0; i<n_s; i++) { printf("IS %d %d\n",i,s[i]); } */
  
  /* get number of all datapoints beyond 'is' */
  for(i=is; i<n_s; i++) { n += s[i]; }
  
  /* get 90% of it */
  n_range = floor(0.9 * (float)n);

  mean = 0;
  logmean = 0;
  sum = 0;
  r = is;
  while(sum <= n_range) {
    /*FF mean += r*s[r];  */           /* sum up for mean calculation */
    mean += (r-shift)*s[r];
    /*FF logmean += log(r)*s[r]; */    /* sum up for logmean calculation */
    logmean += log(r-shift)*s[r];
    sum +=s[r];                /* count datapoints */
    r++;                       /* shift on x-axis */
  }

  gfv.startscore = is;
  gfv.endscore   = r;
  gfv.mu    = mean / sum;
  gfv.N     = sum;
  fprintf(stderr,"log(mean): %f mean(logs): %f\n",log(gfv.mu),logmean / sum);
  gfv.sval = log(gfv.mu) - logmean / sum;

  return gfv;
}

/* -------------------------------------------------------------------------- */
/**
   int *scores - array, containing the number of alignments with score (= index) [IN]
   gotoh_fitVals fv - struct storing the current fit values [IN]
   k - current k, may diverge from fv.k! [IN]
   theta - current theta, may diverge from fv.theta! [IN]
   returns sum of derivation of log(gamma-funktion)
 */
float gotoh_getSum(int *scores, gotoh_fitVals fv, float k, float theta, int shift) {

  int x;
  float Hx, qxt, Hxkt, sum, phi, gamma;

  phi = (float) gotoh_getPhi((double)k);
  gamma = (float) gotoh_logGammaX(k);
  /* exit(0); */
  sum = 0;
  for(x=fv.startscore; x<=fv.endscore; x++) {
    if(scores[x] <= 0) continue;
    Hx = log(scores[x]);
    /*FF qxt = (-1)*fv.mu*log(x) + x - fv.mu*log(theta) - fv.mu + fv.mu*theta - phi*theta*theta; */
    qxt = (-1)*fv.mu*log(x-shift) + (x-shift) - fv.mu*log(theta) - fv.mu + fv.mu*theta - phi*theta*theta;
    /*FF Hxkt = gotoh_getLogGammaVal(x,(double)k,theta,gamma,0) + log(fv.N); */
    Hxkt = gotoh_getLogGammaVal(x-shift,(double)k,theta,gamma,0) + log(fv.N);
    sum += ((Hx) - Hxkt)*qxt;
  }

  return sum;

}


/* -------------------------------------------------------------------------- */

double gotoh_getPhi(double k) {

  if(k >= 8)
    return (log(k) - (1  + (1 - (1/10 - 1/(21*k*k)) / (k*k)) / (6*k)) / (2*k));

  return (gotoh_getPhi(k+1) - 1/k);
  
}

/* -------------------------------------------------------------------------- */
/* for details see: Choi and Wette (1969) */
double gotoh_getPhiPrime(double k) {

  if(k >= 8) 
    return ((1. + (1.+ (1.- (0.2 - 1./(7.*k*k)) / (k*k)) / (3.*k)) / (2.*k)) / k);

  return (gotoh_getPhiPrime(k+1.) + 1./(k*k));
    
}

/* -------------------------------------------------------------------------- */

float gotoh_getGammaVal(int x, double k, float theta, float gamma, int v) {

  float pg=0;
  
  if(k < 0 || theta < 0 || x < 0)
    gotoh_Error("negative value in gamma distribution -> is this possible???", v);

  pg = pow(x, k-1) * exp(-x/theta) / (pow(theta,k) * gamma);
  
  return pg;

}

/* -------------------------------------------------------------------------- */
float gotoh_getLogGammaVal(int x, double k, float theta, float gamma, int v) {

  float pg=0;

  if(k < 0 || theta < 0 || x < 0)
    gotoh_Error("negative value in gamma distribution -> is this possible???",v);

  pg = (k - 1) * log(x) - x/theta - k*log(theta) - gamma;

  return pg;
  
}

/* -------------------------------------------------------------------------- */

float gotoh_gammaX(float x) {

  int i;
  float g=0;

  if(x < 1) {
    g = gotoh_gammaX(x+1) / x;
  } else if(x > 2) {
    g = (x-1) * gotoh_gammaX(x-1);
  } else {
    i=0;
    while(x > gotoh_gammatable[i][0]) { i++; }
    g = gotoh_gammatable[i][1];
  }

  /* fprintf(stderr, "x: %f gamma: %f\n",x,g); */
  
  return g;
  
}
/* -------------------------------------------------------------------------- */

float gotoh_logGammaX(float x) {

  int i;
  float g=0;

  if(x < 1) {
    if(x > 0) g = gotoh_logGammaX(x+1) - log(x);
    else {
      fprintf(stderr, "ERROR: k-1 reaches 0 in gamma computation.\n");
      exit(EXIT_FAILURE);
    }
  } else if(x > 2) {
    g = log(x-1) + gotoh_logGammaX(x-1);
  } else {
    i=0;
    while(x > gotoh_gammatable[i][0]) { i++; }
    g = log(gotoh_gammatable[i][1]);
  }

  /* fprintf(stderr, "x:%f log(gamma): %f\n\n",(float)x,g); */

  return g;
  
}

/* -------------------------------------------------------------------------- */

double gotoh_uFunction(double a, double z) {

  double u=1., t=1., k=1., eps = 0.000001;

  /* if(z < a) */
/*     fprintf(stderr, "WARNING: estimated parameter k (%lf) < x/theta (%lf)\n. Numerical problems to be expected!\n",a, z); */

  while(t > eps) {
    t *= (a - k) / z;
    u += t;
    k++;
  }

  return u;
  
}

/* -------------------------------------------------------------------------- */

struct gotoh_aln gotoh_initL(void) {

  gotoh_aln ga;

  ga.db_len = 0;
  ga.hitseq=NULL; ga.queryseq=NULL; ga.hitname=NULL; ga.queryname=NULL;
  ga.sStart = -1; ga.sEnd = -1;
  ga.qStart = -1; ga.qEnd = -1;
  ga.length = 0;
  ga.alnscore = -1;
  ga.Levalue = 999999;
  ga.evalue = 1e-3;
  ga.strand = '+';
  ga.mismatches = 0; ga.gapopening = 0;
  ga.percID = 0;
  
  return ga;
  
}

/* -------------------------------------------------------------------------- */

void gotoh_printGotohAln(gotoh_aln aln, int f) {

  int i;
  char *t=NULL;

  switch(f) {
  case 0: /* blast */
    fprintf(stdout, "%s\t%s\t%5.2f\t",aln.queryname,aln.hitname,aln.percID);
    fprintf(stdout, "%d\t%d\t%d\t",aln.length,aln.mismatches,aln.gapopening);
    if(aln.strand == '+') {
      fprintf(stdout, "%d\t%d\t%d\t%d\t",aln.qStart,aln.qEnd,aln.sStart,aln.sEnd);
    } else {
      fprintf(stdout, "%d\t%d\t%d\t%d\t",aln.qStart,aln.qEnd,aln.sEnd,aln.sStart);
    }
    fprintf(stdout, "%e\n",aln.evalue);
    break;
  case 1: /* blast + aln sequences */
    fprintf(stdout, "%s\t%s\t%5.2f\t",aln.queryname,aln.hitname,aln.percID);
    fprintf(stdout, "%d\t%d\t%d\t",aln.length,aln.mismatches,aln.gapopening);
    if(aln.strand == '+') {
      fprintf(stdout, "%d\t%d\t%d\t%d\t",aln.qStart,aln.qEnd,aln.sStart,aln.sEnd);
    } else {
      fprintf(stdout, "%d\t%d\t%d\t%d\t",aln.qStart,aln.qEnd,aln.sEnd,aln.sStart);
    }
    fprintf(stdout, "%e\t",aln.evalue);
    fprintf(stdout, "strand:%c\t", aln.strand);
    fprintf(stdout, "%s&%s\n",aln.hitseq,aln.queryseq); 
    break;
  case 2: /* fasta */
    fprintf(stdout, ">%s:%s:%d-%d:%c:%.2f:%e\n",aln.queryname,aln.hitname,aln.sStart,aln.sEnd,aln.strand,aln.percID,aln.evalue);
    for(i=0; i<aln.length; i++)
      if(aln.hitseq[i] != '-') fprintf(stdout, "%c",aln.hitseq[i]);
    fprintf(stdout, "\n");
    break;
  case 3: /* maf */
    /* give real sequence lengths and NOT alignment lengths! */
    { int i,ll;
      char *t=NULL;
      t = (char *) calloc(32, sizeof(char));
      strncpy(t, aln.hitname, 30);
      
      fprintf(stdout, "a score=%e\n",aln.evalue);
      fprintf(stdout, "%-30s %13d %5d %c %13d %s\n",t,aln.sStart,aln.length,aln.strand,aln.db_len,aln.hitseq);
      strncpy(t, aln.queryname, 30);
      ll = 0;
      for(i=0; i<aln.length; i++)
	if(aln.queryseq[i] != '-')
	  ll++;
      fprintf(stdout, "%-30s %13d %5d %c %13d %s\n",t,aln.qStart,ll,aln.strand,ll,aln.queryseq);
      free(t);
    }
    fprintf(stdout, "\n");
    /* fprintf(stdout, "CLUSTAL W\n\n\n"); */
/*     t = (char *) calloc(32, sizeof(char)); */
/*     strncpy(t, aln.hitname, 30); */
/*     fprintf(stdout, "%-30s %s\n",t, aln.hitseq); */
/*     strncpy(t, aln.queryname, 30); */
/*     fprintf(stdout, "%-30s %s\n",t, aln.queryseq); */
/*     free(t); */
/*     fprintf(stdout, "%-30s ",""); */
/*     for(i=0;i<aln.length; i++) { */
/*       if(aln.hitseq[i] == aln.queryseq[i]) fprintf(stdout, "*"); */
/*       else fprintf(stdout, " "); */
/*     } */
/*     fprintf(stdout, "\n//\n"); */
    break;
  case 4: /* bed */
    fprintf(stdout, "%s\t%d\t%d\t%s\t%e\t%c\t",aln.hitname,aln.sStart,aln.sEnd,aln.queryname,aln.evalue,aln.strand);
    fprintf(stdout, "note=\"%s&%s\"\n",aln.hitseq,aln.queryseq);
    break;
  case 5: /* gff */
    fprintf(stdout, "%s\tGotohScan\t%s\t%d\t%d\t",aln.hitname,aln.queryname,aln.sStart,aln.sEnd);
    fprintf(stdout, "%e\t%c\t",aln.evalue,aln.strand);
    fprintf(stdout, "note=\"%s&%s\"\n",aln.hitseq,aln.queryseq);
    break;
  case 6: /* my own test output */
    fprintf(stdout, "%s\n%s\n",aln.hitname,aln.hitseq);
    fprintf(stdout, "%s\n%s\n",aln.queryname,aln.queryseq);
    fprintf(stdout, "start: %d length: %d strand: %c ",aln.sStart,aln.length,aln.strand);
    fprintf(stdout, "alnscore: %d log(Evalue): %lf Evalue: %.2e\n\n",aln.alnscore,aln.Levalue,aln.evalue);
    break;
  default: /* blast -> 0 */
    fprintf(stdout, "%s\t%s\t%5.2f\t",aln.queryname,aln.hitname,aln.percID);
    fprintf(stdout, "%d\t%d\t%d\t",aln.length,aln.mismatches,aln.gapopening);
    fprintf(stdout, "%d\t%d\t%d\t%d\t",aln.qStart,aln.qEnd,aln.sStart,aln.sEnd);
    fprintf(stdout, "%e\n",aln.evalue);
  }

  fflush(NULL);
  return;
  
}

/* -------------------------------------------------------------------------- */

void gotoh_getRNA(char *seq, int l) {

  int i,j=0;
  char *tmp=NULL;
  
  i=0; j=0;

  tmp = (char *) calloc(l+1, sizeof(char));
  printf("l: %d\n%s\n",l,seq);
  while(i<l) {
    fprintf(stderr,"%d: %c\n",i,seq[i]);
    switch(seq[i]) {
    case 'a':
      tmp[j] = 'A'; j++;
      break;
    case 'c':
      tmp[j] = 'C'; j++;
      break;
    case 'g':
      tmp[j] = 'G'; j++;
      break;
    case 't':
      tmp[j] = 'U'; j++;
      break;
    case 'u':
      tmp[j] = 'U'; j++;
      break;
    case 'A':
      tmp[j] = 'A'; j++;
      break;
    case 'C':
      tmp[j] = 'C'; j++;
      break;
    case 'G':
      tmp[j] = 'G'; j++;
      break;
    case 'T':
      tmp[j] = 'U'; j++;
      break;
    case 'U':
      tmp[j] = 'U'; j++;
      break;
    case 'N':
      tmp[j] = 'N'; j++;
      break;
    case 'n':
      tmp[j] = 'N'; j++;
      break;
    case ' ':
      break;
    default:
      /* fprintf(stderr, "ERROR: You have strange letters in your sequence\n"); */
/*       fprintf(stderr, "       Letter: '%c' at position: %d\n",seq[i],i); */
/*       exit(0); */
      tmp[j] = 'N'; j++;
    }
    i++;
  }

  tmp[j] = '\0';

  strcpy(seq, tmp);
    
  free(tmp);
  
}

/* -------------------------------------------------------------------------- */
